import assert from "node:assert/strict";
import test from "node:test";
import { normalizeArabic, rankQuranMatches } from "../lib/quran-match.ts";

const sample = [{
  number: 1,
  name: "سُورَةُ ٱلْفَاتِحَةِ",
  ayahs: [
    { number: 1, numberInSurah: 1, text: "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ" },
    { number: 2, numberInSurah: 2, text: "ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ" },
    { number: 3, numberInSurah: 3, text: "ٱلرَّحْمَٰنِ ٱلرَّحِيمِ" },
  ],
}];

test("normalizes Quran marks and Alef variants", () => {
  assert.equal(normalizeArabic("ٱلْحَمْدُ لِلَّهِ"), "الحمد لله");
});

test("ranks the spoken verse first", () => {
  const [match] = rankQuranMatches("الحمد لله رب العالمين", sample, 2);
  assert.equal(match.ayahGlobalNumber, 2);
  assert.equal(match.ayahNumber, 2);
  assert.equal(match.surahName, "الفاتحة");
  assert.ok(match.confidence >= 70);
});

test("returns no match for unusably short audio text", () => {
  assert.deepEqual(rankQuranMatches("لا", sample), []);
});

