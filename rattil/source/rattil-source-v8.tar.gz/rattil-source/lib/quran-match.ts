export interface QuranAyahMatch {
  ayahGlobalNumber: number;
  ayahNumber: number;
  endAyahNumber: number;
  surahNumber: number;
  surahName: string;
  text: string;
  confidence: number;
}

interface QuranAyahSource {
  number: number;
  numberInSurah: number;
  text: string;
}

export interface QuranSurahSource {
  number: number;
  name: string;
  ayahs: QuranAyahSource[];
}

const QURAN_MARKS = /[\u0610-\u061A\u0640\u064B-\u065F\u0670\u06D6-\u06ED]/gu;
const NON_ARABIC = /[^\u0621-\u063A\u0641-\u064A\s]/gu;

export function normalizeArabic(value: string) {
  return value
    .normalize("NFKD")
    .replace(QURAN_MARKS, "")
    .replace(/[ٱأإآ]/gu, "ا")
    .replace(/ى/gu, "ي")
    .replace(/ؤ/gu, "و")
    .replace(/ئ/gu, "ي")
    .replace(/ة/gu, "ه")
    .replace(NON_ARABIC, " ")
    .replace(/\s+/gu, " ")
    .trim();
}

function cleanSurahName(value: string) {
  return value
    .replace(QURAN_MARKS, "")
    .replace(/ٱ/gu, "ا")
    .replace(/^سورة\s+/u, "")
    .trim();
}

function ngrams(value: string, size = 2) {
  const compact = value.replace(/\s+/gu, "");
  const grams = new Map<string, number>();
  if (compact.length < size) {
    if (compact) grams.set(compact, 1);
    return grams;
  }
  for (let index = 0; index <= compact.length - size; index += 1) {
    const gram = compact.slice(index, index + size);
    grams.set(gram, (grams.get(gram) ?? 0) + 1);
  }
  return grams;
}

function multisetDice(left: Map<string, number>, right: Map<string, number>) {
  let common = 0;
  let leftCount = 0;
  let rightCount = 0;
  left.forEach((count, token) => {
    leftCount += count;
    common += Math.min(count, right.get(token) ?? 0);
  });
  right.forEach((count) => {
    rightCount += count;
  });
  return leftCount + rightCount ? (2 * common) / (leftCount + rightCount) : 0;
}

function tokenCounts(value: string) {
  const counts = new Map<string, number>();
  value.split(" ").filter(Boolean).forEach((token) => {
    counts.set(token, (counts.get(token) ?? 0) + 1);
  });
  return counts;
}

function similarity(transcript: string, candidate: string) {
  const characterScore = multisetDice(ngrams(transcript), ngrams(candidate));
  const tokenScore = multisetDice(tokenCounts(transcript), tokenCounts(candidate));
  const containment = transcript.includes(candidate) || candidate.includes(transcript) ? 1 : 0;
  const lengthRatio = Math.min(transcript.length, candidate.length) / Math.max(transcript.length, candidate.length, 1);
  return characterScore * 0.52 + tokenScore * 0.34 + containment * lengthRatio * 0.14;
}

export function rankQuranMatches(
  transcript: string,
  surahs: QuranSurahSource[],
  limit = 3,
): QuranAyahMatch[] {
  const normalizedTranscript = normalizeArabic(transcript);
  if (normalizedTranscript.replace(/\s/gu, "").length < 4) return [];

  const candidates: QuranAyahMatch[] = [];
  for (const surah of surahs) {
    const maxWindow = Math.min(4, surah.ayahs.length);
    for (let start = 0; start < surah.ayahs.length; start += 1) {
      let combinedText = "";
      for (let windowSize = 1; windowSize <= maxWindow && start + windowSize <= surah.ayahs.length; windowSize += 1) {
        const ayah = surah.ayahs[start + windowSize - 1];
        combinedText = `${combinedText} ${ayah.text}`.trim();
        const score = similarity(normalizedTranscript, normalizeArabic(combinedText));
        candidates.push({
          ayahGlobalNumber: surah.ayahs[start].number,
          ayahNumber: surah.ayahs[start].numberInSurah,
          endAyahNumber: ayah.numberInSurah,
          surahNumber: surah.number,
          surahName: cleanSurahName(surah.name),
          text: combinedText,
          confidence: Math.round(score * 100),
        });
      }
    }
  }

  candidates.sort((left, right) => right.confidence - left.confidence);
  const results: QuranAyahMatch[] = [];
  const seen = new Set<string>();
  for (const candidate of candidates) {
    const key = `${candidate.surahNumber}:${candidate.ayahNumber}`;
    if (seen.has(key)) continue;
    seen.add(key);
    results.push(candidate);
    if (results.length >= limit) break;
  }
  return results;
}
