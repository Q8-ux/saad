import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const source = await readFile(new URL("../app/rattil-app.tsx", import.meta.url), "utf8");
const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

test("the homepage Quran sample renders numbered verse markers", () => {
  assert.doesNotMatch(source, /الرَّحْمَٰنُ ۝ عَلَّمَ الْقُرْآنَ ۝ خَلَقَ الْإِنسَانَ/);
  assert.equal((source.match(/className="hero-ayah-marker"/g) ?? []).length, 3);
  assert.match(source, /arabicDigits\(1, lang\)/);
  assert.match(source, /arabicDigits\(2, lang\)/);
  assert.match(source, /arabicDigits\(3, lang\)/);
  assert.match(styles, /\.hero-ayah-marker\s*\{/);
});

test("Mushaf verse badges always contain an accessible number", () => {
  assert.match(source, /className="ayah-number"/);
  assert.match(source, /aria-label=\{`\$\{tx\("الآية", "Verse"\)\}/);
  assert.match(source, /\{arabicDigits\(ayah\.numberInSurah, lang\)\}/);
  assert.match(styles, /\.ayah-number[^}]*font-family:\s*Tahoma, Arial, sans-serif/s);
});
