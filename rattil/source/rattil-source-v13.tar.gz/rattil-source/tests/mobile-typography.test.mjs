import assert from "node:assert/strict";
import { readFile, stat } from "node:fs/promises";
import test from "node:test";

const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

test("AL-Mohanad regular and bold files are bundled with the interface", () => {
  assert.match(styles, /font-family:\s*"AL-Mohanad"/);
  assert.match(styles, /\.\.\/public\/fonts\/al-mohanad\.woff/);
  assert.match(styles, /\.\.\/public\/fonts\/al-mohanad-bold\.woff/);
  assert.match(styles, /body\s*\{[\s\S]*?font-family:\s*"AL-Mohanad", Tahoma, Arial, sans-serif;/);
});

test("GitHub build emits cacheable AL-Mohanad font assets", async () => {
  const regular = await stat(new URL("../github-dist/assets/al-mohanad.woff", import.meta.url));
  const bold = await stat(new URL("../github-dist/assets/al-mohanad-bold.woff", import.meta.url));
  assert.ok(regular.size > 40_000);
  assert.ok(bold.size > 40_000);
});

test("mobile UI has a readable type and touch-target baseline", () => {
  const mobile = styles.match(/\/\* Mobile readability baseline[\s\S]*?@media \(max-width: 700px\) \{([\s\S]*)\}\s*$/)?.[1];
  assert.ok(mobile, "mobile readability rules should be the final responsive override");
  assert.match(mobile, /body\s*\{\s*font-size:\s*17px;/);
  assert.match(mobile, /input, select, textarea,[\s\S]*?font-size:\s*16px;/);
  assert.match(mobile, /\.mobile-nav button\s*\{[^}]*font-size:\s*16px;/);
  assert.match(mobile, /\.ayah-actions button\s*\{[^}]*min-height:\s*44px;[^}]*font-size:\s*14px;/);
  assert.match(mobile, /\.tafsir-text\s*\{[^}]*font-size:\s*17px;/);
});

test("Quran text retains a Mushaf-friendly font on mobile", () => {
  assert.match(styles, /\.quran-text\s*\{\s*font-family:\s*"Traditional Arabic"/);
  assert.match(styles, /Quran verses keep a dedicated Mushaf-friendly typeface/);
  assert.match(styles, /\.quran-text, \.hero-verse,[\s\S]*?font-family:\s*"Traditional Arabic", "Noto Naskh Arabic", "Amiri", Georgia, serif;/);
});
