import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const source = await readFile(new URL("../app/rattil-app.tsx", import.meta.url), "utf8");

test("AI result links open the matched verse and the Surah beginning", () => {
  assert.match(source, /openAnalysisMatchInMushaf\(analysisResult\.match!, true\)/);
  assert.match(source, /openAnalysisMatchInMushaf\(analysisResult\.match!, false\)/);
  assert.match(source, /id=\{`ayah-\$\{currentSurah\.number\}-\$\{ayah\.numberInSurah\}`\}/);
  assert.match(source, /scrollIntoView\(\{/);
});

test("GitHub Pages uses browser speech recognition without exposing an API key", () => {
  assert.match(source, /webkitSpeechRecognition/);
  assert.match(source, /rankQuranMatches\(browserTranscript/);
  assert.doesNotMatch(source, /sk-[A-Za-z0-9_-]{20,}/);
});

test("word results search the full Quran and open the selected verse", () => {
  assert.match(source, /findAyahsContainingWord\(normalizedWord, quranSource\)/);
  assert.match(source, /openAnalysisMatchInMushaf\(result, false\)/);
  assert.match(source, /wordResults\.slice\(0, wordResultsVisible\)/);
});
