import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const source = await readFile(new URL("../app/rattil-app.tsx", import.meta.url), "utf8");

test("Tafsir as-Saadi is available in the Mushaf with pinned reviewed editions", () => {
  assert.match(source, /id="tafsir-select"/);
  assert.match(source, /value="saadi"/);
  assert.match(source, /TAFSIR_DATA_REVISION = "[a-f0-9]{40}"/);
  assert.match(source, /ar-tafsir-as-saadi/);
  assert.match(source, /turkish-tafsir-as-saadi-turkish/);
  assert.match(source, /ur-tafsir-as-saadi-urdu/);
});

test("unsupported Tafsir languages fall back to Arabic without machine translation", () => {
  assert.match(source, /en: "ar"/);
  assert.match(source, /fr: "ar"/);
  assert.match(source, /es: "ar"/);
  assert.match(source, /without machine translation/);
  assert.doesNotMatch(source, /translate\.google|api\/translate/);
});

test("each Tafsir panel attributes the source and links to the selected verse", () => {
  assert.match(source, /quranenc\.com\/\$\{tafsirContentLang\}\/browse\/\$\{tafsirEdition\.quranEncSlug\}/);
  assert.match(source, /#aya-\$\{ayahNumber\}/);
  assert.match(source, /QuranEnc\.com, edition/);
});
