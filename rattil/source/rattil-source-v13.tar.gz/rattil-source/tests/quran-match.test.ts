import assert from "node:assert/strict";
import test from "node:test";
import {
  extractQuranSearchWords,
  findAyahsContainingWord,
  normalizeArabic,
  rankQuranMatches,
} from "../lib/quran-match.ts";

const sample = [{
  number: 1,
  name: "سُورَةُ ٱلْفَاتِحَةِ",
  ayahs: [
    { number: 1, numberInSurah: 1, text: "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ" },
    { number: 2, numberInSurah: 2, text: "ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ" },
    { number: 3, numberInSurah: 3, text: "ٱلرَّحْمَٰنِ ٱلرَّحِيمِ" },
  ],
}];

test("normalizes Quran marks and Alef variants", () => {
  assert.equal(normalizeArabic("ٱلْحَمْدُ لِلَّهِ"), "الحمد لله");
});

test("ranks the spoken verse first", () => {
  const [match] = rankQuranMatches("الحمد لله رب العالمين", sample, 2);
  assert.equal(match.ayahGlobalNumber, 2);
  assert.equal(match.ayahNumber, 2);
  assert.equal(match.surahName, "الفاتحة");
  assert.ok(match.confidence >= 70);
});

test("returns no match for unusably short audio text", () => {
  assert.deepEqual(rankQuranMatches("لا", sample), []);
});

test("extracts unique searchable words from heard text", () => {
  assert.deepEqual(
    extractQuranSearchWords("الرَّحْمَٰنِ الرحيم الرحمن"),
    ["الرحمن", "الرحيم"],
  );
});

test("finds every verse containing the exact normalized word", () => {
  const results = findAyahsContainingWord("الرَّحْمَٰنِ", sample);
  assert.deepEqual(results.map((result) => result.ayahNumber), [1, 3]);
  assert.ok(results.every((result) => result.surahName === "الفاتحة"));
});

test("does not treat a partial word as the same word", () => {
  assert.deepEqual(findAyahsContainingWord("رحم", sample), []);
});
