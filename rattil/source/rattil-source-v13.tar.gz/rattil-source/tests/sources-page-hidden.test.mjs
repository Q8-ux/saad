import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const source = await readFile(new URL("../app/rattil-app.tsx", import.meta.url), "utf8");

test("the Sources page is hidden from every user-facing navigation", () => {
  assert.doesNotMatch(source, /changeView\("sources"\)/);
  assert.doesNotMatch(source, /\{ id: "sources" as View, icon: ShieldCheck \}/);
  assert.doesNotMatch(source, /<button[^>]*>\{t\.sources\}<\/button>/);
});

test("source attribution remains available inside the application code", () => {
  assert.match(source, /const SOURCE_ITEMS = \[/);
  assert.match(source, /const renderSources = \(\) =>/);
  assert.match(source, /sources: renderSources/);
  assert.match(source, /QuranEnc\.com|quranenc\.com/);
});
