import { resolve } from "node:path";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  base: "./",
  plugins: [react()],
  build: {
    outDir: "github-dist",
    emptyOutDir: true,
    // Keep bundled fonts as cacheable files instead of inflating render-blocking CSS.
    assetsInlineLimit: 0,
    rollupOptions: {
      input: resolve(import.meta.dirname, "github.html"),
      output: {
        entryFileNames: "assets/app.js",
        chunkFileNames: "assets/[name].js",
        assetFileNames: (assetInfo) => assetInfo.names.some((name) => name.endsWith(".css"))
          ? "assets/app.css"
          : "assets/[name][extname]",
      },
    },
  },
});
