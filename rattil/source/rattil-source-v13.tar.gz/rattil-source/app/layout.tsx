import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "رَتِّل القرآن",
  description: "منصة عربية ذكية لتنظيم حفظ القرآن الكريم والمراجعة والتسميع.",
  other: {
    "codex-preview": "development",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
