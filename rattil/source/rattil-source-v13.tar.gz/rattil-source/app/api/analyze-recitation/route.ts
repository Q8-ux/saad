import { rankQuranMatches, type QuranSurahSource } from "../../../lib/quran-match";

const OPENAI_TRANSCRIPTIONS_URL = "https://api.openai.com/v1/audio/transcriptions";
const QURAN_URL = "https://api.alquran.cloud/v1/quran/quran-uthmani";
const MAX_AUDIO_BYTES = 12 * 1024 * 1024;
const MAX_REQUESTS_PER_WINDOW = 8;
const RATE_WINDOW_MS = 10 * 60_000;
const ALLOWED_AUDIO_TYPES = new Set([
  "audio/aac",
  "audio/flac",
  "audio/m4a",
  "audio/mp4",
  "audio/mpeg",
  "audio/ogg",
  "audio/wav",
  "audio/webm",
  "audio/x-m4a",
  "audio/x-wav",
]);

let quranPromise: Promise<QuranSurahSource[]> | null = null;
const requestBuckets = new Map<string, { count: number; resetAt: number }>();

function isRateLimited(request: Request) {
  const now = Date.now();
  const clientId = request.headers.get("cf-connecting-ip")
    ?? request.headers.get("x-forwarded-for")?.split(",", 1)[0]?.trim()
    ?? "local";
  const bucket = requestBuckets.get(clientId);
  if (!bucket || bucket.resetAt <= now) {
    requestBuckets.set(clientId, { count: 1, resetAt: now + RATE_WINDOW_MS });
    if (requestBuckets.size > 2_000) {
      requestBuckets.forEach((entry, key) => {
        if (entry.resetAt <= now) requestBuckets.delete(key);
      });
    }
    return false;
  }
  bucket.count += 1;
  return bucket.count > MAX_REQUESTS_PER_WINDOW;
}

function json(data: unknown, status = 200) {
  return Response.json(data, {
    status,
    headers: {
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}

function getQuran() {
  if (!quranPromise) {
    quranPromise = fetch(QURAN_URL, { headers: { Accept: "application/json" } })
      .then(async (response) => {
        if (!response.ok) throw new Error("QURAN_SOURCE_UNAVAILABLE");
        const payload = await response.json() as { data?: { surahs?: QuranSurahSource[] } };
        if (!payload.data?.surahs?.length) throw new Error("QURAN_SOURCE_INVALID");
        return payload.data.surahs;
      })
      .catch((error) => {
        quranPromise = null;
        throw error;
      });
  }
  return quranPromise;
}

export async function POST(request: Request) {
  if (isRateLimited(request)) return json({ error: "ai_rate_limited" }, 429);
  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (contentLength > MAX_AUDIO_BYTES + 256_000) {
    return json({ error: "audio_too_large" }, 413);
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return json({ error: "ai_not_configured" }, 503);

  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return json({ error: "invalid_form_data" }, 400);
  }

  const audio = form.get("audio");
  if (!(audio instanceof File) || audio.size === 0) {
    return json({ error: "audio_required" }, 400);
  }
  if (audio.size > MAX_AUDIO_BYTES) return json({ error: "audio_too_large" }, 413);

  const mimeType = audio.type.toLowerCase().split(";", 1)[0];
  if (!ALLOWED_AUDIO_TYPES.has(mimeType)) {
    return json({ error: "unsupported_audio_type" }, 415);
  }

  try {
    const openaiForm = new FormData();
    openaiForm.append("file", audio, audio.name || "recitation.webm");
    openaiForm.append("model", "gpt-4o-mini-transcribe");
    openaiForm.append("language", "ar");
    openaiForm.append("response_format", "json");
    openaiForm.append(
      "prompt",
      "This is a Quran recitation in Arabic. Transcribe only the words that are clearly heard, preserving Quranic wording. Do not guess missing words.",
    );

    const transcriptionResponse = await fetch(OPENAI_TRANSCRIPTIONS_URL, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}` },
      body: openaiForm,
      signal: AbortSignal.timeout(45_000),
    });

    if (!transcriptionResponse.ok) {
      if (transcriptionResponse.status === 429) return json({ error: "ai_rate_limited" }, 429);
      if (transcriptionResponse.status === 401 || transcriptionResponse.status === 403) {
        return json({ error: "ai_configuration_error" }, 503);
      }
      return json({ error: "transcription_failed" }, 502);
    }

    const transcription = await transcriptionResponse.json() as { text?: string };
    const transcript = transcription.text?.trim() ?? "";
    if (!transcript) return json({ status: "no_speech", transcript: "", matches: [] });

    const matches = rankQuranMatches(transcript, await getQuran(), 3);
    const reliableMatches = matches.filter((match) => match.confidence >= 38);
    if (!reliableMatches.length) {
      return json({ status: "no_match", transcript, matches });
    }

    return json({
      status: "matched",
      transcript,
      match: reliableMatches[0],
      matches,
      source: "Al Quran Cloud · quran-uthmani",
      model: "gpt-4o-mini-transcribe",
    });
  } catch (error) {
    const timedOut = error instanceof Error && (error.name === "TimeoutError" || error.name === "AbortError");
    return json({ error: timedOut ? "analysis_timeout" : "analysis_failed" }, timedOut ? 504 : 502);
  }
}
