import React from "react";
import { createRoot } from "react-dom/client";
import "./globals.css";
import RattilApp from "./rattil-app";

createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <RattilApp />
  </React.StrictMode>,
);
