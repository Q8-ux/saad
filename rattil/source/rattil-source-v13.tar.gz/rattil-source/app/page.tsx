import RattilApp from "./rattil-app";

export default function Home() {
  return <RattilApp />;
}
