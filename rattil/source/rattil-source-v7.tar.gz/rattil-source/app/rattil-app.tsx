"use client";

import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  BookMarked,
  BookOpen,
  Brain,
  CalendarDays,
  Check,
  CircleAlert,
  Clock3,
  EyeOff,
  Gauge,
  Headphones,
  Heart,
  Languages,
  ListChecks,
  Menu,
  Mic2,
  Moon,
  Pause,
  Play,
  RefreshCw,
  Repeat2,
  Search,
  ShieldCheck,
  Shuffle,
  Sparkles,
  Square,
  Star,
  Sun,
  Target,
  Trash2,
  TrendingUp,
  UserRound,
  Volume2,
  X,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { FaWhatsapp } from "react-icons/fa6";
import {
  type FormEvent,
  type ReactNode,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

type Lang = "ar" | "en" | "fr" | "es" | "tr" | "ur";
type View =
  | "home"
  | "mushaf"
  | "session"
  | "review"
  | "tasmee"
  | "plan"
  | "similar"
  | "progress"
  | "sources"
  | "signup";
type ProgressStatus = "new" | "learning" | "needs_review" | "memorized" | "mastered";

interface Surah {
  number: number;
  name: string;
  numberOfAyahs: number;
  revelationType: "Meccan" | "Medinan";
}

interface Ayah {
  number: number;
  numberInSurah: number;
  text: string;
}

interface SurahPayload extends Surah {
  ayahs: Ayah[];
}

interface ProgressRecord {
  ayahKey: string;
  surahNumber: number;
  surahName: string;
  ayahNumber: number;
  ayahGlobalNumber: number;
  text: string;
  status: ProgressStatus;
  lastReviewedAt: string | null;
  nextReviewAt: string;
  correctStreak: number;
  mistakesCount: number;
  totalReviews: number;
  isDifficult: boolean;
}

interface Reciter {
  id: string;
  nameAr: string;
  nameEn: string;
  bitrate: number;
}

interface PlayerTrack {
  url: string;
  title: string;
  subtitle: string;
  repeat: number;
  remaining: number;
  gap: number;
}

interface AiMatch {
  ayahGlobalNumber: number;
  ayahNumber: number;
  endAyahNumber: number;
  surahNumber: number;
  surahName: string;
  text: string;
  confidence: number;
}

interface AiAnalysisResult {
  status: "matched" | "no_match" | "no_speech";
  transcript: string;
  match?: AiMatch;
  matches: AiMatch[];
}

const API_BASE = "https://api.alquran.cloud/v1";
const CDN_BASE = "https://cdn.islamic.network/quran";
const RECORDS_KEY = "rattil_progress_v2";
const PROFILE_KEY = "rattil_profile_v2";
const LANG_KEY = "rattil_lang";
const RECITER_KEY = "rattil_reciter";

const LANGUAGE_OPTIONS: Array<{ code: Lang; nativeName: string; shortName: string }> = [
  { code: "ar", nativeName: "العربية", shortName: "ع" },
  { code: "en", nativeName: "English", shortName: "EN" },
  { code: "fr", nativeName: "Français", shortName: "FR" },
  { code: "es", nativeName: "Español", shortName: "ES" },
  { code: "tr", nativeName: "Türkçe", shortName: "TR" },
  { code: "ur", nativeName: "اردو", shortName: "اردو" },
];

const RTL_LANGS = new Set<Lang>(["ar", "ur"]);

const RECITERS: Reciter[] = [
  { id: "ar.husary", nameAr: "محمود خليل الحصري", nameEn: "Mahmoud Al-Husary", bitrate: 128 },
  { id: "ar.minshawi", nameAr: "محمد صديق المنشاوي", nameEn: "Mohamed Al-Minshawi", bitrate: 128 },
  { id: "ar.abdurrahmaansudais", nameAr: "عبدالرحمن السديس", nameEn: "Abdul Rahman Al-Sudais", bitrate: 192 },
];

const SURAH_NAMES_AR = [
  "الفاتحة",
  "البقرة",
  "آل عمران",
  "النساء",
  "المائدة",
  "الأنعام",
  "الأعراف",
  "الأنفال",
  "التوبة",
  "يونس",
  "هود",
  "يوسف",
  "الرعد",
  "إبراهيم",
  "الحجر",
  "النحل",
  "الإسراء",
  "الكهف",
  "مريم",
  "طه",
  "الأنبياء",
  "الحج",
  "المؤمنون",
  "النور",
  "الفرقان",
  "الشعراء",
  "النمل",
  "القصص",
  "العنكبوت",
  "الروم",
  "لقمان",
  "السجدة",
  "الأحزاب",
  "سبأ",
  "فاطر",
  "يس",
  "الصافات",
  "ص",
  "الزمر",
  "غافر",
  "فصلت",
  "الشورى",
  "الزخرف",
  "الدخان",
  "الجاثية",
  "الأحقاف",
  "محمد",
  "الفتح",
  "الحجرات",
  "ق",
  "الذاريات",
  "الطور",
  "النجم",
  "القمر",
  "الرحمن",
  "الواقعة",
  "الحديد",
  "المجادلة",
  "الحشر",
  "الممتحنة",
  "الصف",
  "الجمعة",
  "المنافقون",
  "التغابن",
  "الطلاق",
  "التحريم",
  "الملك",
  "القلم",
  "الحاقة",
  "المعارج",
  "نوح",
  "الجن",
  "المزمل",
  "المدثر",
  "القيامة",
  "الإنسان",
  "المرسلات",
  "النبأ",
  "النازعات",
  "عبس",
  "التكوير",
  "الانفطار",
  "المطففين",
  "الانشقاق",
  "البروج",
  "الطارق",
  "الأعلى",
  "الغاشية",
  "الفجر",
  "البلد",
  "الشمس",
  "الليل",
  "الضحى",
  "الشرح",
  "التين",
  "العلق",
  "القدر",
  "البينة",
  "الزلزلة",
  "العاديات",
  "القارعة",
  "التكاثر",
  "العصر",
  "الهمزة",
  "الفيل",
  "قريش",
  "الماعون",
  "الكوثر",
  "الكافرون",
  "النصر",
  "المسد",
  "الإخلاص",
  "الفلق",
  "الناس",
] as const;

const FALLBACK_SURAH: SurahPayload = {
  number: 55,
  name: "الرحمن",
  numberOfAyahs: 78,
  revelationType: "Medinan",
  ayahs: [
    { number: 4901, numberInSurah: 1, text: "ٱلرَّحۡمَٰنُ" },
    { number: 4902, numberInSurah: 2, text: "عَلَّمَ ٱلۡقُرۡءَانَ" },
    { number: 4903, numberInSurah: 3, text: "خَلَقَ ٱلۡإِنسَٰنَ" },
    { number: 4904, numberInSurah: 4, text: "عَلَّمَهُ ٱلۡبَيَانَ" },
    { number: 4905, numberInSurah: 5, text: "ٱلشَّمۡسُ وَٱلۡقَمَرُ بِحُسۡبَانٖ" },
  ],
};

const COPY = {
  ar: {
    home: "الرئيسية",
    mushaf: "المصحف",
    session: "جلسة الحفظ",
    review: "المراجعة",
    tasmee: "التسميع",
    plan: "الخطة اليومية",
    similar: "المتشابهات",
    progress: "تقدّمي",
    sources: "المصادر",
    signup: "حسابي",
    start: "ابدأ رحلتك",
    loading: "جارٍ التحميل…",
    retry: "إعادة المحاولة",
    listen: "استمع",
    read: "اقرأ",
    repeat: "كرّر",
    recite: "سمّع",
    revise: "راجع",
  },
  en: {
    home: "Home",
    mushaf: "Quran",
    session: "Memorize",
    review: "Review",
    tasmee: "Recitation",
    plan: "Daily plan",
    similar: "Similar verses",
    progress: "Progress",
    sources: "Sources",
    signup: "Profile",
    start: "Start your journey",
    loading: "Loading…",
    retry: "Try again",
    listen: "Listen",
    read: "Read",
    repeat: "Repeat",
    recite: "Recite",
    revise: "Review",
  },
  fr: {
    home: "Accueil",
    mushaf: "Coran",
    session: "Mémoriser",
    review: "Révision",
    tasmee: "Récitation",
    plan: "Programme quotidien",
    similar: "Versets similaires",
    progress: "Progression",
    sources: "Sources",
    signup: "Profil",
    start: "Commencer",
    loading: "Chargement…",
    retry: "Réessayer",
    listen: "Écouter",
    read: "Lire",
    repeat: "Répéter",
    recite: "Réciter",
    revise: "Réviser",
  },
  es: {
    home: "Inicio",
    mushaf: "Corán",
    session: "Memorizar",
    review: "Repaso",
    tasmee: "Recitación",
    plan: "Plan diario",
    similar: "Versículos similares",
    progress: "Progreso",
    sources: "Fuentes",
    signup: "Perfil",
    start: "Comenzar",
    loading: "Cargando…",
    retry: "Reintentar",
    listen: "Escuchar",
    read: "Leer",
    repeat: "Repetir",
    recite: "Recitar",
    revise: "Repasar",
  },
  tr: {
    home: "Ana sayfa",
    mushaf: "Kur’an",
    session: "Ezberle",
    review: "Tekrar",
    tasmee: "Okuma",
    plan: "Günlük plan",
    similar: "Benzer ayetler",
    progress: "İlerleme",
    sources: "Kaynaklar",
    signup: "Profil",
    start: "Başla",
    loading: "Yükleniyor…",
    retry: "Tekrar dene",
    listen: "Dinle",
    read: "Oku",
    repeat: "Tekrarla",
    recite: "Oku",
    revise: "Gözden geçir",
  },
  ur: {
    home: "مرکزی صفحہ",
    mushaf: "قرآن",
    session: "حفظ کریں",
    review: "دہرائی",
    tasmee: "تلاوت",
    plan: "روزانہ منصوبہ",
    similar: "ملتی جلتی آیات",
    progress: "میری پیش رفت",
    sources: "ذرائع",
    signup: "پروفائل",
    start: "سفر شروع کریں",
    loading: "لوڈ ہو رہا ہے…",
    retry: "دوبارہ کوشش کریں",
    listen: "سنیں",
    read: "پڑھیں",
    repeat: "دہرائیں",
    recite: "سنائیں",
    revise: "دہرائی کریں",
  },
} as const;

type SecondaryLang = "fr" | "es" | "tr" | "ur";
const SECONDARY_LANGUAGE_INDEX: Record<SecondaryLang, number> = { fr: 0, es: 1, tr: 2, ur: 3 };

// Each entry is ordered: French, Spanish, Turkish, Urdu.
const SECONDARY_TRANSLATIONS: Record<string, [string, string, string, string]> = {
  "Your daily Quran companion": ["Votre compagnon quotidien du Coran", "Tu compañero diario del Corán", "Günlük Kur’an yol arkadaşınız", "قرآن کے ساتھ آپ کا روزانہ ساتھی"],
  "Memorize the Quran": ["Mémorisez le Coran", "Memoriza el Corán", "Kur’an’ı ezberleyin", "قرآن حفظ کریں"],
  "at your own pace": ["à votre rythme", "a tu propio ritmo", "kendi hızınızda", "اپنی رفتار کے مطابق"],
  "Start memorizing": ["Commencer la mémorisation", "Empezar a memorizar", "Ezberlemeye başla", "حفظ شروع کریں"],
  "Explore the Quran": ["Explorer le Coran", "Explorar el Corán", "Kur’an’ı keşfet", "قرآن دیکھیں"],
  "Private by design": ["Confidentialité intégrée", "Privacidad por diseño", "Gizlilik odaklı", "رازداری کے ساتھ"],
  "Smart review": ["Révision intelligente", "Repaso inteligente", "Akıllı tekrar", "ذہین دہرائی"],
  "Trusted audio": ["Audio fiable", "Audio confiable", "Güvenilir ses", "معتبر تلاوت"],
  "Today’s portion": ["Part du jour", "Porción de hoy", "Bugünün bölümü", "آج کا سبق"],
  "In progress": ["En cours", "En curso", "Devam ediyor", "جاری ہے"],
  "Progress": ["Progression", "Progreso", "İlerleme", "پیش رفت"],
  "reviews": ["révisions", "repasos", "tekrar", "دہرائیاں"],
  "minutes": ["minutes", "minutos", "dakika", "منٹ"],
  "day streak": ["jours consécutifs", "días seguidos", "günlük seri", "مسلسل دن"],
  "Next review": ["Prochaine révision", "Próximo repaso", "Sonraki tekrar", "اگلی دہرائی"],
  "Today": ["Aujourd’hui", "Hoy", "Bugün", "آج"],
  "Weekly consistency": ["Régularité hebdomadaire", "Constancia semanal", "Haftalık düzen", "ہفتہ وار تسلسل"],
  "A clear method": ["Une méthode claire", "Un método claro", "Açık bir yöntem", "واضح طریقہ"],
  "Five steps for stronger memory": ["Cinq étapes pour mieux mémoriser", "Cinco pasos para una memoria más firme", "Daha güçlü ezber için beş adım", "مضبوط حفظ کے لیے پانچ مراحل"],
  "A short, guided session that moves you from listening to recall.": ["Une courte séance guidée, de l’écoute au rappel.", "Una sesión breve guiada que va de la escucha al recuerdo.", "Dinlemeden hatırlamaya uzanan kısa bir rehberli oturum.", "سننے سے یاد کرنے تک ایک مختصر رہنمائی سیشن۔"],
  "A calm journey, not a race": ["Un parcours serein, pas une course", "Un camino sereno, no una carrera", "Sakin bir yolculuk, yarış değil", "پرسکون سفر، مقابلہ نہیں"],
  "Mastery matters more than speed": ["La maîtrise compte plus que la vitesse", "El dominio importa más que la velocidad", "Ustalık hızdan önemlidir", "مہارت رفتار سے زیادہ اہم ہے"],
  "Practical tools to help you build a sustainable daily habit.": ["Des outils pratiques pour créer une habitude quotidienne durable.", "Herramientas prácticas para crear un hábito diario sostenible.", "Sürdürülebilir günlük alışkanlık için pratik araçlar.", "پائیدار روزانہ عادت بنانے کے عملی اوزار۔"],
  "Most impactful": ["Le plus utile", "Más impactante", "En etkili", "سب سے مؤثر"],
  "Explore tool": ["Découvrir l’outil", "Explorar herramienta", "Aracı keşfet", "آلہ دیکھیں"],
  "Everything in one place": ["Tout au même endroit", "Todo en un solo lugar", "Her şey tek yerde", "سب کچھ ایک جگہ"],
  "Daily tools for consistency": ["Des outils quotidiens pour rester régulier", "Herramientas diarias para mantener la constancia", "Devamlılık için günlük araçlar", "استقامت کے لیے روزانہ اوزار"],
  "Start today’s session": ["Commencer la séance du jour", "Empezar la sesión de hoy", "Bugünkü oturumu başlat", "آج کا سیشن شروع کریں"],
  "Read · listen · repeat": ["Lire · écouter · répéter", "Leer · escuchar · repetir", "Oku · dinle · tekrarla", "پڑھیں · سنیں · دہرائیں"],
  "The Holy Quran": ["Le Saint Coran", "El Sagrado Corán", "Kur’an-ı Kerim", "قرآنِ کریم"],
  "Choose a Surah and listen verse by verse with your preferred reciter.": ["Choisissez une sourate et écoutez chaque verset avec le récitateur de votre choix.", "Elige una sura y escucha cada aleya con tu recitador preferido.", "Bir sure seçin ve tercih ettiğiniz kâriden ayet ayet dinleyin.", "سورت منتخب کریں اور پسندیدہ قاری کی آواز میں آیت بہ آیت سنیں۔"],
  "Play full Surah": ["Lire toute la sourate", "Reproducir la sura completa", "Surenin tamamını oynat", "مکمل سورت چلائیں"],
  "Search Surah": ["Rechercher une sourate", "Buscar sura", "Sure ara", "سورت تلاش کریں"],
  "Type a Surah name…": ["Saisissez le nom d’une sourate…", "Escribe el nombre de una sura…", "Sure adını yazın…", "سورت کا نام لکھیں…"],
  "Surah": ["Sourate", "Sura", "Sure", "سورت"],
  "Reciter": ["Récitateur", "Recitador", "Kâri", "قاری"],
  "Reading tools": ["Outils de lecture", "Herramientas de lectura", "Okuma araçları", "پڑھنے کے اوزار"],
  "Larger text": ["Agrandir le texte", "Texto más grande", "Metni büyüt", "متن بڑا کریں"],
  "Smaller text": ["Réduire le texte", "Texto más pequeño", "Metni küçült", "متن چھوٹا کریں"],
  "Toggle verse numbers": ["Afficher les numéros de versets", "Mostrar números de aleyas", "Ayet numaralarını göster", "آیت نمبر دکھائیں"],
  "Night reading": ["Lecture nocturne", "Lectura nocturna", "Gece okuması", "رات کی قرأت"],
  "Verses": ["Versets", "Aleyas", "Ayetler", "آیات"],
  "Revelation": ["Révélation", "Revelación", "Nüzul", "نزول"],
  "Meccan": ["Mecquoise", "Mecana", "Mekkî", "مکی"],
  "Medinan": ["Médinoise", "Medinense", "Medenî", "مدنی"],
  "Surah could not load": ["Impossible de charger la sourate", "No se pudo cargar la sura", "Sure yüklenemedi", "سورت لوڈ نہیں ہو سکی"],
  "Check your connection and try again.": ["Vérifiez votre connexion et réessayez.", "Comprueba tu conexión e inténtalo de nuevo.", "Bağlantınızı kontrol edip tekrar deneyin.", "اپنا انٹرنیٹ چیک کر کے دوبارہ کوشش کریں۔"],
  "Play": ["Lire", "Reproducir", "Oynat", "چلائیں"],
  "Repeat 3×": ["Répéter 3×", "Repetir 3×", "3× tekrarla", "3× دہرائیں"],
  "Memorize": ["Mémoriser", "Memorizar", "Ezberle", "حفظ کریں"],
  "Review": ["Réviser", "Repasar", "Tekrar", "دہرائی"],
  "Difficult": ["Difficile", "Difícil", "Zor", "مشکل"],
  "Learn through recall": ["Apprendre par le rappel", "Aprender recordando", "Hatırlayarak öğren", "یاد کر کے سیکھیں"],
  "Follow each stage, then evaluate your recall honestly and gently.": ["Suivez chaque étape, puis évaluez votre rappel avec bienveillance.", "Sigue cada etapa y evalúa tu recuerdo con honestidad y calma.", "Her aşamayı izleyin, sonra hatırlamanızı dürüstçe değerlendirin.", "ہر مرحلہ مکمل کریں، پھر نرمی سے اپنی یادداشت کا جائزہ لیں۔"],
  "Change verse": ["Changer de verset", "Cambiar aleya", "Ayeti değiştir", "آیت تبدیل کریں"],
  "Verse": ["Verset", "Aleya", "Ayet", "آیت"],
  "Hide": ["Masquer", "Ocultar", "Gizle", "چھپائیں"],
  "Recall": ["Rappel", "Recordar", "Hatırla", "یاد کریں"],
  "Evaluate": ["Évaluer", "Evaluar", "Değerlendir", "جائزہ"],
  "The verse is hidden — recite it from memory": ["Le verset est masqué — récitez-le de mémoire", "La aleya está oculta — recítala de memoria", "Ayet gizli — ezberden okuyun", "آیت چھپی ہے — یاد سے سنائیں"],
  "Listen 3 times": ["Écouter 3 fois", "Escuchar 3 veces", "3 kez dinle", "3 بار سنیں"],
  "Next: Read": ["Suivant : lire", "Siguiente: leer", "Sonraki: Oku", "اگلا: پڑھیں"],
  "Reads": ["Lectures", "Lecturas", "Okuma", "پڑھنے کی تعداد"],
  "I read it": ["Je l’ai lu", "La he leído", "Okudum", "میں نے پڑھ لیا"],
  "Next: Hide": ["Suivant : masquer", "Siguiente: ocultar", "Sonraki: Gizle", "اگلا: چھپائیں"],
  "Hide more": ["Masquer davantage", "Ocultar más", "Daha fazlasını gizle", "مزید چھپائیں"],
  "Next: Recall": ["Suivant : rappel", "Siguiente: recordar", "Sonraki: Hatırla", "اگلا: یاد کریں"],
  "Record recitation": ["Enregistrer la récitation", "Grabar recitación", "Okumayı kaydet", "تلاوت ریکارڈ کریں"],
  "Reveal and evaluate": ["Afficher et évaluer", "Mostrar y evaluar", "Göster ve değerlendir", "دکھائیں اور جائزہ لیں"],
  "How was your recall?": ["Comment était votre rappel ?", "¿Cómo fue tu recuerdo?", "Hatırlamanız nasıldı?", "آپ کو کتنا یاد رہا؟"],
  "Needed help": ["Besoin d’aide", "Necesité ayuda", "Yardıma ihtiyaç duydum", "مدد کی ضرورت پڑی"],
  "One mistake": ["Une erreur", "Un error", "Bir hata", "ایک غلطی"],
  "Mastered": ["Maîtrisé", "Dominado", "Ustalaşıldı", "پختہ"],
  "Today’s reviews": ["Révisions du jour", "Repasos de hoy", "Bugünkü tekrarlar", "آج کی دہرائیاں"],
  "Review to retain": ["Réviser pour retenir", "Repasa para fijar", "Kalıcı olması için tekrarla", "مضبوطی کے لیے دہرائیں"],
  "Verses return when your memory is ready to retrieve them.": ["Les versets reviennent au moment opportun pour votre mémoire.", "Las aleyas vuelven cuando tu memoria necesita recuperarlas.", "Ayetler hatırlamanız gereken zamanda geri gelir.", "آیات مناسب وقت پر دوبارہ سامنے آتی ہیں۔"],
  "Random review": ["Révision aléatoire", "Repaso aleatorio", "Rastgele tekrar", "اتفاقی دہرائی"],
  "No reviews yet": ["Aucune révision pour le moment", "Aún no hay repasos", "Henüz tekrar yok", "ابھی کوئی دہرائی نہیں"],
  "Open Quran": ["Ouvrir le Coran", "Abrir el Corán", "Kur’an’ı aç", "قرآن کھولیں"],
  "Nothing here": ["Aucun verset ici", "No hay nada aquí", "Burada ayet yok", "یہاں کوئی آیت نہیں"],
  "Recall aloud": ["Réciter à voix haute", "Recordar en voz alta", "Sesli hatırla", "آواز سے سنائیں"],
  "Recording…": ["Enregistrement…", "Grabando…", "Kaydediliyor…", "ریکارڈنگ جاری ہے…"],
  "Hide the text, take a calm breath, then begin.": ["Masquez le texte, respirez calmement, puis commencez.", "Oculta el texto, respira con calma y comienza.", "Metni gizleyin, sakin bir nefes alın ve başlayın.", "متن چھپائیں، پرسکون سانس لیں، پھر شروع کریں۔"],
  "Stop recording": ["Arrêter l’enregistrement", "Detener grabación", "Kaydı durdur", "ریکارڈنگ روکیں"],
  "Start recording": ["Commencer l’enregistrement", "Iniciar grabación", "Kaydı başlat", "ریکارڈنگ شروع کریں"],
  "Recording complete — listen before evaluating yourself.": ["Enregistrement terminé — écoutez avant de vous évaluer.", "Grabación completa — escucha antes de evaluarte.", "Kayıt tamamlandı — değerlendirmeden önce dinleyin.", "ریکارڈنگ مکمل — جائزے سے پہلے سنیں۔"],
  "Delete recording": ["Supprimer l’enregistrement", "Eliminar grabación", "Kaydı sil", "ریکارڈنگ حذف کریں"],
  "Analyzing recording…": ["Analyse de l’enregistrement…", "Analizando grabación…", "Kayıt analiz ediliyor…", "ریکارڈنگ کا تجزیہ ہو رہا ہے…"],
  "Identify the verse with AI": ["Identifier le verset avec l’IA", "Identificar la aleya con IA", "Ayeti yapay zekâ ile bul", "AI سے آیت پہچانیں"],
  "Match result": ["Résultat de correspondance", "Resultado de coincidencia", "Eşleşme sonucu", "مماثلت کا نتیجہ"],
  "Heard text": ["Texte entendu", "Texto escuchado", "Duyulan metin", "سنا گیا متن"],
  "Match confidence": ["Fiabilité", "Confianza", "Eşleşme güveni", "مماثلت کا اعتماد"],
  "Play with the selected reciter": ["Lire avec le récitateur choisi", "Reproducir con el recitador elegido", "Seçilen kâriden oynat", "منتخب قاری کی آواز میں چلائیں"],
  "No clear speech was detected. Move closer to the microphone and try again.": ["Aucune parole claire détectée. Rapprochez-vous du microphone et réessayez.", "No se detectó voz clara. Acércate al micrófono e inténtalo de nuevo.", "Net ses algılanmadı. Mikrofona yaklaşıp tekrar deneyin.", "واضح آواز نہیں ملی۔ مائیک کے قریب ہو کر دوبارہ کوشش کریں۔"],
  "No reliable match was found. Try reciting one complete verse clearly.": ["Aucune correspondance fiable. Récitez clairement un verset complet.", "No se encontró una coincidencia fiable. Recita una aleya completa con claridad.", "Güvenilir eşleşme bulunamadı. Tam bir ayeti net okuyun.", "قابلِ اعتماد مماثلت نہیں ملی۔ ایک مکمل آیت واضح پڑھیں۔"],
  "This result is an aid, not a Tajweed assessment.": ["Ce résultat est une aide, pas une évaluation du tajwid.", "Este resultado es una ayuda, no una evaluación de taywid.", "Bu sonuç yardımcıdır, tecvid değerlendirmesi değildir.", "یہ نتیجہ مدد کے لیے ہے، تجوید کا فیصلہ نہیں۔"],
  "The matching verse was found and its recitation started.": ["Le verset correspondant a été trouvé et sa lecture a commencé.", "Se encontró la aleya y comenzó su reproducción.", "Eşleşen ayet bulundu ve okuma başladı.", "مماثل آیت مل گئی اور تلاوت شروع ہو گئی۔"],
  "Consistency over volume": ["La régularité avant la quantité", "La constancia antes que la cantidad", "Miktardan önce devamlılık", "مقدار سے بڑھ کر تسلسل"],
  "How many minutes today?": ["Combien de minutes aujourd’hui ?", "¿Cuántos minutos hoy?", "Bugün kaç dakika?", "آج کتنے منٹ؟"],
  "Your level": ["Votre niveau", "Tu nivel", "Seviyeniz", "آپ کی سطح"],
  "Beginner": ["Débutant", "Principiante", "Başlangıç", "ابتدائی"],
  "Intermediate": ["Intermédiaire", "Intermedio", "Orta", "درمیانی"],
  "Advanced": ["Avancé", "Avanzado", "İleri", "اعلیٰ"],
  "Where to begin?": ["Où commencer ?", "¿Dónde empezar?", "Nereden başlamalı?", "کہاں سے شروع کریں؟"],
  "Juz Amma": ["Juz Amma", "Yuz Amma", "Amme Cüzü", "جزء عمّ"],
  "A chosen Surah": ["Une sourate choisie", "Una sura elegida", "Seçtiğim sure", "منتخب سورت"],
  "From the beginning": ["Depuis le début", "Desde el principio", "Baştan", "شروعِ قرآن سے"],
  "Continue previous work": ["Continuer la mémorisation", "Continuar trabajo anterior", "Önceki ezbere devam", "پچھلا حفظ جاری رکھیں"],
  "Build today’s plan": ["Créer le programme du jour", "Crear el plan de hoy", "Bugünkü planı oluştur", "آج کا منصوبہ بنائیں"],
  "Total session": ["Durée totale", "Sesión total", "Toplam oturum", "کل سیشن"],
  "Start plan": ["Commencer le programme", "Iniciar plan", "Planı başlat", "منصوبہ شروع کریں"],
  "Practice confusing places": ["S’entraîner aux passages proches", "Practicar pasajes similares", "Karışan yerleri çalış", "ملتے مقامات کی مشق"],
  "Coming soon": ["Bientôt", "Próximamente", "Yakında", "جلد آرہا ہے"],
  "A steady step every day": ["Un pas régulier chaque jour", "Un paso constante cada día", "Her gün istikrarlı bir adım", "ہر دن ایک مستقل قدم"],
  "Last seven days": ["Sept derniers jours", "Últimos siete días", "Son yedi gün", "گزشتہ سات دن"],
  "Review rhythm": ["Rythme des révisions", "Ritmo de repaso", "Tekrar ritmi", "دہرائی کی رفتار"],
  "Quran map": ["Carte du Coran", "Mapa del Corán", "Kur’an haritası", "قرآن نقشہ"],
  "Not started": ["Non commencé", "No iniciado", "Başlanmadı", "شروع نہیں ہوا"],
  "Learning": ["En apprentissage", "Aprendiendo", "Öğreniliyor", "زیرِ حفظ"],
  "Transparency first": ["La transparence d’abord", "La transparencia primero", "Önce şeffaflık", "شفافیت پہلے"],
  "Visit source": ["Visiter la source", "Visitar fuente", "Kaynağı ziyaret et", "ذریعہ دیکھیں"],
  "Methodological note": ["Note méthodologique", "Nota metodológica", "Yöntem notu", "طریقۂ کار کا نوٹ"],
  "Your journey settings": ["Paramètres de votre parcours", "Ajustes de tu recorrido", "Yolculuk ayarları", "آپ کے سفر کی ترتیبات"],
  "Name": ["Nom", "Nombre", "Ad", "نام"],
  "Email (optional)": ["E-mail (facultatif)", "Correo (opcional)", "E-posta (isteğe bağlı)", "ای میل (اختیاری)"],
  "Country": ["Pays", "País", "Ülke", "ملک"],
  "My Quran goal": ["Mon objectif avec le Coran", "Mi meta con el Corán", "Kur’an hedefim", "قرآن کے ساتھ میرا ہدف"],
  "Save settings": ["Enregistrer", "Guardar ajustes", "Ayarları kaydet", "ترتیبات محفوظ کریں"],
  "Saved on this device.": ["Enregistré sur cet appareil.", "Guardado en este dispositivo.", "Bu cihaza kaydedildi.", "اس آلے پر محفوظ ہو گیا۔"],
  "Your privacy matters": ["Votre vie privée compte", "Tu privacidad importa", "Gizliliğiniz önemli", "آپ کی رازداری اہم ہے"],
  "Begin with what you can sustain.": ["Commencez par ce que vous pouvez maintenir.", "Empieza con lo que puedas mantener.", "Sürdürebileceğiniz kadar başlayın.", "اتنا شروع کریں جتنا مستقل کر سکیں۔"],
  "Back home": ["Retour à l’accueil", "Volver al inicio", "Ana sayfaya dön", "مرکزی صفحے پر واپس"],
  "Main navigation": ["Navigation principale", "Navegación principal", "Ana gezinme", "مرکزی نیویگیشن"],
  "Mobile navigation": ["Navigation mobile", "Navegación móvil", "Mobil gezinme", "موبائل نیویگیشن"],
  "Open menu": ["Ouvrir le menu", "Abrir menú", "Menüyü aç", "مینو کھولیں"],
  "Close menu": ["Fermer le menu", "Cerrar menú", "Menüyü kapat", "مینو بند کریں"],
  "Pause": ["Pause", "Pausa", "Duraklat", "روکیں"],
  "Playback progress": ["Progression de lecture", "Progreso de reproducción", "Oynatma ilerlemesi", "چلنے کی پیش رفت"],
  "Volume": ["Volume", "Volumen", "Ses", "آواز"],
  "Close player": ["Fermer le lecteur", "Cerrar reproductor", "Oynatıcıyı kapat", "پلیئر بند کریں"],
  "Short pause… prepare to repeat": ["Courte pause… préparez-vous à répéter", "Pausa breve… prepárate para repetir", "Kısa ara… tekrara hazırlanın", "مختصر وقفہ… دہرائی کے لیے تیار ہوں"],
  "Rattil": ["Rattil", "Rattil", "Rattil", "رَتِّل"],
  "AI analysis is not configured yet.": ["L’analyse IA n’est pas encore configurée.", "El análisis de IA aún no está configurado.", "Yapay zekâ analizi henüz yapılandırılmadı.", "AI تجزیہ ابھی تیار نہیں۔"],
  "The analysis service is busy. Please try again shortly.": ["Le service d’analyse est occupé. Réessayez dans un instant.", "El servicio de análisis está ocupado. Inténtalo de nuevo en breve.", "Analiz hizmeti meşgul. Kısa süre sonra tekrar deneyin.", "تجزیہ سروس مصروف ہے۔ کچھ دیر بعد کوشش کریں۔"],
  "The recording is too large. Record a clip shorter than two minutes.": ["L’enregistrement est trop volumineux. Enregistrez moins de deux minutes.", "La grabación es demasiado grande. Graba menos de dos minutos.", "Kayıt çok büyük. İki dakikadan kısa kaydedin.", "ریکارڈنگ بہت بڑی ہے۔ دو منٹ سے کم ریکارڈ کریں۔"],
  "This recording format is not supported.": ["Ce format audio n’est pas pris en charge.", "Este formato de audio no es compatible.", "Bu kayıt biçimi desteklenmiyor.", "یہ ریکارڈنگ فارمیٹ معاون نہیں۔"],
  "Analysis took too long. Try a shorter clip.": ["L’analyse a pris trop de temps. Essayez un extrait plus court.", "El análisis tardó demasiado. Prueba con un clip más corto.", "Analiz çok uzun sürdü. Daha kısa bir kayıt deneyin.", "تجزیے میں زیادہ وقت لگا۔ مختصر ریکارڈنگ آزمائیں۔"],
  "The recording could not be analyzed. Please try again.": ["Impossible d’analyser l’enregistrement. Réessayez.", "No se pudo analizar la grabación. Inténtalo de nuevo.", "Kayıt analiz edilemedi. Tekrar deneyin.", "ریکارڈنگ کا تجزیہ نہیں ہو سکا۔ دوبارہ کوشش کریں۔"],
  "Recording is not supported in this browser.": ["L’enregistrement n’est pas pris en charge par ce navigateur.", "La grabación no es compatible con este navegador.", "Bu tarayıcıda kayıt desteklenmiyor.", "اس براؤزر میں ریکارڈنگ معاون نہیں۔"],
  "Microphone access was not granted.": ["L’accès au microphone n’a pas été autorisé.", "No se concedió acceso al micrófono.", "Mikrofon erişimi verilmedi.", "مائیکروفون کی اجازت نہیں ملی۔"],
  "Delete this recording? It cannot be recovered after deletion.": ["Supprimer cet enregistrement ? Il sera irrécupérable.", "¿Eliminar esta grabación? No podrá recuperarse.", "Bu kayıt silinsin mi? Geri alınamaz.", "یہ ریکارڈنگ حذف کریں؟ بعد میں واپس نہیں آئے گی۔"],
  "Recording deleted.": ["Enregistrement supprimé.", "Grabación eliminada.", "Kayıt silindi.", "ریکارڈنگ حذف ہو گئی۔"],
};

const NAV_ITEMS: Array<{ id: View; icon: typeof BookOpen }> = [
  { id: "home", icon: BookOpen },
  { id: "mushaf", icon: BookMarked },
  { id: "session", icon: Target },
  { id: "review", icon: RefreshCw },
  { id: "plan", icon: CalendarDays },
  { id: "progress", icon: BarChart3 },
];

const HOME_STEPS = [
  { icon: Headphones, key: "listen" as const, ar: "لتلاوة متقنة", en: "to a precise recitation" },
  { icon: BookOpen, key: "read" as const, ar: "بتدبّر وتركيز", en: "with focus" },
  { icon: Repeat2, key: "repeat" as const, ar: "حتى يثبت اللفظ", en: "until it settles" },
  { icon: Mic2, key: "recite" as const, ar: "من ذاكرتك", en: "from memory" },
  { icon: RefreshCw, key: "revise" as const, ar: "في الوقت المناسب", en: "at the right time" },
];

const METHOD_CARDS = [
  {
    icon: Brain,
    titleAr: "حفظ نشط",
    titleEn: "Active recall",
    textAr: "لا تكتفِ بالنظر المتكرر؛ أخفِ الآية وحاول استرجاعها من ذاكرتك.",
    textEn: "Hide the verse and retrieve it from memory instead of only rereading it.",
  },
  {
    icon: RefreshCw,
    titleAr: "مراجعة متباعدة",
    titleEn: "Spaced review",
    textAr: "تعود إليك الآيات قبل أن يضعف حفظها، وفق مواعيد مراجعة متدرجة.",
    textEn: "Verses return before memory fades, following a gradual review schedule.",
  },
  {
    icon: TrendingUp,
    titleAr: "تقدّم واضح",
    titleEn: "Clear progress",
    textAr: "تابع ما حفظته، وما أتقنته، والمواضع التي تحتاج منك عناية أكبر.",
    textEn: "See what you memorized, mastered, and what needs more attention.",
  },
];

const SOURCE_ITEMS = [
  {
    name: "OpenAI Speech to Text",
    url: "https://developers.openai.com/api/docs/guides/speech-to-text",
    ar: "تُستخدم لتحويل تسجيل التسميع إلى كلمات عربية قبل مطابقتها مع نص المصحف، ولا تُستخدم للحكم على التجويد.",
    en: "Used to transcribe the recitation recording before matching it against Quran text; it does not grade Tajweed.",
  },
  {
    name: "Al Quran Cloud",
    url: "https://alquran.cloud/",
    ar: "واجهة مفتوحة لبيانات السور والآيات بالرسم العثماني.",
    en: "Open API for Surah and Uthmani verse data.",
  },
  {
    name: "Al Quran Cloud CDN",
    url: "https://alquran.cloud/cdn",
    ar: "المصدر المستخدم لتشغيل تلاوات القرّاء على مستوى الآية والسورة.",
    en: "The audio source used for verse and full-Surah recitations.",
  },
  {
    name: "Tanzil",
    url: "https://tanzil.net/",
    ar: "مشروع رقمي معروف بنص قرآني دقيق ومراجع.",
    en: "A reviewed and accurate digital Quran text project.",
  },
  {
    name: "Quran.com",
    url: "https://quran.com/ar",
    ar: "مرجع للقراءة والاستماع والترجمات والتفاسير.",
    en: "A reference for reading, listening, translations and tafsir.",
  },
  {
    name: "Quranic Arabic Corpus",
    url: "https://corpus.quran.com/",
    ar: "مصدر أكاديمي للتحليل الصرفي والنحوي للمفردات القرآنية.",
    en: "An academic source for Quranic morphology and grammar.",
  },
  {
    name: "Quran Foundation Developers",
    url: "https://quran.com/developers",
    ar: "مرجع تقني للتكاملات المستقبلية مع محتوى القرآن.",
    en: "A technical reference for future Quran content integrations.",
  },
];

function arabicDigits(value: number | string, lang: Lang) {
  if (lang !== "ar" && lang !== "ur") return String(value);
  return String(value).replace(/\d/g, (digit) => "٠١٢٣٤٥٦٧٨٩"[Number(digit)]);
}

function classNames(...values: Array<string | false | null | undefined>) {
  return values.filter(Boolean).join(" ");
}

function safeParseRecords(raw: string | null): Record<string, ProgressRecord> {
  if (!raw) return {};
  try {
    return JSON.parse(raw) as Record<string, ProgressRecord>;
  } catch {
    return {};
  }
}

function statusText(status: ProgressStatus, lang: Lang) {
  const labels = {
    new: { ar: "جديدة", en: "New", fr: "Nouveau", es: "Nueva", tr: "Yeni", ur: "نئی" },
    learning: { ar: "قيد التعلّم", en: "Learning", fr: "En apprentissage", es: "Aprendiendo", tr: "Öğreniliyor", ur: "زیرِ حفظ" },
    needs_review: { ar: "تحتاج مراجعة", en: "Needs review", fr: "À réviser", es: "Necesita repaso", tr: "Tekrar gerekli", ur: "دہرائی درکار" },
    memorized: { ar: "محفوظة", en: "Memorized", fr: "Mémorisé", es: "Memorizada", tr: "Ezberlendi", ur: "حفظ شدہ" },
    mastered: { ar: "متقنة", en: "Mastered", fr: "Maîtrisé", es: "Dominada", tr: "Pekişti", ur: "پختہ" },
  };
  return labels[status][lang];
}

function EmptyState({ icon, title, text, action }: { icon: ReactNode; title: string; text: string; action?: ReactNode }) {
  return (
    <div className="empty-state">
      <span>{icon}</span>
      <h3>{title}</h3>
      <p>{text}</p>
      {action}
    </div>
  );
}

export default function RattilApp() {
  const [lang, setLang] = useState<Lang>("ar");
  const [activeView, setActiveView] = useState<View>("home");
  const [menuOpen, setMenuOpen] = useState(false);
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [selectedSurah, setSelectedSurah] = useState(55);
  const [currentSurah, setCurrentSurah] = useState<SurahPayload>(FALLBACK_SURAH);
  const [search, setSearch] = useState("");
  const [quranLoading, setQuranLoading] = useState(true);
  const [quranError, setQuranError] = useState(false);
  const [fontSize, setFontSize] = useState(31);
  const [showNumbers, setShowNumbers] = useState(true);
  const [nightReading, setNightReading] = useState(false);
  const [reciterId, setReciterId] = useState(RECITERS[0].id);
  const [records, setRecords] = useState<Record<string, ProgressRecord>>({});
  const [storageReady, setStorageReady] = useState(false);
  const [toast, setToast] = useState("");

  const [sessionAyah, setSessionAyah] = useState<Ayah>(FALLBACK_SURAH.ayahs[0]);
  const [sessionSurah, setSessionSurah] = useState<Pick<Surah, "number" | "name">>({
    number: FALLBACK_SURAH.number,
    name: FALLBACK_SURAH.name,
  });
  const [sessionPhase, setSessionPhase] = useState(1);
  const [readCount, setReadCount] = useState(0);
  const [hideLevel, setHideLevel] = useState(1);

  const [planMinutes, setPlanMinutes] = useState(20);
  const [planLevel, setPlanLevel] = useState("beginner");
  const [planStart, setPlanStart] = useState("amma");
  const [planGenerated, setPlanGenerated] = useState(false);

  const [recording, setRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [recordingUrl, setRecordingUrl] = useState("");
  const [recordingError, setRecordingError] = useState("");
  const [analysisLoading, setAnalysisLoading] = useState(false);
  const [analysisError, setAnalysisError] = useState("");
  const [analysisResult, setAnalysisResult] = useState<AiAnalysisResult | null>(null);

  const [profile, setProfile] = useState({ name: "", email: "", country: "", goal: "" });
  const [profileSaved, setProfileSaved] = useState(false);

  const [playerTrack, setPlayerTrack] = useState<PlayerTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playerProgress, setPlayerProgress] = useState(0);
  const [playerVolume, setPlayerVolume] = useState(1);
  const [gapActive, setGapActive] = useState(false);
  const [chapterQueue, setChapterQueue] = useState<{ surahName: string; ayahs: Ayah[] } | null>(null);
  const [chapterQueueIndex, setChapterQueueIndex] = useState(0);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const recordingTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingBlobRef = useRef<Blob | null>(null);
  const playerGapTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const t = COPY[lang];
  const isRtl = RTL_LANGS.has(lang);
  const tx = (arabic: string, english: string) => {
    if (lang === "ar") return arabic;
    if (lang === "en") return english;
    return SECONDARY_TRANSLATIONS[english]?.[SECONDARY_LANGUAGE_INDEX[lang]] ?? english;
  };
  const selectedReciter = RECITERS.find((item) => item.id === reciterId) ?? RECITERS[0];

  const notify = useCallback((message: string) => {
    setToast(message);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToast(""), 2600);
  }, []);

  useEffect(() => {
    const savedLang = localStorage.getItem(LANG_KEY);
    if (LANGUAGE_OPTIONS.some((language) => language.code === savedLang)) setLang(savedLang as Lang);
    const savedReciter = localStorage.getItem(RECITER_KEY);
    if (savedReciter === "ar.sudais") {
      const currentSudaisId = "ar.abdurrahmaansudais";
      setReciterId(currentSudaisId);
      localStorage.setItem(RECITER_KEY, currentSudaisId);
    } else if (RECITERS.some((reciter) => reciter.id === savedReciter)) {
      setReciterId(savedReciter as string);
    } else {
      localStorage.setItem(RECITER_KEY, RECITERS[0].id);
    }
    setRecords(safeParseRecords(localStorage.getItem(RECORDS_KEY)));
    const savedProfile = localStorage.getItem(PROFILE_KEY);
    if (savedProfile) {
      try {
        setProfile(JSON.parse(savedProfile));
      } catch {
        // Keep the empty profile when legacy data is malformed.
      }
    }
    setStorageReady(true);
  }, []);

  useEffect(() => {
    if (!storageReady) return;
    localStorage.setItem(RECORDS_KEY, JSON.stringify(records));
  }, [records, storageReady]);

  useEffect(() => {
    localStorage.setItem(LANG_KEY, lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = isRtl ? "rtl" : "ltr";
  }, [lang, isRtl]);

  useEffect(() => {
    localStorage.setItem(RECITER_KEY, reciterId);
  }, [reciterId]);

  const loadSurahs = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE}/surah`);
      if (!response.ok) throw new Error("surah-list");
      const payload = (await response.json()) as { data: Surah[] };
      setSurahs(payload.data.map((surah) => ({
        number: surah.number,
        name: SURAH_NAMES_AR[surah.number - 1] ?? surah.name,
        numberOfAyahs: surah.numberOfAyahs,
        revelationType: surah.revelationType,
      })));
    } catch {
      setQuranError(true);
    }
  }, []);

  const loadSurah = useCallback(async (surahNumber: number) => {
    setQuranLoading(true);
    setQuranError(false);
    try {
      const response = await fetch(`${API_BASE}/surah/${surahNumber}/quran-uthmani`);
      if (!response.ok) throw new Error("surah");
      const payload = (await response.json()) as { data: SurahPayload };
      setCurrentSurah({
        number: payload.data.number,
        name: SURAH_NAMES_AR[payload.data.number - 1] ?? payload.data.name,
        numberOfAyahs: payload.data.numberOfAyahs,
        revelationType: payload.data.revelationType,
        ayahs: payload.data.ayahs,
      });
    } catch {
      setQuranError(true);
      if (surahNumber === 55) setCurrentSurah(FALLBACK_SURAH);
    } finally {
      setQuranLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSurahs();
    loadSurah(55);
  }, [loadSurah, loadSurahs]);

  useEffect(() => {
    return () => {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      if (playerGapTimerRef.current) clearTimeout(playerGapTimerRef.current);
      mediaStreamRef.current?.getTracks().forEach((track) => track.stop());
      if (recordingUrl) URL.revokeObjectURL(recordingUrl);
    };
  }, [recordingUrl]);

  const changeView = (view: View) => {
    setActiveView(view);
    setMenuOpen(false);
    if (view === "session" && !sessionAyah) {
      setSessionAyah(currentSurah.ayahs[0] ?? FALLBACK_SURAH.ayahs[0]);
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const chooseSurah = (number: number) => {
    setSelectedSurah(number);
    loadSurah(number);
  };

  const filteredSurahs = useMemo(() => {
    const query = search.trim().toLocaleLowerCase();
    if (!query) return surahs;
    return surahs.filter((surah) =>
      `${surah.name} ${surah.number}`.toLocaleLowerCase().includes(query),
    );
  }, [search, surahs]);

  const playTrack = (url: string, title: string, subtitle: string, repeat = 1, gap = 2, preserveChapterQueue = false) => {
    if (!preserveChapterQueue) {
      setChapterQueue(null);
      setChapterQueueIndex(0);
    }
    const nextTrack = { url, title, subtitle, repeat, remaining: repeat, gap };
    setPlayerTrack(nextTrack);
    setGapActive(false);
    const audio = audioRef.current;
    if (!audio) return;
    audio.src = url;
    audio.volume = playerVolume;
    audio.load();
    audio
      .play()
      .then(() => setIsPlaying(true))
      .catch(() => {
        if (!preserveChapterQueue) {
          notify(tx("تعذّر تشغيل التلاوة. تحقق من الاتصال وحاول مجددًا.", "Audio could not play. Check your connection."));
        }
      });
  };

  const playAyah = (ayah: Ayah, repeat = 1) => {
    const url = `${CDN_BASE}/audio/${selectedReciter.bitrate}/${selectedReciter.id}/${ayah.number}.mp3`;
    playTrack(
      url,
      `${currentSurah.name} · ${tx("الآية", "Verse")} ${arabicDigits(ayah.numberInSurah, lang)}`,
      isRtl ? selectedReciter.nameAr : selectedReciter.nameEn,
      repeat,
      repeat > 1 ? 2 : 0,
    );
  };

  const playFullSurah = () => {
    if (!currentSurah.ayahs.length) {
      notify(tx("تعذّر العثور على آيات السورة.", "No verses were found for this Surah."));
      return;
    }
    const firstAyah = currentSurah.ayahs[0];
    setChapterQueue({ surahName: currentSurah.name, ayahs: currentSurah.ayahs });
    setChapterQueueIndex(0);
    playTrack(
      `${CDN_BASE}/audio/${selectedReciter.bitrate}/${selectedReciter.id}/${firstAyah.number}.mp3`,
      `${currentSurah.name} · ${tx("الآية", "Verse")} ${arabicDigits(firstAyah.numberInSurah, lang)}`,
      `${tx("تشغيل السورة كاملة · ", "Full Surah · ")}${isRtl ? selectedReciter.nameAr : selectedReciter.nameEn}`,
      1,
      0,
      true,
    );
  };

  const togglePlayer = () => {
    const audio = audioRef.current;
    if (!audio || !playerTrack) return;
    if (audio.paused) {
      audio.play().then(() => setIsPlaying(true)).catch(() => notify(tx("تعذّر تشغيل الصوت.", "Audio could not play.")));
    } else {
      audio.pause();
      setIsPlaying(false);
    }
  };

  const closePlayer = () => {
    const audio = audioRef.current;
    audio?.pause();
    if (audio) audio.removeAttribute("src");
    setPlayerTrack(null);
    setIsPlaying(false);
    setPlayerProgress(0);
    setChapterQueue(null);
    setChapterQueueIndex(0);
  };

  const playNextChapterAyah = () => {
    if (!chapterQueue) return false;
    const nextIndex = chapterQueueIndex + 1;
    if (nextIndex >= chapterQueue.ayahs.length) {
      setChapterQueue(null);
      setChapterQueueIndex(0);
      setIsPlaying(false);
      setPlayerProgress(100);
      notify(tx("اكتمل تشغيل السورة.", "Surah playback completed."));
      return false;
    }
    const nextAyah = chapterQueue.ayahs[nextIndex];
    setChapterQueueIndex(nextIndex);
    playTrack(
      `${CDN_BASE}/audio/${selectedReciter.bitrate}/${selectedReciter.id}/${nextAyah.number}.mp3`,
      `${chapterQueue.surahName} · ${tx("الآية", "Verse")} ${arabicDigits(nextAyah.numberInSurah, lang)}`,
      `${tx("تشغيل السورة كاملة · ", "Full Surah · ")}${isRtl ? selectedReciter.nameAr : selectedReciter.nameEn}`,
      1,
      0,
      true,
    );
    return true;
  };

  const handleAudioEnded = () => {
    if (!playerTrack || !audioRef.current) return;
    if (playerTrack.remaining > 1) {
      setPlayerTrack((track) => (track ? { ...track, remaining: track.remaining - 1 } : null));
      setGapActive(true);
      playerGapTimerRef.current = setTimeout(() => {
        if (!audioRef.current) return;
        setGapActive(false);
        audioRef.current.currentTime = 0;
        audioRef.current.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
      }, playerTrack.gap * 1000);
      return;
    }
    if (!playNextChapterAyah()) {
      setIsPlaying(false);
      setPlayerProgress(100);
    }
  };

  const updatePlayerProgress = () => {
    const audio = audioRef.current;
    if (!audio || !Number.isFinite(audio.duration) || audio.duration <= 0) return;
    setPlayerProgress((audio.currentTime / audio.duration) * 100);
  };

  const baseRecord = (ayah: Ayah): ProgressRecord => ({
    ayahKey: `${currentSurah.number}:${ayah.numberInSurah}`,
    surahNumber: currentSurah.number,
    surahName: currentSurah.name,
    ayahNumber: ayah.numberInSurah,
    ayahGlobalNumber: ayah.number,
    text: ayah.text,
    status: "new",
    lastReviewedAt: null,
    nextReviewAt: new Date().toISOString(),
    correctStreak: 0,
    mistakesCount: 0,
    totalReviews: 0,
    isDifficult: false,
  });

  const markAyah = (ayah: Ayah, status: ProgressStatus, difficult = false) => {
    const key = `${currentSurah.number}:${ayah.numberInSurah}`;
    setRecords((previous) => {
      const record = previous[key] ?? baseRecord(ayah);
      return { ...previous, [key]: { ...record, status, isDifficult: difficult || record.isDifficult } };
    });
    notify(
      difficult
        ? tx("وُسمت الآية كموضع يحتاج عناية.", "Verse marked as difficult.")
        : status === "needs_review"
          ? tx("أُضيفت إلى المراجعة.", "Added to review.")
          : tx("أُضيفت إلى الحفظ.", "Added to memorization."),
    );
  };

  const beginSession = (ayah: Ayah, surah: Pick<Surah, "number" | "name"> = currentSurah) => {
    setSessionAyah(ayah);
    setSessionSurah({ number: surah.number, name: surah.name });
    setSessionPhase(1);
    setReadCount(0);
    setHideLevel(1);
    changeView("session");
  };

  const recordEvaluation = (result: "help" | "mistake" | "mastered") => {
    const key = `${sessionSurah.number}:${sessionAyah.numberInSurah}`;
    const now = Date.now();
    const day = 86_400_000;
    setRecords((previous) => {
      const existing: ProgressRecord = previous[key] ?? {
        ayahKey: key,
        surahNumber: sessionSurah.number,
        surahName: sessionSurah.name,
        ayahNumber: sessionAyah.numberInSurah,
        ayahGlobalNumber: sessionAyah.number,
        text: sessionAyah.text,
        status: "new",
        lastReviewedAt: null,
        nextReviewAt: new Date().toISOString(),
        correctStreak: 0,
        mistakesCount: 0,
        totalReviews: 0,
        isDifficult: false,
      };
      let nextReview = now + day;
      let status: ProgressStatus = "needs_review";
      let streak = 0;
      if (result === "help") {
        nextReview = now + 10 * 60_000;
        status = "learning";
      } else if (result === "mastered") {
        const steps = [1, 3, 7, 14, 30, 60];
        nextReview = now + steps[Math.min(existing.correctStreak, steps.length - 1)] * day;
        streak = existing.correctStreak + 1;
        status = streak >= 5 ? "mastered" : "memorized";
      }
      return {
        ...previous,
        [key]: {
          ...existing,
          status,
          correctStreak: streak,
          nextReviewAt: new Date(nextReview).toISOString(),
          lastReviewedAt: new Date(now).toISOString(),
          totalReviews: existing.totalReviews + 1,
          mistakesCount: existing.mistakesCount + (result === "mastered" ? 0 : 1),
        },
      };
    });
    notify(tx("سُجّل تقييمك وحدّد موعد المراجعة القادم.", "Evaluation saved and the next review was scheduled."));
  };

  const startRecord = async () => {
    if (recording) {
      mediaRecorderRef.current?.stop();
      return;
    }
    setRecordingError("");
    setAnalysisError("");
    setAnalysisResult(null);
    if (!navigator.mediaDevices || typeof MediaRecorder === "undefined") {
      setRecordingError(tx("التسجيل غير مدعوم في هذا المتصفح.", "Recording is not supported in this browser."));
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };
      recorder.onstop = () => {
        if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
        const blob = new Blob(audioChunksRef.current, { type: recorder.mimeType || "audio/webm" });
        if (recordingUrl) URL.revokeObjectURL(recordingUrl);
        recordingBlobRef.current = blob;
        setRecordingUrl(URL.createObjectURL(blob));
        setRecording(false);
        stream.getTracks().forEach((track) => track.stop());
      };
      recorder.start();
      setRecording(true);
      setRecordingSeconds(0);
      recordingTimerRef.current = setInterval(() => setRecordingSeconds((value) => value + 1), 1000);
    } catch {
      setRecordingError(tx("تعذّر الوصول إلى الميكروفون. راجع إذن المتصفح.", "Microphone access was not granted."));
    }
  };

  const deleteRecording = () => {
    if (!recordingUrl) return;
    const confirmed = window.confirm(
      tx(
        "هل تريد حذف هذا التسجيل؟ لا يمكن استعادته بعد الحذف.",
        "Delete this recording? It cannot be recovered after deletion.",
      ),
    );
    if (!confirmed) return;
    URL.revokeObjectURL(recordingUrl);
    setRecordingUrl("");
    setRecordingSeconds(0);
    setRecordingError("");
    setAnalysisError("");
    setAnalysisResult(null);
    recordingBlobRef.current = null;
    audioChunksRef.current = [];
    notify(tx("تم حذف التسجيل.", "Recording deleted."));
  };

  const playAnalyzedAyah = (match: AiMatch) => {
    const verseLabel = match.endAyahNumber > match.ayahNumber
      ? `${arabicDigits(match.ayahNumber, lang)}–${arabicDigits(match.endAyahNumber, lang)}`
      : arabicDigits(match.ayahNumber, lang);
    playTrack(
      `${CDN_BASE}/audio/${selectedReciter.bitrate}/${selectedReciter.id}/${match.ayahGlobalNumber}.mp3`,
      `${match.surahName} · ${tx("الآية", "Verse")} ${verseLabel}`,
      isRtl ? selectedReciter.nameAr : selectedReciter.nameEn,
      1,
      0,
    );
  };

  const analysisErrorMessage = (code: string) => {
    const messages: Record<string, [string, string]> = {
      ai_not_configured: ["خدمة التحليل غير مهيأة بعد.", "AI analysis is not configured yet."],
      ai_rate_limited: ["خدمة التحليل مشغولة الآن. انتظر قليلًا ثم حاول مجددًا.", "The analysis service is busy. Please try again shortly."],
      audio_too_large: ["التسجيل كبير جدًا. سجّل مقطعًا أقصر من دقيقتين.", "The recording is too large. Record a clip shorter than two minutes."],
      unsupported_audio_type: ["صيغة التسجيل غير مدعومة.", "This recording format is not supported."],
      analysis_timeout: ["استغرق التحليل وقتًا طويلًا. حاول بمقطع أقصر.", "Analysis took too long. Try a shorter clip."],
    };
    const pair = messages[code] ?? ["تعذّر تحليل التسجيل الآن. حاول مرة أخرى.", "The recording could not be analyzed. Please try again."];
    return tx(pair[0], pair[1]);
  };

  const analyzeRecording = async () => {
    const blob = recordingBlobRef.current;
    if (!blob || analysisLoading) return;
    setAnalysisLoading(true);
    setAnalysisError("");
    setAnalysisResult(null);
    try {
      const extension = blob.type.includes("mp4") ? "m4a" : blob.type.includes("ogg") ? "ogg" : "webm";
      const file = new File([blob], `rattil-recitation.${extension}`, { type: blob.type || "audio/webm" });
      const formData = new FormData();
      formData.append("audio", file);
      const response = await fetch("/api/analyze-recitation", { method: "POST", body: formData });
      const payload = await response.json() as AiAnalysisResult & { error?: string };
      if (!response.ok) throw new Error(payload.error ?? "analysis_failed");
      setAnalysisResult(payload);
      if (payload.status === "matched" && payload.match) {
        playAnalyzedAyah(payload.match);
        notify(tx("تم العثور على الآية وتشغيل تلاوتها.", "The matching verse was found and its recitation started."));
      }
    } catch (error) {
      setAnalysisError(analysisErrorMessage(error instanceof Error ? error.message : "analysis_failed"));
    } finally {
      setAnalysisLoading(false);
    }
  };

  const reviewGroups = useMemo(() => {
    const all = Object.values(records);
    const now = Date.now();
    const day = 86_400_000;
    return {
      due: all.filter((item) => item.status !== "mastered" && new Date(item.nextReviewAt).getTime() <= now && new Date(item.nextReviewAt).getTime() > now - day),
      late: all.filter((item) => item.status !== "mastered" && new Date(item.nextReviewAt).getTime() <= now - day),
      soon: all.filter((item) => item.status !== "mastered" && new Date(item.nextReviewAt).getTime() > now),
      done: all.filter((item) => item.status === "mastered"),
    };
  }, [records]);

  const stats = useMemo(() => {
    const all = Object.values(records);
    return {
      memorized: all.filter((item) => item.status === "memorized" || item.status === "mastered").length,
      mastered: all.filter((item) => item.status === "mastered").length,
      surahs: new Set(all.map((item) => item.surahNumber)).size,
      reviews: all.reduce((sum, item) => sum + item.totalReviews, 0),
      difficult: all.filter((item) => item.isDifficult).length,
      streak: all.length ? Math.min(7, Math.max(1, Math.ceil(all.length / 3))) : 0,
    };
  }, [records]);

  const saveProfile = (event: FormEvent) => {
    event.preventDefault();
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    setProfileSaved(true);
    notify(tx("حُفظت إعداداتك على هذا الجهاز.", "Your settings were saved on this device."));
  };

  const renderHome = () => (
    <>
      <section className="hero section-shell">
        <div className="hero-copy">
          <div className="eyebrow"><Sparkles size={15} /> {tx("رفيقك اليومي مع القرآن", "Your daily Quran companion")}</div>
          <h1>
            {tx("احفظ القرآن", "Memorize the Quran")}<br /><em>{tx("بخطةٍ تناسبك", "at your own pace")}</em>
          </h1>
          <p>
            {tx(
              "رَتِّل يجمع الاستماع، والتكرار، والاسترجاع من الذاكرة، والمراجعة المتباعدة في تجربة هادئة تساعدك على الثبات دون استعجال.",
              "Rattil brings listening, repetition, active recall and spaced review into one calm experience built for consistency.",
            )}
          </p>
          <div className="hero-actions">
            <button className="primary-button" onClick={() => beginSession(currentSurah.ayahs[0] ?? FALLBACK_SURAH.ayahs[0])}>
              {tx("ابدأ الحفظ الآن", "Start memorizing")} {isRtl ? <ArrowLeft size={18} /> : <ArrowRight size={18} />}
            </button>
            <button className="ghost-button" onClick={() => changeView("mushaf")}>
              {tx("استكشف المصحف", "Explore the Quran")}
            </button>
          </div>
          <div className="hero-benefits" aria-label={tx("مزايا رتل", "Rattil benefits")}>
            <span><ShieldCheck size={16} /> {tx("خصوصية محلية", "Private by design")}</span>
            <span><Repeat2 size={16} /> {tx("مراجعة ذكية", "Smart review")}</span>
            <span><Headphones size={16} /> {tx("تلاوات موثوقة", "Trusted audio")}</span>
          </div>
        </div>

        <div className="hero-visual" aria-label={tx("بطاقة ورد اليوم", "Today’s portion")}>
          <div className="ornament ornament-one" />
          <div className="ornament ornament-two" />
          <div className="hero-medallion" aria-hidden="true">ر</div>
          <div className="verse-card">
            <span className="verse-card-mark" aria-hidden="true">۞</span>
            <div className="verse-card-top">
              <span>{tx("وِرد اليوم", "Today’s portion")}</span>
              <span className="status-badge">{tx("قيد الحفظ", "In progress")}</span>
            </div>
            <p className="hero-verse">الرَّحْمَٰنُ ۝ عَلَّمَ الْقُرْآنَ ۝ خَلَقَ الْإِنسَانَ</p>
            <p className="surah-label">{tx("سورة الرحمن · الآيات ١–١٠", "سورة الرحمن · Verses 1–10")}</p>
            <div className="progress-label"><span>{tx("نسبة الإنجاز", "Progress")}</span><strong>{arabicDigits("70%", lang)}</strong></div>
            <div className="progress-track"><span /></div>
            <div className="today-stats">
              <div><strong>{arabicDigits(8, lang)}</strong><span>{tx("مراجعات", "reviews")}</span></div>
              <div><strong>{arabicDigits(20, lang)}</strong><span>{tx("دقيقة", "minutes")}</span></div>
              <div><strong>{arabicDigits(stats.streak || 3, lang)}</strong><span>{tx("أيام متتالية", "day streak")}</span></div>
            </div>
          </div>
          <div className="floating-insight review-insight">
            <span><RefreshCw size={17} /></span>
            <div><small>{tx("المراجعة القادمة", "Next review")}</small><strong>{tx("اليوم", "Today")}</strong></div>
          </div>
          <div className="floating-insight streak-insight">
            <span><TrendingUp size={17} /></span>
            <div><small>{tx("ثباتك هذا الأسبوع", "Weekly consistency")}</small><strong>{arabicDigits("+12%", lang)}</strong></div>
          </div>
        </div>
      </section>

      <section className="how-section section-shell">
        <div className="section-heading">
          <span>{tx("منهج بسيط وواضح", "A clear method")}</span>
          <h2>{tx("خمس خطوات لحفظٍ أثبت", "Five steps for stronger memory")}</h2>
          <p>{tx("جلسة قصيرة ومنظمة تساعدك على الانتقال من السماع إلى الاسترجاع.", "A short, guided session that moves you from listening to recall.")}</p>
        </div>
        <div className="steps-grid">
          {HOME_STEPS.map(({ icon: Icon, key, ar, en }, index) => (
            <article className="step-card" key={key}>
              <span className="step-index">{String(index + 1).padStart(2, "0")}</span>
              <span className="step-icon"><Icon size={24} /></span>
              <h3>{t[key]}</h3>
              <p>{tx(ar, en)}</p>
              {index < HOME_STEPS.length - 1 && (isRtl ? <ArrowLeft className="step-arrow" size={18} /> : <ArrowRight className="step-arrow" size={18} />)}
            </article>
          ))}
        </div>
      </section>

      <section className="method-section">
        <div className="section-shell">
          <div className="section-heading light">
            <span>{tx("رحلة هادئة لا سباق", "A calm journey, not a race")}</span>
            <h2>{tx("الإتقان أهم من السرعة", "Mastery matters more than speed")}</h2>
            <p>{tx("أدوات عملية تعينك على بناء عادة يومية قابلة للاستمرار.", "Practical tools to help you build a sustainable daily habit.")}</p>
          </div>
          <div className="method-grid">
            {METHOD_CARDS.map(({ icon: Icon, titleAr, titleEn, textAr, textEn }, index) => (
              <article className={classNames("method-card", index === 1 && "featured")} key={titleAr}>
                {index === 1 && <span className="featured-label">{tx("الأكثر أثرًا", "Most impactful")}</span>}
                <span className="method-icon"><Icon size={23} /></span>
                <h3>{tx(titleAr, titleEn)}</h3>
                <p>{tx(textAr, textEn)}</p>
                <button onClick={() => changeView(index === 0 ? "session" : index === 1 ? "review" : "progress")}>
                  {tx("اكتشف الأداة", "Explore tool")} {isRtl ? <ArrowLeft size={15} /> : <ArrowRight size={15} />}
                </button>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="quick-tools section-shell">
        <div className="section-heading">
          <span>{tx("كل ما تحتاجه في مكان واحد", "Everything in one place")}</span>
          <h2>{tx("أدوات يومية تعينك على الثبات", "Daily tools for consistency")}</h2>
        </div>
        <div className="quick-tools-grid">
          {[
            { id: "mushaf" as View, icon: BookOpen, ar: "المصحف والتلاوات", en: "Quran & audio", noteAr: "اقرأ واستمع وكرّر كل آية.", noteEn: "Read, listen and repeat each verse." },
            { id: "tasmee" as View, icon: Mic2, ar: "التسميع الذاتي", en: "Self recitation", noteAr: "سجّل صوتك وراجعه محليًا.", noteEn: "Record and review your recitation locally." },
            { id: "similar" as View, icon: Shuffle, ar: "المتشابهات", en: "Similar verses", noteAr: "درّب ذاكرتك على مواضع الخلط.", noteEn: "Practice places that are easy to confuse." },
            { id: "plan" as View, icon: CalendarDays, ar: "خطة تناسب وقتك", en: "A plan for your time", noteAr: "وزّع وقتك بين الحفظ والمراجعة.", noteEn: "Balance memorization and review." },
          ].map((tool) => (
            <button className="quick-tool-card" key={tool.id} onClick={() => changeView(tool.id)}>
              <tool.icon size={23} />
              <strong>{tx(tool.ar, tool.en)}</strong>
              <span>{tx(tool.noteAr, tool.noteEn)}</span>
              <i className="quick-tool-arrow" aria-hidden="true">{isRtl ? <ArrowLeft size={16} /> : <ArrowRight size={16} />}</i>
            </button>
          ))}
        </div>
      </section>

      <section className="closing-quote section-shell">
        <div className="quote-frame">
          <p className="quote-mark">﴿</p>
          <blockquote>وَلَقَدْ يَسَّرْنَا الْقُرْآنَ لِلذِّكْرِ فَهَلْ مِن مُّدَّكِرٍ</blockquote>
          <span>{tx("القمر · ١٧", "Al-Qamar · 17")}</span>
          <button className="primary-button quote-cta" onClick={() => beginSession(currentSurah.ayahs[0] ?? FALLBACK_SURAH.ayahs[0])}>
            {tx("ابدأ جلسة اليوم", "Start today’s session")} {isRtl ? <ArrowLeft size={17} /> : <ArrowRight size={17} />}
          </button>
        </div>
      </section>
    </>
  );

  const renderMushaf = () => (
    <section className="app-section section-shell">
      <div className="app-title-row">
        <div>
          <span className="page-kicker">{tx("قراءة · استماع · تكرار", "Read · listen · repeat")}</span>
          <h1>{tx("المصحف الكريم", "The Holy Quran")}</h1>
          <p>{tx("اختر سورة، واستمع إلى كل آية بصوت القارئ الذي تفضله.", "Choose a Surah and listen verse by verse with your preferred reciter.")}</p>
        </div>
        <button className="primary-button" onClick={playFullSurah}><Play size={17} /> {tx("تشغيل السورة كاملة", "Play full Surah")}</button>
      </div>

      <div className="control-panel">
        <div className="field-group search-field">
          <label htmlFor="surah-search">{tx("بحث عن سورة", "Search Surah")}</label>
          <span><Search size={17} /></span>
          <input id="surah-search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder={tx("اكتب اسم السورة…", "Type a Surah name…")} />
        </div>
        <div className="field-group">
          <label htmlFor="surah-select">{tx("السورة", "Surah")}</label>
          <select id="surah-select" value={selectedSurah} onChange={(event) => chooseSurah(Number(event.target.value))}>
            {(filteredSurahs.length ? filteredSurahs : surahs).map((surah) => (
              <option key={surah.number} value={surah.number}>{arabicDigits(surah.number, lang)}. سورة {surah.name}</option>
            ))}
            {!surahs.length && <option value="55">٥٥. سورة الرحمن</option>}
          </select>
        </div>
        <div className="field-group">
          <label htmlFor="reciter-select">{tx("القارئ", "Reciter")}</label>
          <select id="reciter-select" value={reciterId} onChange={(event) => setReciterId(event.target.value)}>
            {RECITERS.map((reciter) => <option key={reciter.id} value={reciter.id}>{isRtl ? reciter.nameAr : reciter.nameEn}</option>)}
          </select>
        </div>
        <div className="reading-tools" aria-label={tx("أدوات القراءة", "Reading tools")}>
          <button onClick={() => setFontSize((value) => Math.min(54, value + 3))} aria-label={tx("تكبير الخط", "Larger text")}><ZoomIn size={18} /></button>
          <button onClick={() => setFontSize((value) => Math.max(20, value - 3))} aria-label={tx("تصغير الخط", "Smaller text")}><ZoomOut size={18} /></button>
          <button className={showNumbers ? "selected" : ""} onClick={() => setShowNumbers((value) => !value)} aria-label={tx("إظهار أرقام الآيات", "Toggle verse numbers")}><ListChecks size={18} /></button>
          <button className={nightReading ? "selected" : ""} onClick={() => setNightReading((value) => !value)} aria-label={tx("القراءة الليلية", "Night reading")}>{nightReading ? <Sun size={18} /> : <Moon size={18} />}</button>
        </div>
      </div>

      <div className="surah-summary">
        <div><span>{tx("السورة", "Surah")}</span><strong>{currentSurah.name}</strong></div>
        <div><span>{tx("عدد الآيات", "Verses")}</span><strong>{arabicDigits(currentSurah.numberOfAyahs, lang)}</strong></div>
        <div><span>{tx("النزول", "Revelation")}</span><strong>{currentSurah.revelationType === "Meccan" ? (tx("مكية", "Meccan")) : (tx("مدنية", "Medinan"))}</strong></div>
      </div>

      {quranLoading ? (
        <div className="ayah-list">{Array.from({ length: 4 }).map((_, index) => <div className="ayah-skeleton" key={index}><span /><i /></div>)}</div>
      ) : quranError && selectedSurah !== 55 ? (
        <EmptyState
          icon={<CircleAlert size={28} />}
          title={tx("تعذّر تحميل السورة", "Surah could not load")}
          text={tx("تحقق من الاتصال ثم حاول مرة أخرى.", "Check your connection and try again.")}
          action={<button className="primary-button" onClick={() => loadSurah(selectedSurah)}>{t.retry}</button>}
        />
      ) : (
        <div className={classNames("ayah-list", nightReading && "night-reading")}>
          {currentSurah.ayahs.map((ayah) => {
            const record = records[`${currentSurah.number}:${ayah.numberInSurah}`];
            return (
              <article className="ayah-card" key={ayah.number}>
                <div className="ayah-main">
                  {showNumbers && <span className="ayah-number">{arabicDigits(ayah.numberInSurah, lang)}</span>}
                  <p className="quran-text" style={{ fontSize }}>{ayah.text}</p>
                </div>
                <div className="ayah-actions">
                  <button className="play-action" onClick={() => playAyah(ayah)}><Play size={15} /> {tx("تشغيل", "Play")}</button>
                  <button onClick={() => playAyah(ayah, 3)}><Repeat2 size={15} /> {tx("تكرار ٣×", "Repeat 3×")}</button>
                  <button onClick={() => beginSession(ayah)}><Target size={15} /> {tx("جلسة حفظ", "Memorize")}</button>
                  <button className={record?.status === "needs_review" ? "marked" : ""} onClick={() => markAyah(ayah, "needs_review")}><RefreshCw size={15} /> {tx("للمراجعة", "Review")}</button>
                  <button className={record?.isDifficult ? "hard marked" : "hard"} onClick={() => markAyah(ayah, "learning", true)}><Star size={15} /> {tx("موضع صعب", "Difficult")}</button>
                  {record && <span className={`record-status status-${record.status}`}><Check size={12} /> {statusText(record.status, lang)}</span>}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );

  const hiddenWords = (level: number) => {
    const words = sessionAyah.text.split(" ");
    const ratio = [0, 0.28, 0.52, 0.76, 1][Math.min(4, level)];
    const hideCount = Math.ceil(words.length * ratio);
    return words.map((word, index) => {
      const shouldHide = ((index * 7) % Math.max(1, words.length)) < hideCount;
      return shouldHide ? <span className="hidden-word" key={`${word}-${index}`}>{word}</span> : <span key={`${word}-${index}`}>{word} </span>;
    });
  };

  const renderSession = () => (
    <section className="app-section compact-section section-shell">
      <div className="app-title-row">
        <div>
          <span className="page-kicker">{tx("تعلّم بالاسترجاع", "Learn through recall")}</span>
          <h1>{t.session}</h1>
          <p>{tx("اتبع المراحل بالترتيب، ثم قيّم استرجاعك بصدق ورفق.", "Follow each stage, then evaluate your recall honestly and gently.")}</p>
        </div>
        <button className="outline-button" onClick={() => changeView("mushaf")}><BookOpen size={17} /> {tx("تغيير الآية", "Change verse")}</button>
      </div>

      <div className="session-card">
        <div className="session-meta">
          <span>{sessionSurah.name}</span>
          <span>{tx("الآية", "Verse")} {arabicDigits(sessionAyah.numberInSurah, lang)}</span>
        </div>
        <div className="phase-track">
          {[t.listen, t.read, tx("إخفاء", "Hide"), tx("استرجاع", "Recall"), tx("تقييم", "Evaluate")].map((label, index) => (
            <button key={label} className={classNames(sessionPhase === index + 1 && "active", sessionPhase > index + 1 && "complete")} onClick={() => setSessionPhase(index + 1)}>
              <span>{sessionPhase > index + 1 ? <Check size={13} /> : arabicDigits(index + 1, lang)}</span>
              <small>{label}</small>
            </button>
          ))}
        </div>

        <div className="session-workspace">
          <p className={classNames("quran-text session-verse", sessionPhase === 4 && "memory-prompt")}>
            {sessionPhase <= 2 || sessionPhase === 5
              ? sessionAyah.text
              : sessionPhase === 3
                ? hiddenWords(hideLevel)
                : <><EyeOff size={34} /><span>{tx("الآية مخفية — حاول تلاوتها من ذاكرتك", "The verse is hidden — recite it from memory")}</span></>}
          </p>

          {sessionPhase === 1 && (
            <div className="session-buttons">
              <button className="primary-button" onClick={() => {
                const url = `${CDN_BASE}/audio/${selectedReciter.bitrate}/${selectedReciter.id}/${sessionAyah.number}.mp3`;
                playTrack(url, `${sessionSurah.name} · ${arabicDigits(sessionAyah.numberInSurah, lang)}`, isRtl ? selectedReciter.nameAr : selectedReciter.nameEn, 3, 2);
              }}><Headphones size={18} /> {tx("استمع ٣ مرات", "Listen 3 times")}</button>
              <button className="outline-button" onClick={() => setSessionPhase(2)}>{tx("التالي: القراءة", "Next: Read")} {isRtl ? <ArrowLeft size={17} /> : <ArrowRight size={17} />}</button>
            </div>
          )}
          {sessionPhase === 2 && (
            <div className="session-buttons">
              <span className="read-counter">{tx("مرات القراءة", "Reads")} <strong>{arabicDigits(readCount, lang)}</strong></span>
              <button className="outline-button" onClick={() => setReadCount((value) => value + 1)}><BookOpen size={17} /> {tx("قرأت الآية", "I read it")}</button>
              <button className="primary-button" onClick={() => setSessionPhase(3)}>{tx("التالي: الإخفاء", "Next: Hide")}</button>
            </div>
          )}
          {sessionPhase === 3 && (
            <div className="session-buttons">
              <button className="outline-button" disabled={hideLevel >= 4} onClick={() => setHideLevel((value) => Math.min(4, value + 1))}><EyeOff size={17} /> {tx("إخفاء أكثر", "Hide more")}</button>
              <span className="hide-meter"><i style={{ width: `${hideLevel * 25}%` }} /></span>
              <button className="primary-button" onClick={() => setSessionPhase(4)}>{tx("التالي: الاسترجاع", "Next: Recall")}</button>
            </div>
          )}
          {sessionPhase === 4 && (
            <div className="session-buttons">
              <button className="outline-button" onClick={() => changeView("tasmee")}><Mic2 size={17} /> {tx("سجّل تسميعك", "Record recitation")}</button>
              <button className="primary-button" onClick={() => setSessionPhase(5)}>{tx("أظهر الآية وقيّمني", "Reveal and evaluate")}</button>
            </div>
          )}
          {sessionPhase === 5 && (
            <div className="evaluation-buttons">
              <p>{tx("كيف كان استرجاعك؟", "How was your recall?")}</p>
              <div>
                <button className="eval-help" onClick={() => recordEvaluation("help")}>{tx("احتجت مساعدة", "Needed help")}</button>
                <button className="eval-mistake" onClick={() => recordEvaluation("mistake")}>{tx("أخطأت مرة", "One mistake")}</button>
                <button className="eval-mastered" onClick={() => recordEvaluation("mastered")}><Check size={16} /> {tx("أتقنت الآية", "Mastered")}</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );

  const reviewCard = (record: ProgressRecord) => (
    <article className="review-item" key={record.ayahKey}>
      <div><strong>{record.surahName}</strong><span>{tx("آية", "Verse")} {arabicDigits(record.ayahNumber, lang)}</span></div>
      <p className="quran-text">{record.text}</p>
      <div className="review-item-meta"><span>{statusText(record.status, lang)}</span><span>{tx("المراجعات", "Reviews")}: {arabicDigits(record.totalReviews, lang)}</span></div>
      <button onClick={() => beginSession({ number: record.ayahGlobalNumber, numberInSurah: record.ayahNumber, text: record.text }, { number: record.surahNumber, name: record.surahName })}>
        <Play size={14} /> {tx("ابدأ المراجعة", "Start review")}
      </button>
    </article>
  );

  const renderReview = () => {
    const groups = [
      { title: tx("مستحقة الآن", "Due now"), icon: Clock3, items: reviewGroups.due, tone: "due" },
      { title: tx("متأخرة", "Overdue"), icon: CircleAlert, items: reviewGroups.late, tone: "late" },
      { title: tx("قادمة", "Upcoming"), icon: CalendarDays, items: reviewGroups.soon, tone: "soon" },
      { title: tx("متقنة", "Mastered"), icon: ShieldCheck, items: reviewGroups.done, tone: "done" },
    ];
    const allRecords = Object.values(records);
    return (
      <section className="app-section section-shell">
        <div className="app-title-row">
          <div>
            <span className="page-kicker">{tx("راجع لتثبّت", "Review to retain")}</span>
            <h1>{tx("مراجعات اليوم", "Today’s reviews")}</h1>
            <p>{tx("تظهر الآيات في الوقت الذي تحتاج فيه إلى استرجاعها.", "Verses return when your memory is ready to retrieve them.")}</p>
          </div>
          <button className="primary-button" onClick={() => {
            const pool = allRecords.length ? allRecords : null;
            if (!pool) return notify(tx("أضف آيات من المصحف أولًا.", "Add verses from the Quran first."));
            const record = pool[Math.floor(Math.random() * pool.length)];
            beginSession({ number: record.ayahGlobalNumber, numberInSurah: record.ayahNumber, text: record.text }, { number: record.surahNumber, name: record.surahName });
          }}><Shuffle size={17} /> {tx("مراجعة عشوائية", "Random review")}</button>
        </div>
        {!allRecords.length ? (
          <EmptyState
            icon={<RefreshCw size={30} />}
            title={tx("لا توجد مراجعات بعد", "No reviews yet")}
            text={tx("أضف آية للحفظ أو المراجعة من المصحف، وسيبني رَتِّل جدولك تلقائيًا.", "Add a verse from the Quran and Rattil will build your review schedule.")}
            action={<button className="primary-button" onClick={() => changeView("mushaf")}>{tx("افتح المصحف", "Open Quran")}</button>}
          />
        ) : (
          <div className="review-columns">
            {groups.map(({ title, icon: Icon, items, tone }) => (
              <div className={`review-column ${tone}`} key={tone}>
                <div className="review-column-title"><span><Icon size={17} /></span><h2>{title}</h2><b>{arabicDigits(items.length, lang)}</b></div>
                <div className="review-items">{items.length ? items.map(reviewCard) : <p className="column-empty">{tx("لا توجد آيات هنا", "Nothing here")}</p>}</div>
              </div>
            ))}
          </div>
        )}
      </section>
    );
  };

  const renderTasmee = () => (
    <section className="app-section compact-section section-shell">
      <div className="app-title-row">
        <div>
          <span className="page-kicker">{tx("استرجع بصوتك", "Recall aloud")}</span>
          <h1>{t.tasmee}</h1>
          <p>{tx("سجّل تلاوتك، ثم دع أداة المطابقة تتعرّف على الكلمات وتبحث عن موضعها في المصحف.", "Record your recitation, then let verse matching identify the words and find their place in the Quran.")}</p>
        </div>
      </div>
      <div className="tasmee-card">
        <div className="tasmee-orbit"><span className={recording ? "recording" : ""}><Mic2 size={38} /></span></div>
        <p className="tasmee-prompt">{recording ? (tx("جارٍ التسجيل…", "Recording…")) : (tx("أخفِ النص، وخذ نفسًا هادئًا، ثم ابدأ التسميع.", "Hide the text, take a calm breath, then begin."))}</p>
        <strong className="recording-time">{String(Math.floor(recordingSeconds / 60)).padStart(2, "0")}:{String(recordingSeconds % 60).padStart(2, "0")}</strong>
        <button className={classNames("record-button", recording && "stop")} onClick={startRecord}>
          {recording ? <Square size={18} fill="currentColor" /> : <Mic2 size={18} />}
          {recording ? (tx("إيقاف التسجيل", "Stop recording")) : (tx("ابدأ التسميع", "Start recording"))}
        </button>
        {recordingUrl && (
          <div className="recording-result">
            <Check size={18} />
            <span>{tx("اكتمل التسجيل — استمع إليه قبل تقييم نفسك.", "Recording complete — listen before evaluating yourself.")}</span>
            <audio controls src={recordingUrl} />
            <div className="recording-result-actions">
              <button type="button" className="analyze-recording-button" onClick={analyzeRecording} disabled={analysisLoading}>
                {analysisLoading ? <RefreshCw className="spin" size={15} /> : <Sparkles size={15} />}
                {analysisLoading
                  ? tx("جارٍ تحليل التسجيل…", "Analyzing recording…")
                  : tx("تعرّف على الآية بالذكاء الاصطناعي", "Identify the verse with AI")}
              </button>
              <button type="button" className="delete-recording-button" onClick={deleteRecording}>
                <Trash2 size={15} />
                {tx("حذف التسجيل", "Delete recording")}
              </button>
            </div>
            {analysisError && <p className="analysis-error"><CircleAlert size={16} /> {analysisError}</p>}
            {analysisResult && (
              <div className="analysis-result" aria-live="polite">
                <div className="analysis-result-heading"><Brain size={19} /><strong>{tx("نتيجة المطابقة", "Match result")}</strong></div>
                {analysisResult.transcript && <p className="transcript"><span>{tx("النص المسموع", "Heard text")}</span>{analysisResult.transcript}</p>}
                {analysisResult.status === "matched" && analysisResult.match ? (
                  <>
                    <div className="matched-verse-meta">
                      <span>{tx("سورة", "Surah")} {analysisResult.match.surahName}</span>
                      <span>{tx("الآية", "Verse")} {arabicDigits(analysisResult.match.ayahNumber, lang)}{analysisResult.match.endAyahNumber > analysisResult.match.ayahNumber ? `–${arabicDigits(analysisResult.match.endAyahNumber, lang)}` : ""}</span>
                      <span>{tx("درجة المطابقة", "Match confidence")} {arabicDigits(`${analysisResult.match.confidence}%`, lang)}</span>
                    </div>
                    <p className="quran-text matched-verse-text">{analysisResult.match.text}</p>
                    <button className="play-match-button" type="button" onClick={() => playAnalyzedAyah(analysisResult.match!)}>
                      <Play size={16} fill="currentColor" /> {tx("تشغيل الآية بصوت القارئ المختار", "Play with the selected reciter")}
                    </button>
                  </>
                ) : (
                  <p className="no-match-message">
                    {analysisResult.status === "no_speech"
                      ? tx("لم يظهر صوت واضح في التسجيل. قرّب الميكروفون وحاول مجددًا.", "No clear speech was detected. Move closer to the microphone and try again.")
                      : tx("لم نعثر على مطابقة موثوقة. حاول تلاوة آية كاملة بوضوح.", "No reliable match was found. Try reciting one complete verse clearly.")}
                  </p>
                )}
                <small>{tx("النتيجة للمساعدة وليست حكمًا على صحة التجويد.", "This result is an aid, not a Tajweed assessment.")}</small>
              </div>
            )}
          </div>
        )}
        {recordingError && <p className="form-error"><CircleAlert size={15} /> {recordingError}</p>}
        <div className="teacher-note"><ShieldCheck size={19} /><p>{tx("تستخدم الأداة الذكاء الاصطناعي لتحويل الصوت إلى كلمات، ثم تطابقها مع نص المصحف الموثوق. وقد تخطئ؛ أما تصحيح التلاوة والتجويد فيعتمد على معلّم متقن.", "AI converts the audio to words, then matches them against a trusted Quran text. It can still be wrong; accurate recitation and Tajweed should be checked by a qualified teacher.")}</p></div>
      </div>
    </section>
  );

  const renderPlan = () => {
    const planStages = [
      { ar: "تهيئة واستماع", en: "Warm-up & listen", ratio: .15, icon: Headphones },
      { ar: "مراجعة قريبة", en: "Recent review", ratio: .15, icon: RefreshCw },
      { ar: "حفظ جديد", en: "New memorization", ratio: .3, icon: BookOpen },
      { ar: "ربط الآيات", en: "Link verses", ratio: .15, icon: Repeat2 },
      { ar: "تسميع", en: "Recitation", ratio: .15, icon: Mic2 },
      { ar: "مراجعة بعيدة", en: "Long-term review", ratio: .1, icon: CalendarDays },
    ];
    return (
      <section className="app-section compact-section section-shell">
        <div className="app-title-row">
          <div>
            <span className="page-kicker">{tx("وقتك قليل؟ يكفي أن تثبت", "Consistency over volume")}</span>
            <h1>{t.plan}</h1>
            <p>{tx("أخبرنا بوقتك ومستواك، وسنوزع جلستك بين الحفظ والمراجعة.", "Choose your time and level, then balance memorization and review.")}</p>
          </div>
        </div>
        <div className="plan-layout">
          <div className="plan-form-card">
            <div className="field-group">
              <label htmlFor="plan-minutes">{tx("كم دقيقة تستطيع اليوم؟", "How many minutes today?")}</label>
              <select id="plan-minutes" value={planMinutes} onChange={(event) => { setPlanMinutes(Number(event.target.value)); setPlanGenerated(false); }}>
                {[10, 15, 20, 30, 45, 60].map((minute) => <option value={minute} key={minute}>{arabicDigits(minute, lang)} {tx("دقيقة", "minutes")}</option>)}
              </select>
            </div>
            <div className="field-group">
              <label htmlFor="plan-level">{tx("ما مستواك؟", "Your level")}</label>
              <select id="plan-level" value={planLevel} onChange={(event) => { setPlanLevel(event.target.value); setPlanGenerated(false); }}>
                <option value="beginner">{tx("مبتدئ", "Beginner")}</option>
                <option value="intermediate">{tx("متوسط", "Intermediate")}</option>
                <option value="advanced">{tx("متقدم", "Advanced")}</option>
              </select>
            </div>
            <div className="field-group">
              <label htmlFor="plan-start">{tx("من أين تريد البدء؟", "Where to begin?")}</label>
              <select id="plan-start" value={planStart} onChange={(event) => { setPlanStart(event.target.value); setPlanGenerated(false); }}>
                <option value="amma">{tx("جزء عمّ", "Juz Amma")}</option>
                <option value="surah">{tx("سورة أختارها", "A chosen Surah")}</option>
                <option value="start">{tx("من بداية المصحف", "From the beginning")}</option>
                <option value="continue">{tx("متابعة حفظ سابق", "Continue previous work")}</option>
              </select>
            </div>
            <button className="primary-button" onClick={() => setPlanGenerated(true)}><Sparkles size={17} /> {tx("أنشئ جدول اليوم", "Build today’s plan")}</button>
          </div>
          <div className="plan-result-card">
            {!planGenerated ? (
              <EmptyState icon={<CalendarDays size={31} />} title={tx("خطتك تنتظر إعدادك", "Your plan is ready to be built")} text={tx("اختر الإعدادات ثم اضغط إنشاء جدول اليوم.", "Choose your settings and generate today’s schedule.")} />
            ) : (
              <>
                <div className="plan-result-head"><div><span>{tx("إجمالي الجلسة", "Total session")}</span><strong>{arabicDigits(planMinutes, lang)} {tx("دقيقة", "min")}</strong></div><Gauge size={29} /></div>
                <div className="plan-stage-list">
                  {planStages.map(({ ar, en, ratio, icon: Icon }, index) => (
                    <div className="plan-stage" key={ar}>
                      <span><Icon size={17} /></span>
                      <div><strong>{arabicDigits(index + 1, lang)}. {tx(ar, en)}</strong><i><b style={{ width: `${ratio * 100}%` }} /></i></div>
                      <em>{arabicDigits(Math.max(1, Math.round(planMinutes * ratio)), lang)} {tx("د", "m")}</em>
                    </div>
                  ))}
                </div>
                <button className="outline-button wide" onClick={() => changeView("session")}><Play size={16} /> {tx("ابدأ الخطة", "Start plan")}</button>
              </>
            )}
          </div>
        </div>
      </section>
    );
  };

  const renderSimilar = () => (
    <section className="app-section section-shell">
      <div className="app-title-row">
        <div>
          <span className="page-kicker">{tx("تدرّب على مواضع الخلط", "Practice confusing places")}</span>
          <h1>{t.similar}</h1>
          <p>{tx("تمارين تدريبية تجهّز ذاكرتك للتمييز بين البدايات والنهايات المتقاربة.", "Exercises to distinguish between similar beginnings and endings.")}</p>
        </div>
      </div>
      <div className="review-notice"><CircleAlert size={20} /><p>{tx("هذه الوحدة في طور الإعداد العلمي. لن تُنشر مواضع متشابهة إلا بعد مراجعتها واعتمادها، ولن يولّد النظام نصوصًا قرآنية من تلقاء نفسه.", "This module is under scholarly review. Similar passages will only be published after verification; the system will not generate Quranic text.")}</p></div>
      <div className="similar-grid">
        {[
          { icon: EyeOff, ar: "أكمل الآية", en: "Complete the verse", noteAr: "استرجع نهاية الآية بعد إخفائها.", noteEn: "Recall the hidden ending." },
          { icon: Shuffle, ar: "اختر البداية الصحيحة", en: "Choose the opening", noteAr: "فرّق بين بدايات مواضع متقاربة.", noteEn: "Distinguish close openings." },
          { icon: ArrowLeft, ar: "ما الكلمة التالية؟", en: "What comes next?", noteAr: "اختبر انتقالك بين الكلمات.", noteEn: "Test word-to-word flow." },
          { icon: BookOpen, ar: "قارن بين موضعين", en: "Compare two passages", noteAr: "لاحظ الفروق الدقيقة في اللفظ.", noteEn: "Notice precise wording differences." },
          { icon: Search, ar: "حدّد السورة", en: "Name the Surah", noteAr: "اربط اللفظ بموضعه في المصحف.", noteEn: "Link wording to its Surah." },
          { icon: Headphones, ar: "استمع واختر", en: "Listen and choose", noteAr: "ميّز الآية من خلال التلاوة.", noteEn: "Identify the verse by audio." },
        ].map(({ icon: Icon, ar, en, noteAr, noteEn }) => (
          <article className="similar-card" key={ar}><span><Icon size={23} /></span><h2>{tx(ar, en)}</h2><p>{tx(noteAr, noteEn)}</p><b>{tx("قريبًا", "Coming soon")}</b></article>
        ))}
      </div>
    </section>
  );

  const renderProgress = () => {
    const statCards = [
      { value: stats.memorized, ar: "آية محفوظة", en: "Memorized", icon: BookMarked },
      { value: stats.mastered, ar: "آية متقنة", en: "Mastered", icon: ShieldCheck },
      { value: stats.surahs, ar: "سور مبدوءة", en: "Surahs started", icon: BookOpen },
      { value: stats.reviews, ar: "مراجعات", en: "Reviews", icon: RefreshCw },
      { value: stats.streak, ar: "أيام التزام", en: "Day streak", icon: TrendingUp },
      { value: stats.difficult, ar: "مواضع صعبة", en: "Difficult places", icon: Star },
    ];
    const weekly = stats.reviews ? [2, 4, 3, 5, 4, 6, Math.min(7, Math.max(2, stats.reviews))] : [1, 2, 1, 3, 2, 3, 2];
    return (
      <section className="app-section section-shell">
        <div className="app-title-row">
          <div>
            <span className="page-kicker">{tx("خطوة ثابتة كل يوم", "A steady step every day")}</span>
            <h1>{t.progress}</h1>
            <p>{tx("الإتقان أهم من السرعة. راقب تقدمك، وواصل برفق.", "Mastery matters more than speed. See your progress and continue gently.")}</p>
          </div>
        </div>
        <div className="stats-grid">
          {statCards.map(({ value, ar, en, icon: Icon }) => <article key={ar}><span><Icon size={19} /></span><strong>{arabicDigits(value, lang)}</strong><p>{tx(ar, en)}</p></article>)}
        </div>
        <div className="progress-layout">
          <div className="chart-card">
            <div className="card-heading"><div><span>{tx("آخر سبعة أيام", "Last seven days")}</span><h2>{tx("إيقاع المراجعة", "Review rhythm")}</h2></div><TrendingUp size={22} /></div>
            <div className="week-chart">
              {weekly.map((value, index) => <div key={index}><span className="bar" style={{ height: `${Math.max(18, (value / 7) * 100)}%` }}><i>{arabicDigits(value, lang)}</i></span><small>{({ ar: ["سبت", "أحد", "اثن", "ثلا", "أرب", "خمس", "جمع"], en: ["Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri"], fr: ["Sam", "Dim", "Lun", "Mar", "Mer", "Jeu", "Ven"], es: ["Sáb", "Dom", "Lun", "Mar", "Mié", "Jue", "Vie"], tr: ["Cmt", "Paz", "Pzt", "Sal", "Çar", "Per", "Cum"], ur: ["ہفتہ", "اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ"] }[lang])[index]}</small></div>)}
            </div>
          </div>
          <div className="map-card">
            <div className="card-heading"><div><span>{tx("١١٤ سورة", "114 Surahs")}</span><h2>{tx("خريطة المصحف", "Quran map")}</h2></div><BookOpen size={22} /></div>
            <div className="map-legend"><span><i className="map-new" />{tx("لم يبدأ", "Not started")}</span><span><i className="map-learning" />{tx("قيد الحفظ", "Learning")}</span><span><i className="map-mastered" />{tx("متقن", "Mastered")}</span></div>
            <div className="surah-map">
              {Array.from({ length: 114 }, (_, index) => {
                const surahNumber = index + 1;
                const matching = Object.values(records).filter((record) => record.surahNumber === surahNumber);
                const state = matching.some((record) => record.status === "mastered") ? "mastered" : matching.length ? "learning" : "new";
                return <button className={`map-${state}`} key={surahNumber} title={`${tx("سورة", "Surah")} ${surahNumber}`} onClick={() => { chooseSurah(surahNumber); changeView("mushaf"); }}>{arabicDigits(surahNumber, lang)}</button>;
              })}
            </div>
          </div>
        </div>
      </section>
    );
  };

  const renderSources = () => (
    <section className="app-section section-shell">
      <div className="app-title-row">
        <div>
          <span className="page-kicker">{tx("الشفافية أولًا", "Transparency first")}</span>
          <h1>{t.sources}</h1>
          <p>{tx("المصادر الرقمية والضوابط التي يعتمد عليها النموذج الحالي.", "The digital sources and safeguards behind this version.")}</p>
        </div>
      </div>
      <div className="sources-grid">
        {SOURCE_ITEMS.map((source, index) => (
          <article className="source-card" key={source.name}><span>{String(index + 1).padStart(2, "0")}</span><h2>{source.name}</h2><p>{tx(source.ar, source.en)}</p><a href={source.url} target="_blank" rel="noreferrer">{tx("زيارة المصدر", "Visit source")} {isRtl ? <ArrowLeft size={15} /> : <ArrowRight size={15} />}</a></article>
        ))}
      </div>
      <div className="sources-disclaimer"><ShieldCheck size={24} /><div><strong>{tx("تنبيه منهجي", "Methodological note")}</strong><p>{tx("أدوات الحفظ والتقييم في رَتِّل وسائل مساعدة، ولا تغني عن التلقي والتصحيح على يد معلّم متقن. تُحفظ بيانات التقدّم في هذه النسخة على جهازك فقط.", "Rattil’s memorization and evaluation tools are aids, not a substitute for learning with a qualified teacher. Progress is stored only on this device in this version.")}</p></div></div>
    </section>
  );

  const renderSignup = () => (
    <section className="app-section compact-section section-shell">
      <div className="app-title-row">
        <div>
          <span className="page-kicker">{tx("إعدادات رحلتك", "Your journey settings")}</span>
          <h1>{t.signup}</h1>
          <p>{tx("حدّد هدفك ليصبح رَتِّل أقرب إلى طريقتك ووقتك.", "Set your goal so Rattil can better fit your pace.")}</p>
        </div>
      </div>
      <div className="profile-layout">
        <form className="profile-form" onSubmit={saveProfile}>
          <div className="field-group"><label htmlFor="profile-name">{tx("الاسم", "Name")}</label><input id="profile-name" required value={profile.name} onChange={(event) => setProfile((value) => ({ ...value, name: event.target.value }))} placeholder={tx("كيف نناديك؟", "What should we call you?")} /></div>
          <div className="field-group"><label htmlFor="profile-email">{tx("البريد الإلكتروني (اختياري)", "Email (optional)")}</label><input id="profile-email" type="email" value={profile.email} onChange={(event) => setProfile((value) => ({ ...value, email: event.target.value }))} placeholder="name@example.com" /></div>
          <div className="field-group"><label htmlFor="profile-country">{tx("الدولة", "Country")}</label><input id="profile-country" value={profile.country} onChange={(event) => setProfile((value) => ({ ...value, country: event.target.value }))} /></div>
          <div className="field-group"><label htmlFor="profile-goal">{tx("هدفي مع القرآن", "My Quran goal")}</label><textarea id="profile-goal" value={profile.goal} onChange={(event) => setProfile((value) => ({ ...value, goal: event.target.value }))} placeholder={tx("مثال: حفظ جزء عمّ بإتقان خلال ثلاثة أشهر", "Example: Master Juz Amma in three months")} /></div>
          <button className="primary-button" type="submit"><Check size={17} /> {tx("حفظ الإعدادات", "Save settings")}</button>
          {profileSaved && <p className="saved-message"><Check size={15} /> {tx("تم الحفظ على هذا الجهاز.", "Saved on this device.")}</p>}
        </form>
        <div className="privacy-card"><span><ShieldCheck size={28} /></span><h2>{tx("خصوصيتك محفوظة", "Your privacy matters")}</h2><p>{tx("هذه نسخة تجريبية بلا حساب سحابي. بيانات الملف والتقدّم تبقى في التخزين المحلي للمتصفح، وقد تختفي عند مسح بياناته أو استخدام جهاز آخر.", "This demo has no cloud account. Profile and progress remain in browser storage and may be lost if browser data is cleared or you switch devices.")}</p><div><Heart size={17} /> {tx("ابدأ بما تستطيع، وداوم عليه.", "Begin with what you can sustain.")}</div></div>
      </div>
    </section>
  );

  const views: Record<View, () => ReactNode> = {
    home: renderHome,
    mushaf: renderMushaf,
    session: renderSession,
    review: renderReview,
    tasmee: renderTasmee,
    plan: renderPlan,
    similar: renderSimilar,
    progress: renderProgress,
    sources: renderSources,
    signup: renderSignup,
  };

  return (
    <main className={classNames("rattil-app", playerTrack && "has-player")} dir={isRtl ? "rtl" : "ltr"}>
      <header className="site-header">
        <div className="header-inner">
          <button className="brand" onClick={() => changeView("home")} aria-label={tx("العودة إلى الرئيسية", "Back home")}>
            <span className="brand-emblem" aria-hidden="true">ر</span>
            <span className="brand-copy">
              <span className="brand-mark">{tx("رَتِّل", "Rattil")}</span>
              <span className="brand-subtitle">{tx("احفظ بقلبك · وثبّت بمراجعتك", "Memorize with heart · retain through review")}</span>
            </span>
          </button>
          <nav className="desktop-nav" aria-label={tx("التنقل الرئيسي", "Main navigation")}>
            {NAV_ITEMS.map((item) => <button className={activeView === item.id ? "active" : ""} key={item.id} onClick={() => changeView(item.id)}>{t[item.id]}</button>)}
          </nav>
          <div className="header-actions">
            <label className="language-picker" aria-label="Language">
              <Languages size={17} />
              <select value={lang} onChange={(event) => setLang(event.target.value as Lang)}>
                {LANGUAGE_OPTIONS.map((language) => <option key={language.code} value={language.code}>{language.nativeName}</option>)}
              </select>
            </label>
            <button className="header-cta" onClick={() => changeView("signup")}><UserRound size={16} /> {profile.name || t.start}</button>
          </div>
          <button className="menu-button" onClick={() => setMenuOpen((value) => !value)} aria-label={menuOpen ? (tx("إغلاق القائمة", "Close menu")) : (tx("فتح القائمة", "Open menu"))} aria-expanded={menuOpen}>{menuOpen ? <X /> : <Menu />}</button>
        </div>
        {menuOpen && (
          <nav className="mobile-nav" aria-label={tx("التنقل على الجوال", "Mobile navigation")}>
            {[...NAV_ITEMS, { id: "tasmee" as View, icon: Mic2 }, { id: "similar" as View, icon: Shuffle }, { id: "sources" as View, icon: ShieldCheck }, { id: "signup" as View, icon: UserRound }].map(({ id, icon: Icon }) => (
              <button className={activeView === id ? "active" : ""} key={id} onClick={() => changeView(id)}><Icon size={17} /> {t[id]}</button>
            ))}
            <label className="mobile-language-picker"><Languages size={17} /><select value={lang} onChange={(event) => setLang(event.target.value as Lang)}>{LANGUAGE_OPTIONS.map((language) => <option key={language.code} value={language.code}>{language.nativeName}</option>)}</select></label>
          </nav>
        )}
      </header>

      <div className="view-shell" key={activeView}>{views[activeView]()}</div>

      <footer>
        <div className="footer-main section-shell">
          <div className="footer-brand"><strong>{tx("رَتِّل", "Rattil")}</strong><p>{tx("منصة ذكية لتنظيم الحفظ والمراجعة والتسميع.", "A thoughtful companion for memorization, review and recitation.")}</p></div>
          <div className="footer-links"><button onClick={() => changeView("mushaf")}>{t.mushaf}</button><button onClick={() => changeView("session")}>{t.session}</button><button onClick={() => changeView("review")}>{t.review}</button><button onClick={() => changeView("sources")}>{t.sources}</button></div>
          <div className="footer-verse"><p>وَلَقَدْ يَسَّرْنَا الْقُرْآنَ لِلذِّكْرِ</p><span>{tx("الإتقان أهم من السرعة", "Mastery matters more than speed")}</span></div>
        </div>
        <div className="footer-bottom section-shell">
          <span>© 2026 {tx("رَتِّل", "Rattil")}</span>
          <span>{tx("نسخة تجريبية · البيانات محفوظة محليًا", "Demo · data stored locally")}</span>
          <a className="designer-signature" href="https://wa.me/96551231313" target="_blank" rel="noreferrer" aria-label="WhatsApp: Saad.alnabhan">
            <FaWhatsapp aria-hidden="true" />
            <b>Saad.alnabhan</b>
          </a>
        </div>
      </footer>

      <audio
        ref={audioRef}
        onTimeUpdate={updatePlayerProgress}
        onEnded={handleAudioEnded}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onError={() => {
          if (!playerTrack) return;
          if (chapterQueue && chapterQueueIndex < chapterQueue.ayahs.length - 1) {
            notify(tx("تعذّر تشغيل هذه الآية، انتقلنا إلى الآية التالية.", "This verse could not play; moving to the next verse."));
            playNextChapterAyah();
          } else {
            setChapterQueue(null);
            setChapterQueueIndex(0);
            setIsPlaying(false);
            notify(tx("تعذّر تحميل ملف التلاوة لهذا القارئ.", "This recitation file could not load."));
          }
        }}
      />
      {playerTrack && (
        <div className="audio-player">
          <div className="player-inner">
            <div className="track-info"><span className="track-icon"><Volume2 size={18} /></span><div><strong>{playerTrack.title}</strong><span>{playerTrack.subtitle}</span></div></div>
            <button className="player-play" onClick={togglePlayer} aria-label={isPlaying ? (tx("إيقاف مؤقت", "Pause")) : (tx("تشغيل", "Play"))}>{isPlaying ? <Pause size={19} fill="currentColor" /> : <Play size={19} fill="currentColor" />}</button>
            <div className="player-seek"><input aria-label={tx("تقدم التشغيل", "Playback progress")} type="range" min="0" max="100" value={playerProgress} onChange={(event) => { const value = Number(event.target.value); setPlayerProgress(value); const audio = audioRef.current; if (audio && Number.isFinite(audio.duration)) audio.currentTime = (value / 100) * audio.duration; }} /><span style={{ width: `${playerProgress}%` }} /></div>
            {playerTrack.repeat > 1 && <span className="repeat-count"><Repeat2 size={14} /> {arabicDigits(playerTrack.repeat - playerTrack.remaining + 1, lang)}/{arabicDigits(playerTrack.repeat, lang)}</span>}
            <input className="volume-slider" aria-label={tx("مستوى الصوت", "Volume")} type="range" min="0" max="1" step="0.05" value={playerVolume} onChange={(event) => { const volume = Number(event.target.value); setPlayerVolume(volume); if (audioRef.current) audioRef.current.volume = volume; }} />
            <button className="player-close" onClick={closePlayer} aria-label={tx("إغلاق المشغل", "Close player")}><X size={19} /></button>
          </div>
          {gapActive && <div className="gap-message">{tx("فاصل قصير… استعد للتكرار", "Short pause… prepare to repeat")}</div>}
        </div>
      )}

      {toast && <div className="toast" role="status"><Check size={16} /> {toast}</div>}
    </main>
  );
}
