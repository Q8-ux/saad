async function omanCommerceApp(){
"use strict";
const CFG=window.OMAN_CONFIG,root=document.getElementById("app"),page=document.body.dataset.page||"home",BASE=CFG?.base||"/saad/oman-fruits-commerce/";
let db,settings={},catalog=[],categories=[],roles=[],user=null,staffDisplayName="موظف المتجر",cart=[],posCart=[],activeCustomer=null,selectedOrder=null,managerTab="overview",salesTab="pos",managerCache={};
const route=(p="")=>BASE+(p?p.replace(/^\/|\/$/g,"")+"/":"");
const esc=x=>String(x??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const cash=v=>`${Number(v||0).toFixed(3)} د.ك`;
const num=v=>Number.isFinite(Number(v))?Number(v):0;
const date=v=>v?new Date(v).toLocaleString("ar-KW",{dateStyle:"medium",timeStyle:"short",timeZone:"Asia/Kuwait"}):"—";
const today=()=>new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kuwait",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date());
const daysAgo=d=>{const x=new Date();x.setDate(x.getDate()-d);return new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kuwait",year:"numeric",month:"2-digit",day:"2-digit"}).format(x)};
const toast=(msg,type="ok")=>{let h=document.getElementById("toastbox");if(!h){h=document.createElement("div");h.id="toastbox";h.className="toast-wrap";document.body.append(h)}const t=document.createElement("div");t.className="toast"+(type==="error"?" error":type==="warn"?" warn":"");t.textContent=msg;h.append(t);setTimeout(()=>t.remove(),5800)};
const err=e=>{let msg=e?.message||String(e||"خطأ غير معروف");console.error("Oman shop:",e);toast(msg,"error");return msg};
const q=(sel,parent=document)=>parent.querySelector(sel);
const qa=(sel,parent=document)=>[...parent.querySelectorAll(sel)];
const field=(name,label,type="text",value="",req=false)=>`<div class="field"><label for="${esc(name)}">${esc(label)}</label><input class="input" id="${esc(name)}" name="${esc(name)}" type="${type}" value="${esc(value)}" ${req?"required":""} ${type==="number"?'min="0" step="0.001"':''}></div>`;
const sel=(name,label,options=[],selected="")=>`<div class="field"><label for="${esc(name)}">${esc(label)}</label><select class="select" name="${esc(name)}" id="${esc(name)}">${options.map(o=>`<option value="${esc(o.value)}" ${String(o.value)===String(selected)?"selected":""}>${esc(o.label)}</option>`).join("")}</select></div>`;
const formValues=form=>Object.fromEntries(new FormData(form).entries());
const role=r=>roles.includes(r);
const company=()=>settings.company_name||"شركة عمان للفواكه والخضروات";
const cartKey="oman_cart_v1";
const prod=id=>catalog.find(p=>p.id===id);
const variant=id=>{for(const p of catalog){const v=(p.product_variants||[]).find(v=>v.id===id);if(v)return {...v,product:p}}return null};
// 36 real market photographs, cleaned/cropped from the supplied promotional story screenshots.
const atlasPhoto=p=>{
 const n=Number((String(p.slug||"").match(/^oman-(\d+)$/)||[])[1]);
 if(!Number.isInteger(n)||n<1||n>36)return null;
 const i=n-1,x=((i%6)*20).toFixed(0),y=(Math.floor(i/6)*20).toFixed(0);
 return `<div class="photo-atlas" role="img" aria-label="${esc(p.name_ar)}" style="background-position:${x}% ${y}%"></div>`;
};
const photo=p=>{
 const fallback=atlasPhoto(p)||`<div class="photo-fallback"><span>${esc(p.emoji||"🍎")}</span><small class="photo-tag">صورة توضيحية</small></div>`;
 if(!p.image_url)return fallback;
 return `<img loading="lazy" alt="${esc(p.name_ar)}" src="${esc(p.image_url)}" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><div class="photo-backup" style="display:none">${fallback}</div>`;
};
const catName=p=>categories.find(c=>c.id===p.category_id)?.name_ar||"فواكه";
const activeVariants=p=>(p.product_variants||[]).filter(v=>v.published&&(!v.track_stock||num(v.stock_qty)>0));
const cartCount=()=>cart.reduce((s,c)=>s+num(c.qty),0);
const loadCart=()=>{try{cart=JSON.parse(localStorage.getItem(cartKey)||"[]");if(!Array.isArray(cart))cart=[]}catch{cart=[]}};
const saveCart=()=>{localStorage.setItem(cartKey,JSON.stringify(cart));updateCartBubble()};
const updateCartBubble=()=>{const n=q("[data-cart-count]");if(n)n.textContent=cartCount()};
function makeClient(){
 if(!window.supabase?.createClient||!CFG?.supabaseUrl||!CFG?.publishableKey)throw Error("تعذر تشغيل اتصال المتجر بقاعدة البيانات، يرجى المحاولة لاحقًا.");
 const customFetch=(input,init={})=>{const h=new Headers(typeof Request!=="undefined"&&input instanceof Request?input.headers:undefined);if(init.headers)new Headers(init.headers).forEach((v,k)=>h.set(k,v));if(h.get("Authorization")===`Bearer ${CFG.publishableKey}`)h.delete("Authorization");h.set("apikey",CFG.publishableKey);return fetch(input,{...init,headers:h})};
 return window.supabase.createClient(CFG.supabaseUrl,CFG.publishableKey,{global:{fetch:customFetch},auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
}
const api=async(p)=>{let {data,error}=await p;if(error)throw error;return data};
async function basic(){
 const [s,c,p]=await Promise.all([api(db.from("settings").select("*").eq("id",1).single()),api(db.from("categories").select("*").order("sort")),api(db.from("products").select("id,slug,name_ar,origin,emoji,image_url,image_is_original,active,on_offer,offer_label,featured,category_id,sort,product_variants(id,unit_label,price_unit,price_value,unit_confirmed,needs_review,published,stock_qty,track_stock,sort)").order("sort"))]);settings=s||{};categories=c||[];catalog=(p||[]).map(x=>({...x,product_variants:(x.product_variants||[]).sort((a,b)=>a.sort-b.sort)}))
}
async function session(){
 const {data,error}=await db.auth.getUser();if(error||!data?.user){user=null;roles=[];return}user=data.user;
 try{const v=await api(db.rpc("my_roles"));roles=Array.isArray(v)?v:[]}catch{roles=[]}if(roles.length){try{staffDisplayName=await api(db.rpc("my_employee_name"))||"موظف المتجر"}catch{staffDisplayName=role("manager")?"مدير المتجر":"موظف المتجر"}}
}
const brand=()=>`<a class="brand" href="${route()}"><span class="brand-logo">🧺</span><span><strong>${esc(company())}</strong><small>طازجة كل يوم • الكويت</small></span></a>`;
function header(){return `<div class="topbar">🍃 خضروات وفواكه مختارة بعناية • أسعار محدثة من المتجر</div><header class="header"><div class="container header-row">${brand()}<nav class="header-actions"><a class="btn" href="${route()}">المنتجات</a><a class="btn primary" href="${route("checkout")}">🛒 السلة <b data-cart-count>${cartCount()}</b></a></nav></div></header>`}
function footer(){return `<footer class="footer"><div class="container footer-grid"><div><strong>${esc(company())}</strong><p>منتجات طازجة وأسعار مرتبطة مباشرة بنظام المتجر، لا تُكتب على الصور.</p></div><div><strong>روابط</strong><p><a href="${route()}">المنتجات</a></p><p><a href="${route("checkout")}">إتمام الطلب</a></p></div><div><strong>التواصل</strong><p>${esc(settings.phone||"رقم الهاتف قيد الإضافة")}</p><small>خصوصيتك مهمة؛ لا نعرض طلبات العملاء السابقين عبر رقم الهاتف للزوار.</small></div></div></footer>`}
function cartSummary(list,delivery=false,pos=false){
 let subtotal=0;const lines=list.map(c=>{const v=variant(c.id);if(!v||!v.published)return "";const value=num(v.price_value)*num(c.qty);subtotal+=value;return `<div class="cart-item"><span class="emoji">${esc(v.product.emoji)}</span><div class="meta"><strong>${esc(v.product.name_ar)}</strong><small>${esc(v.unit_label)} × ${esc(c.qty)}</small></div><strong>${cash(value)}</strong><div class="qty"><button type="button" ${pos?"data-pos-minus":"data-cart-minus"}="${esc(c.id)}" aria-label="تقليل">−</button>${esc(c.qty)}<button type="button" ${pos?"data-pos-plus":"data-cart-plus"}="${esc(c.id)}" aria-label="زيادة">+</button></div></div>`}).join("");
 const fee=delivery?(settings.free_delivery_over&&subtotal>=num(settings.free_delivery_over)?0:num(settings.delivery_fee)):0;
 return `<div>${lines||`<div class="empty"><div class="big">🛒</div>سلتك فارغة</div>`}</div><div class="summary-row"><span>قيمة الأصناف</span><strong>${cash(subtotal)}</strong></div>${delivery?`<div class="summary-row"><span>التوصيل</span><strong>${cash(fee)}</strong></div>`:""}<div class="summary-row total"><span>الإجمالي ${delivery?"التقديري":""}</span><strong>${cash(subtotal+fee)}</strong></div>`;
}
function publicCard(p){
 const vs=activeVariants(p);if(!vs.length)return "";const first=vs[0];const sold=vs.some(v=>!v.track_stock||num(v.stock_qty)>0);const voptions=vs.map(v=>`<option value="${esc(v.id)}">${esc(v.unit_label)} — ${cash(v.price_value)}</option>`).join("");
 return `<article class="product-card"><div class="product-photo">${photo(p)}${p.on_offer?`<span class="badge" style="position:absolute;top:10px;right:10px">${esc(p.offer_label||"عرض")}</span>`:""}</div><div class="product-content"><small class="origin">${esc(catName(p))} • ${esc(p.origin||"منشأ غير محدد")}</small><h3>${esc(p.name_ar)}</h3><div class="price" data-price-for="${esc(p.id)}">${cash(first.price_value)} <small> / ${esc(first.unit_label)}</small></div><div class="actions"><select aria-label="وحدة البيع" class="select" data-product-variant="${esc(p.id)}">${voptions}</select><button class="btn primary" data-add-variant="${esc(p.id)}" ${sold?"":"disabled"}>إضافة +</button></div></div></article>`;
}
function home(){
 const visible=catalog.filter(p=>p.active&&activeVariants(p).length);
 root.innerHTML=header()+`<section class="hero"><div class="container hero-grid"><div><span class="badge">🥬 طلبات الفواكه والخضروات</span><h1>الطازج لبيتك<br><span class="text-green">والسعر واضح دائمًا</span></h1><p>اختر فواكهك وخضرواتك المفضلة. أسعار المنتجات محدثة مباشرة من لوحة المتجر، والصور لا تحمل أسعارًا ثابتة.</p><a class="btn primary" href="#products">تسوّق الأصناف ←</a><div class="trust-grid"><span>✓ وحدات بيع متعددة</span><span>✓ طلب إلكتروني بسيط</span><span>✓ خدمة التوصيل في الكويت</span></div></div><div class="hero-art"><span>🍇</span><span>🍊</span><span>🥬</span></div></div></section><section class="section" id="products"><div class="container"><div class="section-head"><div><h2>منتجاتنا الطازجة</h2><span class="muted">اختر الصنف والحجم المناسب من القائمة</span></div><label class="search">🔎 <input type="search" id="catalog-search" placeholder="ابحث عن منتج أو بلد المنشأ" autocomplete="off"></label></div><div class="chips" id="category-chips">${[{id:"all",name_ar:"جميع الأصناف"},...categories].map((c,i)=>`<button class="chip ${i===0?"active":""}" data-cat="${esc(c.id)}">${esc(c.name_ar)}</button>`).join("")}</div><div class="product-grid" id="catalog-grid">${visible.map(publicCard).join("")}</div><p class="muted center" style="margin-top:20px">أي صنف لم تُعتمد وحدته أو سعره لا يُعرض للبيع قبل المراجعة.</p></div></section>${footer()}<a class="floating-cart" href="${route("checkout")}">🛒 السلة: <b data-cart-count>${cartCount()}</b></a>`;
 let filterCat="all";function refresh(){let term=(q("#catalog-search")?.value||"").toLowerCase().trim();const xs=visible.filter(p=>(filterCat==="all"||p.category_id===filterCat)&&(!term||`${p.name_ar} ${p.origin||""}`.toLowerCase().includes(term)));q("#catalog-grid").innerHTML=xs.length?xs.map(publicCard).join(""):`<div class="panel empty" style="grid-column:1/-1">لا توجد منتجات مطابقة للبحث</div>`}
 q("#catalog-search").addEventListener("input",refresh);document.addEventListener("change",e=>{const t=e.target;if(t.matches?.("[data-product-variant]")){const v=variant(t.value),box=q(`[data-price-for="${t.dataset.productVariant}"]`);if(v&&box)box.innerHTML=`${cash(v.price_value)} <small> / ${esc(v.unit_label)}</small>`}});qa("[data-cat]").forEach(b=>b.addEventListener("click",()=>{filterCat=b.dataset.cat;qa("[data-cat]").forEach(x=>x.classList.toggle("active",x===b));refresh()}));
 qa("[data-product-variant]").forEach(x=>x.addEventListener("change",()=>{const v=variant(x.value);const box=q(`[data-price-for="${x.dataset.productVariant}"]`);if(v&&box)box.innerHTML=`${cash(v.price_value)} <small> / ${esc(v.unit_label)}</small>`}));
}
function cartChange(id,step,targetCart=cart){const x=targetCart.find(c=>c.id===id);if(!x){return}x.qty=Math.max(0,Math.min(1000,+(num(x.qty)+step).toFixed(3)));if(x.qty===0)targetCart.splice(targetCart.indexOf(x),1);if(targetCart===cart){saveCart();if(page==="checkout")renderCheckout();else if(page==="home")updateCartBubble()}else renderSalesPos()}
function addCart(id,pos=false){const v=variant(id);if(!v||!v.published&& !pos){toast("الصنف غير متاح","warn");return}if(v.track_stock&&num(v.stock_qty)<=0){toast("المنتج غير متوفر حاليًا","warn");return}const list=pos?posCart:cart;const found=list.find(c=>c.id===id);if(found)found.qty++;else list.push({id,qty:1});if(pos){renderSalesPos()}else{saveCart();toast(`تمت إضافة ${v.product.name_ar} إلى السلة`) }}
function renderCheckout(){
 const items=cart.filter(c=>variant(c.id)?.published);root.innerHTML=header()+`<div class="container"><div class="page-title"><h1>إتمام الطلب</h1><p>ضع بيانات التوصيل بدقة، وسنحفظ الطلب بعد التحقق من توفر الأصناف في قاعدة البيانات.</p></div>${!items.length?`<div class="panel empty"><div class="big">🛒</div><h2>سلتك فارغة</h2><a class="btn primary" href="${route()}">العودة للتسوق</a></div>`:`<div class="layout-two"><form id="checkout-form" class="panel"><h2>معلومات الطلب</h2><div class="form-grid">${field("name","الاسم الكامل","text","",true)}${field("phone","رقم الهاتف الكويتي","tel","",true)}${field("governorate","المحافظة","text","",true)}${field("area","المنطقة","text","",true)}${field("block","القطعة","text","",true)}${field("street","الشارع")}${field("house","المنزل / البناية")}${sel("delivery_slot","وقت التوصيل المفضل",(settings.delivery_slots||[]).map(x=>({value:x,label:x})))}</div>${sel("payment_method","طريقة الدفع",[...(settings.pay_cod?[{value:"cod",label:"الدفع عند الاستلام"}]:[]),...(settings.pay_transfer?[{value:"transfer",label:"تحويل بنكي يدوي"}]:[])])}<div class="field"><label>ملاحظات العنوان</label><textarea class="textarea" name="address_notes" maxlength="300"></textarea></div><div class="field"><label>ملاحظات الطلب</label><textarea class="textarea" name="notes" maxlength="500"></textarea></div><label class="inline"><input type="checkbox" name="consent" required> أوافق على حفظ بيانات الاتصال والعنوان لإتمام الطلب وفق سياسة الخصوصية.</label><details style="margin:12px 0"><summary>سياسة الخصوصية</summary><p class="muted">${esc(settings.privacy_policy)}</p></details><button class="btn primary wide" id="submit-order" type="submit">تأكيد الطلب وحفظه</button></form><aside class="panel cart"><h3>ملخص السلة</h3><div id="checkout-summary">${cartSummary(items,true)}</div><small class="muted">السعر النهائي المعتمد يحسبه الخادم عند تأكيد الطلب.</small></aside></div>`}</div>${footer()}`;
 if(!items.length)return;
 q("#checkout-form").addEventListener("submit",async e=>{e.preventDefault();const form=e.currentTarget,f=formValues(form),button=q("#submit-order");button.disabled=true;button.textContent="جارٍ حفظ الطلب...";try{const p={name:f.name,phone:f.phone,governorate:f.governorate,area:f.area,block:f.block,street:f.street,house:f.house,address_notes:f.address_notes,delivery_slot:f.delivery_slot,payment_method:f.payment_method,notes:f.notes,consent:form.querySelector('[name="consent"]').checked,items:items.map(c=>({variant_id:c.id,qty:num(c.qty)}))};const x=await api(db.rpc("place_online_order",{p}));cart=[];saveCart();toast(`تم حفظ طلبك برقم ${x.invoice_no}`);location.href=route("order")+"?token="+encodeURIComponent(x.token)}catch(ex){err(ex);button.disabled=false;button.textContent="تأكيد الطلب وحفظه"}});
}
async function renderTracking(){
 const token=new URLSearchParams(location.search).get("token")||"";if(!/^[0-9a-f]{64}$/i.test(token)){root.innerHTML=header()+`<main class="container page-title"><div class="panel empty"><h2>رابط الطلب غير صالح</h2></div></main>`+footer();return}
 try{const o=await api(db.rpc("get_order_public",{_token:token}));if(!o)throw Error("الطلب غير موجود أو الرابط غير صحيح");const a=o.customer?.address||{};const lab={new:"طلب جديد",preparing:"جارٍ التجهيز",out_for_delivery:"خارج للتوصيل",delivered:"تم التسليم",cancelled:"ملغى",returned:"مرتجع"};
 root.innerHTML=header()+`<main class="container"><div class="page-title"><span class="badge">تم استلام الطلب</span><h1>متابعة الطلب رقم ${esc(o.invoice_no)}</h1><p>${date(o.created_at)}</p></div><div class="detail-grid"><div class="panel"><h2>حالة الطلب</h2><div class="success"><strong>${esc(lab[o.status]||o.status)}</strong></div><ul class="list">${(o.history||[]).map(i=>`<li>${esc(lab[i.to]||i.to)} — <span class="muted">${date(i.at)}</span></li>`).join("")}</ul><h3>عنوان التوصيل</h3><p>${esc([a.governorate,a.area,a.block,a.street,a.house].filter(Boolean).join("، "))}</p></div><div class="panel"><h2>تفاصيل الفاتورة</h2>${(o.items||[]).map(x=>`<div class="summary-row"><span>${esc(x.name)} • ${esc(x.qty)} ${esc(x.unit)}</span><strong>${cash(x.line_total)}</strong></div>`).join("")}<div class="divider"></div><div class="summary-row"><span>التوصيل</span><b>${cash(o.delivery_fee)}</b></div><div class="summary-row total"><span>الإجمالي</span><b>${cash(o.total)}</b></div><p>طريقة الدفع: ${esc({cod:"عند الاستلام",transfer:"تحويل بنكي",cash:"نقدي",credit:"آجل"}[o.payment_method]||o.payment_method)}</p>${o.transfer_info?`<p class="notice">${esc(o.transfer_info)}</p>`:""}</div></div><p class="muted tiny">احتفظ بهذا الرابط بصورة خاصة؛ يتيح عرض تفاصيل الطلب لمن يملكه.</p></main>${footer()}`;
 }catch(e){root.innerHTML=header()+`<main class="container page-title"><div class="panel error-box">${esc(e.message)}</div></main>${footer()}`}
}
async function renderLogin(){
 await session();if(user&&roles.length){location.href=route(role("manager")?"manager":"sales");return}
 const target=new URLSearchParams(location.search).get("next");const next=["sales","manager"].includes(target)?target:"sales";
 root.innerHTML=header()+`<main class="container"><div class="panel auth-card"><div class="center" style="font-size:44px">🔐</div><h2>دخول فريق المتجر</h2><p class="center muted">سجّل باستخدام بريدك الإلكتروني وكلمة المرور، وليس اسم المستخدم المختصر. إذا لم تنشئ حسابًا مسبقًا فاختر «إنشاء حساب عمل» أولًا.</p><div class="login-tabs"><button type="button" data-auth-mode="signin" class="active">تسجيل الدخول</button><button type="button" data-auth-mode="signup">إنشاء حساب عمل</button></div><form id="auth-form">${field("email","البريد الإلكتروني","email","",true)}${field("password","كلمة المرور","password","",true)}<button class="btn primary wide" id="auth-submit">تسجيل الدخول</button></form><button type="button" id="resend-confirmation" class="btn wide" style="margin-top:12px">📨 إعادة إرسال رابط تأكيد البريد</button><p class="notice tiny" style="margin-top:17px"><strong>لتفعيل الدخول أول مرة:</strong> أنشئ حساب العمل ببريدك الإلكتروني، ثم افتح رسالة التأكيد في بريدك وأكّد الحساب. سيبقى حسابك دون صلاحيات حتى يعيّن مالك قاعدة البيانات صلاحية المدير بشكل آمن. لا يمكن استخدام اسم Oman بدل البريد الإلكتروني حاليًا.</p></div></main>${footer()}`;
 q("#resend-confirmation").addEventListener("click",async()=>{const email=q("#email")?.value.trim(),button=q("#resend-confirmation");if(!email||!email.includes("@"))return toast("اكتب بريدك الإلكتروني أولًا، ثم اضغط إعادة إرسال الرابط","warn");button.disabled=true;try{const {error}=await db.auth.resend({type:"signup",email});if(error)throw error;toast("إذا كان الحساب يحتاج تأكيدًا، فستصل رسالة إلى بريدك. تحقق أيضًا من البريد غير المرغوب.")}catch(ex){err(ex)}finally{button.disabled=false}});
 let mode="signin";qa("[data-auth-mode]").forEach(b=>b.addEventListener("click",()=>{mode=b.dataset.authMode;qa("[data-auth-mode]").forEach(x=>x.classList.toggle("active",x===b));q("#auth-submit").textContent=mode==="signin"?"تسجيل الدخول":"إنشاء الحساب"}));
 q("#auth-form").addEventListener("submit",async e=>{e.preventDefault();const f=formValues(e.currentTarget),b=q("#auth-submit");b.disabled=true;try{if(mode==="signup"){const {data,error}=await db.auth.signUp({email:f.email.trim(),password:f.password});if(error)throw error;if(data?.session){toast("تم إنشاء الحساب، ويجب أن يعيّن المالك صلاحيات العمل قبل الدخول إلى المبيعات.","warn")}else{toast("تم إنشاء طلب الحساب. افتح بريدك الإلكتروني لتأكيد العنوان ثم عد لتسجيل الدخول.")}q("#auth-form").reset()}else{const {error}=await db.auth.signInWithPassword({email:f.email.trim(),password:f.password});if(error)throw error;await session();if(!roles.length){toast("تأكدنا من الحساب، لكنه لم يُعتمد كمدير أو موظف بعد. اطلب تعيين الصلاحية من مالك النظام.","warn");return}location.href=route(role("manager")&&next==="manager"?"manager":"sales")}}catch(ex){let message=String(ex?.message||"");if(/invalid login credentials|email not confirmed|invalid credentials/i.test(message)){toast(/not confirmed/i.test(message)?"يجب تأكيد بريدك الإلكتروني أولًا.":"هذا البريد أو كلمة المرور غير مسجلين أو غير صحيحين. اختر إنشاء حساب عمل إن كانت هذه أول مرة.","warn")}else err(ex)}finally{b.disabled=false}});
}

function guestPreview(which){
 const pages=[["sales","☎️ شاشة استقبال الطلبات"],["manager","⚙️ لوحة الإدارة"]];
 const menu='<div class="row wrap" style="margin:12px 0 20px">'+pages.map(function(x){return '<a class="btn '+(which===x[0]?'primary':'')+'" href="'+route(x[0])+'">'+x[1]+'</a>'}).join("")+'<a class="btn" href="'+route("login")+'">🔐 الدخول التشغيلي</a></div>';
 const intro='<div class="notice" style="margin-bottom:16px">معاينة عامة بدون كلمة مرور. البيانات الشخصية والفواتير والدفاتر المالية الحقيقية لا تظهر هنا. لا يمكن حفظ تغييرات أو إصدار فاتورة إلا بحساب مخوّل.</div>';
 const available=catalog.filter(function(p){return p.active && activeVariants(p).length>0});
 if(which==="sales"){
   root.innerHTML='<div class="container"><div class="page-title"><h1>☎️ استقبال طلبات عمان — معاينة</h1><p>شاهد خطوات العمل والمنتجات. الحفظ والبحث الحقيقيان يتطلبان حساب الموظف.</p></div>'+menu+intro+'<div class="layout-two"><div><div class="panel"><h3>1 — بيانات المتصل</h3><label class="field">رقم الهاتف<input class="input" id="guest-phone" placeholder="معاينة فقط، لا تدخل بيانات حقيقية"></label><button class="btn" id="guest-find">البحث عن عميل</button><p class="muted" id="guest-client">بيانات العملاء مخفية في وضع المعاينة.</p></div><div class="panel" style="margin-top:15px"><h3>2 — اختيار الأصناف</h3><input class="input" id="guest-search" placeholder="ابحث عن منتج"><div id="guest-products" class="product-grid" style="grid-template-columns:repeat(2,minmax(0,1fr));margin-top:12px"></div></div></div><aside class="panel cart"><h3>3 — سلة تجريبية</h3><div id="guest-cart">لا توجد أصناف</div><div class="summary-row total"><span>الإجمالي</span><strong id="guest-total">0.000 د.ك</strong></div><p class="muted tiny">هذه تجربة داخل المتصفح ولا تُحفظ في قاعدة البيانات.</p></aside></div></div>';
   const sample=[];let cart=[];const list=q("#guest-products"),cartBox=q("#guest-cart"),tot=q("#guest-total");
   const renderCart=function(){cartBox.innerHTML=cart.length?cart.map(function(x){return '<div class="summary-row"><span>'+esc(x.name)+' × '+x.qty+'</span><strong>'+cash(x.qty*x.price)+'</strong></div>'}).join(""):'لا توجد أصناف';tot.textContent=cash(cart.reduce(function(a,x){return a+x.qty*x.price},0))};
   const renderList=function(){const term=q("#guest-search").value.trim();const arr=available.filter(function(p){return p.name_ar.includes(term)});list.innerHTML=arr.map(function(p){const v=activeVariants(p)[0];return '<div class="panel" style="padding:9px"><div class="product-photo" style="height:110px">'+photo(p)+'</div><strong>'+esc(p.name_ar)+'</strong><div class="price">'+cash(v.price_value)+'</div><small>'+esc(v.unit_label)+'</small><button class="btn primary wide" data-guest-add="'+esc(v.id)+'" style="margin-top:9px">إضافة للسلة</button></div>'}).join("")||'<div>لا توجد أصناف مطابقة</div>'};
   q("#guest-search").addEventListener("input",renderList);
   q("#guest-find").addEventListener("click",function(){q("#guest-client").textContent="السجل الحقيقي محمي؛ سجّل الدخول لاسترجاع الاسم والعنوان والطلبات السابقة"});
   list.addEventListener("click",function(e){const b=e.target.closest("[data-guest-add]");if(!b)return;const v=variant(b.dataset.guestAdd);if(!v)return;const x=cart.find(function(k){return k.id===v.id});if(x)x.qty++;else cart.push({id:v.id,qty:1,name:v.product.name_ar,price:num(v.price_value)});renderCart()});renderList();
 }else{
   root.innerHTML='<div class="container"><div class="page-title"><h1>⚙️ لوحة إدارة عمان — معاينة</h1><p>أقسام الإدارة متاحة للاستعراض فقط، دون كشف الحسابات أو تعديلها.</p></div>'+menu+intro+'<div class="stats-grid"><div class="stat"><small>الأصناف الموجودة</small><strong>'+catalog.length+'</strong></div><div class="stat"><small>وحدات البيع المعروضة</small><strong>'+available.reduce(function(n,p){return n+activeVariants(p).length},0)+'</strong></div><div class="stat"><small>مبيعات العملاء</small><strong>محجوبة</strong></div><div class="stat"><small>صافي الربح</small><strong>محجوب</strong></div></div><div class="tabs" id="guest-admin-tabs">'+["الرئيسية","إدارة الموظفين","المنتجات","الفواتير","المحاسبة والميزانية","التقارير","الموردون","الإعدادات"].map(function(x,i){return '<button data-guest-tab="'+i+'" class="'+(i===0?'active':'')+'">'+x+'</button>'}).join("")+'</div><div class="panel" id="guest-admin-content"></div></div>';
   const panes=[
   '<h3>الرئيسية</h3><p>راجع هيكل المتجر والأقسام من هنا. الأرقام المحاسبية الحقيقية تحتاج صلاحية المدير.</p>',
   '<h3>إدارة الموظفين</h3><p>إضافة موظف باسمه ومسمّاه الوظيفي، التعديل والإيقاف والحذف متاحة للمدير بعد تسجيل الدخول. لا تظهر أسماء الموظفين أو بريدهم في المعاينة العامة.</p>',
   '<h3>المنتجات والأسعار</h3><p>أسعار عمان محفوظة منفصلة عن الصور. لديك '+catalog.length+' صنفًا في الكتالوج.</p>',
   '<h3>الفواتير</h3><p>الأرشيف والطباعة وبيانات العملاء محمية ولا تعرض هنا.</p>',
   '<h3>المحاسبة والميزانية</h3><p>دفتر القيود والمصروفات والأرصدة محمي. لا توجد أرقام محاسبية وهمية.</p>',
   '<h3>التقارير</h3><p>تقارير المبيعات والأرباح والتصدير محجوبة عن الزوار.</p>',
   '<h3>الموردون</h3><p>سجلات الموردين والمشتريات محمية.</p>',
   '<h3>الإعدادات</h3><p>تعديل الأسعار والموظفين والسياسات وإعدادات الطباعة يتطلب حساب المدير.</p>'
   ];
   q("#guest-admin-content").innerHTML=panes[0];
   q("#guest-admin-tabs").addEventListener("click",function(e){const b=e.target.closest("[data-guest-tab]");if(!b)return;q("#guest-admin-content").innerHTML=panes[Number(b.dataset.guestTab)];qa("[data-guest-tab]").forEach(function(x){x.classList.toggle("active",x===b)})});
 }
}
async function guard(required){
 await session();
 if(!user||(!role(required)&&!(required==="sales"&&role("manager")))){guestPreview(required);return false}
 return true;
}

async function loadPreviewCatalog(){
 const response=await fetch(BASE+"catalog.json",{cache:"no-store"});
 if(!response.ok)throw Error("تعذر تحميل كتالوج المنتجات من GitHub");
 const source=await response.json();
 if(!Array.isArray(source.products))throw Error("ملف المنتجات غير صالح");
 categories=[{id:"fruits",name_ar:"الفواكه"},{id:"vegetables",name_ar:"الخضروات"},{id:"nuts",name_ar:"المكسرات"},{id:"sweets",name_ar:"الحلويات"}];
 catalog=source.products.map((p,i)=>({
   id:p.id,slug:p.id,name_ar:p.name_ar,origin:p.origin,emoji:"🍏",
   active:true,category_id:/بامية|بطاطا|ذرة/.test(p.name_ar)?"vegetables":/فستق|اللوز/.test(p.name_ar)?"nuts":/الحلوى/.test(p.name_ar)?"sweets":"fruits",
   product_variants:(p.variants||[]).map((v,j)=>({
     id:p.id+"-"+j,unit_label:v.unit,price_value:v.price_fils===null?0:v.price_fils/1000,
     published:!!(v.confirmed&&v.active&&v.price_fils!==null),track_stock:false,stock_qty:0,sort:j
   }))
 }));
 settings={company_name:"شركة عمان للفواكه والخضروات",opening_entered:false};
}
async function init(){
 loadCart();
 if(page==="home"||page==="checkout"||page==="order"){location.replace(route("sales"));return}
 if(page==="sales"||page==="manager"){
   // Always render the no-login read-only preview from the public static catalog.
   // Backend DNS/Cloudflare 1016 errors must never blank these pages.
   await loadPreviewCatalog();
   guestPreview(page);
   // A valid authenticated session may upgrade the preview to the actual work screen.
   // The underlying database enforces role-based access and RLS on every action.
   try{
     db=makeClient();
     const check=Promise.all([basic(),session()]);
     await Promise.race([check,new Promise((_,reject)=>setTimeout(()=>reject(Error("الخادم غير متاح")),5500))]);
     if(role(page)||(page==="sales"&&role("manager"))){
       if(page==="sales")await renderSales();else await renderManager();
     }
   }catch(e){
     console.warn("Oman backend unavailable: read-only preview remains accessible.",e?.message||e);
   }
   return;
 }
 db=makeClient();
 if(page==="login"){await renderLogin();return}
 await basic();
 home();
 document.addEventListener("click",async e=>{
 const b=e.target.closest("button");if(!b)return;
 if(b.dataset.addVariant){const v=q(`[data-product-variant="${b.dataset.addVariant}"]`);if(v)addCart(v.value)}
 if(b.dataset.cartMinus){cartChange(b.dataset.cartMinus,-1)}
 if(b.dataset.cartPlus){cartChange(b.dataset.cartPlus,1)}
 if(b.dataset.posMinus){cartChange(b.dataset.posMinus,-1,posCart)}
 if(b.dataset.posPlus){cartChange(b.dataset.posPlus,1,posCart)}
 });
}
async function fetchOrders(){return await api(db.from("orders").select("*,order_items(id,name_snapshot,unit_snapshot,unit_price,qty,line_total,unit_cost),payments(id,kind,amount,method,created_at)").order("created_at",{ascending:false}).limit(250))}
const statusNames={new:"جديد",preparing:"قيد التجهيز",out_for_delivery:"خارج للتوصيل",delivered:"تم التسليم",cancelled:"ملغى",returned:"مرتجع"};
function printTwo(o){
 if(!o)return toast("اختر فاتورة أولًا","warn");
 const items=o.order_items||o.items||[],a=o.customer_snapshot?.address||{},s=esc(company());
 const make=(label)=>`<section class="print-sheet"><span class="tag-copy">${esc(label)}</span><h1>${s}</h1><div class="print-columns"><div>فاتورة رقم: <strong>${esc(o.invoice_no)}</strong><br>التاريخ: ${date(o.created_at)}<br>العميل: ${esc(o.customer_snapshot?.name||"—")}<br>الهاتف: ${esc(o.customer_snapshot?.phone||"—")}</div><div>العنوان:<br>${esc([a.governorate,a.area,a.block,a.street,a.house].filter(Boolean).join("، "))||"—"}<br>طريقة الدفع: ${esc(o.payment_method)}</div></div><div class="print-separator"></div><table><thead><tr><th>الصنف</th><th>الكمية/الوحدة</th><th>سعر الوحدة</th><th>الإجمالي</th></tr></thead><tbody>${items.map(i=>`<tr><td>${esc(i.name_snapshot||i.name)}</td><td>${esc(i.qty)} ${esc(i.unit_snapshot||i.unit)}</td><td>${cash(i.unit_price)}</td><td>${cash(i.line_total)}</td></tr>`).join("")}</tbody></table><div class="print-separator"></div><div>الإجمالي قبل الخصم: ${cash(o.subtotal)}</div><div>الخصم: ${cash(o.discount)}</div><div>التوصيل: ${cash(o.delivery_fee)} &nbsp; الضريبة: ${cash(o.tax)}</div><h2>المجموع: ${cash(o.total)}</h2><div>المدفوع: ${cash(o.paid)} | المتبقي: ${cash(Math.max(0,num(o.total)-num(o.paid)))}</div><p class="center" style="margin-top:22px">شكرًا لتعاملكم معنا</p></section>`;
 const node=q("#print-root");node.hidden=false;node.innerHTML=make("نسخة العميل")+make("نسخة الحفظ والأرشيف");
 document.body.classList.toggle("receipt80",settings.print_size==="80mm");let style=q("#print-page-config");if(!style){style=document.createElement("style");style.id="print-page-config";document.head.append(style)}style.textContent=settings.print_size==="80mm"?"@page{size:80mm 210mm;margin:2mm}":"@page{size:A4;margin:8mm}";
 window.print();
}
function ordersTable(list=[]){
 return `<div class="table-wrap"><table class="data-table"><thead><tr><th>رقم الفاتورة</th><th>التاريخ</th><th>العميل</th><th>الإجمالي</th><th>المدفوع</th><th>الحالة</th><th>الإجراءات</th></tr></thead><tbody>${list.map(o=>`<tr><td>#${esc(o.invoice_no)}</td><td>${date(o.created_at)}</td><td>${esc(o.customer_snapshot?.name||"عميل نقدي")}</td><td>${cash(o.total)}</td><td>${cash(o.paid)}</td><td><span class="badge ${o.status==="cancelled"||o.status==="returned"?"danger":o.status==="delivered"?"":"warning"}">${esc(statusNames[o.status]||o.status)}</span></td><td><div class="actions-row"><button class="btn small" data-show-order="${esc(o.id)}">تفاصيل</button><button class="btn small" data-print-order="${esc(o.id)}">نسختان 🖨️</button></div></td></tr>`).join("")||`<tr><td colspan="7" class="center muted">لا توجد فواتير حتى الآن</td></tr>`}</tbody></table></div>`;
}
function orderDetails(o){
 if(!o)return `<div class="notice">لم تتحدد فاتورة</div>`;
 return `<div class="panel"><h3>الفاتورة رقم ${esc(o.invoice_no)}</h3><p class="muted">${date(o.created_at)} • ${esc(o.customer_snapshot?.name||"عميل نقدي")}</p>${(o.order_items||[]).map(i=>`<div class="summary-row"><span>${esc(i.name_snapshot)} × ${esc(i.qty)} (${esc(i.unit_snapshot)})</span><strong>${cash(i.line_total)}</strong></div>`).join("")}<div class="summary-row total"><span>الإجمالي</span><strong>${cash(o.total)}</strong></div><p>مدفوع: ${cash(o.paid)} | متبقٍ: ${cash(Math.max(0,num(o.total)-num(o.paid)))}</p><div class="form-grid">${sel("change-status","حالة الطلب",Object.entries(statusNames).map(([v,label])=>({value:v,label})),o.status)}${field("payment-amount","تسجيل مبلغ مقبوض","number",Math.max(0,num(o.total)-num(o.paid)).toFixed(3))}</div><div class="actions-row"><button class="btn" data-update-order="${esc(o.id)}">تحديث الحالة</button><button class="btn" data-receive-order="${esc(o.id)}">تسجيل قبض</button><button class="btn primary" data-print-order="${esc(o.id)}">طباعة نسختين</button></div><p class="muted tiny">إلغاء الفواتير أو المرتجعات يتطلب صلاحية المدير، ولا تُحذف الفواتير من الأرشيف.</p></div>`;
}
async function setStatus(id){const element=q('select[name="change-status"]');if(!element)return;try{await api(db.rpc("set_order_status",{_order_id:id,_status:element.value,_note:"تحديث من لوحة المتجر"}));toast("حُفظت حالة الطلب");await refreshProtected()}catch(e){err(e)}}
async function receiveOrder(id){const el=q('input[name="payment-amount"]'),amount=num(el?.value);if(amount<=0)return toast("أدخل مبلغ قبض صحيحًا","warn");try{await api(db.rpc("add_payment",{_order_id:id,_amount:amount,_method:"cash",_kind:"receipt",_note:"قبض من نقطة البيع"}));toast("تم تسجيل القبض محاسبيًا");await refreshProtected()}catch(e){err(e)}}
async function viewOrder(id){const o=(managerCache.orders||[]).find(o=>o.id===id);selectedOrder=o;const slot=q("#order-details");if(slot)slot.innerHTML=orderDetails(o);slot?.scrollIntoView({behavior:"smooth",block:"nearest"})}
async function refreshProtected(){if(page==="manager")await renderManager();else await renderSales()}
async function renderSales(){
 const orders=await fetchOrders();managerCache.orders=orders;
 root.innerHTML=`<div class="dashboard"><aside class="dash-side">${brand()}<nav><button class="dash-nav ${salesTab==="pos"?"active":""}" data-sales-tab="pos">☎️ استقبال مكالمة</button><button class="dash-nav ${salesTab==="orders"?"active":""}" data-sales-tab="orders">🧾 الفواتير</button>${role("manager")?`<a class="dash-nav manager-link" href="${route("manager")}">⚙️ لوحة المدير</a>`:""}<button class="dash-nav" id="sales-out">خروج</button></nav></aside><main class="dash-main"><div class="dash-top"><div><h1>استقبال الطلبات الهاتفية</h1><small>الموظف: ${esc(staffDisplayName)}</small></div><span class="badge">☎️ للموظفين المصرح لهم فقط</span></div><div id="sales-content"></div></main></div>`;
 qa("[data-sales-tab]").forEach(b=>b.addEventListener("click",()=>{salesTab=b.dataset.salesTab;renderSales()}));q("#sales-out").addEventListener("click",signOut);
 if(salesTab==="pos")renderSalesPos();else renderSalesOrders();
}
function renderSalesPos(){
 const slot=q("#sales-content");if(!slot)return;slot.classList.add("callcenter");
 slot.innerHTML=`<div class="layout-two"><div><div class="panel"><h3>2 — اختر الأصناف التي يطلبها المتصل</h3><label class="search" style="margin-bottom:14px">🔎 <input type="search" id="pos-search" placeholder="ابحث باسم الصنف"></label><div id="pos-products" class="product-grid" style="grid-template-columns:repeat(2,minmax(0,1fr))"></div></div><div class="panel" style="margin-top:20px"><h3>1 — رقم هاتف المتصل وبياناته</h3><p class="muted">اكتب رقم الهاتف ثم اضغط استرجاع. سيظهر اسم العميل وعنوانه وطلباته السابقة إن كان مسجلًا.</p><div class="row">${field("lookup-phone","رقم هاتف المتصل (8 أرقام كويتية أو +965)")}</div><button class="btn primary" id="lookup-customer">🔎 استرجاع العميل وطلباته</button><div id="customer-result" style="margin-top:10px">${activeCustomer?customerCard(activeCustomer):'<p class="muted">ابدأ برقم الهاتف. في الاتصال الأول سجّل اسم العميل وعنوانه؛ في الاتصالات التالية ستجد طلباته محفوظة.</p>'}</div><details style="margin-top:15px"><summary>➕ المتصل جديد؟ اضغط لتسجيل الاسم والعنوان ورقم أو رقمين</summary><form id="new-customer-form" style="margin-top:12px">${field("cust-name","اسم العميل","text","",true)}<div class="form-grid">${field("cust-phone1","هاتف أول","tel","",true)}${field("cust-phone2","هاتف آخر","tel")}${field("cust-gov","المحافظة")}${field("cust-area","المنطقة")}${field("cust-block","القطعة")}${field("cust-street","الشارع")}${field("cust-house","المنزل")}</div><label class="inline"><input required type="checkbox" name="consent"> وافق العميل على حفظ بياناته</label><button class="btn primary">حفظ العميل</button></form></details></div></div><aside class="panel cart"><h3>3 — سلة الطلب والفاتورة الجديدة</h3><p class="muted tiny">يمكن تعديل الكميات والأصناف قبل اعتماد الطلب. سعر الطلب يُحسب بالسعر الحالي لا بسعر الطلب القديم.</p><div id="pos-cart">${cartSummary(posCart,false,true)}</div><div class="divider"></div>${field("pos-discount","الخصم (د.ك)","number","0.000")}${sel("pos-payment","نوع الدفع",[{value:"cash",label:"نقدي"},{value:"cod",label:"عند الاستلام"},...(settings.pay_transfer?[{value:"transfer",label:"تحويل"}]:[]),...(settings.pay_credit?[{value:"credit",label:"آجل"}]:[])])}${field("pos-paid","المبلغ المقبوض الآن","number","0.000")}<div class="call-address"><h4>عنوان التوصيل لهذه المكالمة</h4>${activeCustomer?.addresses?.length>1?`<div class="field"><label for="pos-choose-address">اختيار عنوان محفوظ</label><select id="pos-choose-address" class="select"><option value="">عنوان آخر طلب</option>${activeCustomer.addresses.map((a,i)=>`<option value="${i}">${esc([a.governorate,a.area,a.block,a.street,a.house].filter(Boolean).join("، "))}</option>`).join("")}</select></div>`:""}<p class="muted tiny">يظهر عنوان العميل السابق تلقائيًا، ويمكن تعديله للطلب الجديد دون تعديل الفواتير القديمة.</p><div class="call-address-grid">${["governorate","area","block","street","house"].map((k,i)=>field("pos-address-"+k,["المحافظة","المنطقة","القطعة","الشارع","المنزل"][i],"text",(activeCustomer?.last_address||activeCustomer?.addresses?.find(a=>a.is_default)||activeCustomer?.addresses?.[0]||{})[k]||"")).join("")}</div>${field("pos-delivery-fee","رسوم التوصيل (د.ك)","number",settings.delivery_fee??"0.000")}</div><label class="inline tiny"><input type="checkbox" id="pos-save-address"> احفظ العنوان المعدّل كعنوان العميل الافتراضي</label><button class="btn primary wide" id="save-pos">حفظ الفاتورة</button></aside></div><div id="order-details" style="margin-top:22px"></div>`;
 function updateList(){const val=(q("#pos-search")?.value||"").trim();const subset=catalog.filter(p=>p.active&&activeVariants(p).length&&(!val||p.name_ar.includes(val))).slice(0,60);q("#pos-products").innerHTML=subset.map(p=>`<div class="panel call-product"><div class="call-product-image">${photo(p)}</div><div class="call-product-body"><strong>${esc(p.name_ar)}</strong><small class="origin">${esc(p.origin||"")}</small><div class="row call-product-controls"><select class="select" data-pos-select="${esc(p.id)}">${activeVariants(p).map(v=>`<option value="${esc(v.id)}">${esc(v.unit_label)} — ${cash(v.price_value)}</option>`).join("")}</select><button class="btn primary small" data-pos-add="${esc(p.id)}">إضافة +</button></div></div></div>`).join("")}
 updateList();q("#pos-search").addEventListener("input",updateList);q("#lookup-customer").addEventListener("click",lookupCustomer);q("#lookup-phone").addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();lookupCustomer()}});q("#new-customer-form").addEventListener("submit",createCustomer);q("#save-pos").addEventListener("click",savePosOrder);
 q("#pos-cart").innerHTML=cartSummary(posCart,false,true);q("#lookup-phone")?.focus();q("#pos-choose-address")?.addEventListener("change",e=>{if(e.target.value==="")return;const a=activeCustomer?.addresses?.[Number(e.target.value)];if(!a)return;["governorate","area","block","street","house"].forEach(k=>{const x=q("#pos-address-"+k);if(x)x.value=a[k]||""})});
}
function customerCard(c){return `<div class="success"><strong>✅ ${esc(c.name)}</strong><p>الهواتف: ${(c.phones||[]).map(x=>esc(x.phone)).join(" | ")}</p><p>العنوان: ${esc(Object.values(c.last_address||c.addresses?.find(a=>a.is_default)||c.addresses?.[0]||{}).filter(x=>typeof x==="string"&&x.length>0&&!/^[0-9a-f-]{36}$/i.test(x)).join("، ")||"لم يُضف عنوان")}</p><p>عدد الطلبات السابقة: ${(c.orders||[]).length} • يمكن إعادة أي طلب وتعديل السلة</p>${(c.orders||[]).slice(0,5).map(o=>`<div class="summary-row call-order-row"><div><small>فاتورة #${esc(o.invoice_no)} – ${date(o.created_at)}</small><div class="tiny">الإجمالي السابق: ${cash(o.total)}</div></div><button class="btn small primary" type="button" data-repeat-order="${esc(o.id)}">🔁 نفس الطلب</button></div>`).join("")}<small>يظهر هذا السجل للموظفين المخولين فقط، ويتم تدقيق عمليات الاستعلام.</small></div>`}
async function lookupCustomer(){const ph=q("#lookup-phone")?.value;if(!ph)return toast("أدخل رقم الهاتف","warn");try{const c=await api(db.rpc("lookup_customer",{_phone:ph}));if(posCart.length&&activeCustomer?.id!==c?.id){if(!confirm("توجد أصناف في السلة من مكالمة سابقة. هل تريد إفراغها والانتقال إلى العميل الجديد؟"))return;posCart=[]}activeCustomer=c||null;if(c){renderSalesPos()}else{q("#customer-result").innerHTML=`<div class="notice">لم يُعثر على العميل. يمكنك إضافته بالاستمارة أدناه.</div>`;}if(!c){q("#cust-phone1").value=ph;q("#new-customer-form")?.closest("details")?.setAttribute("open","")}toast(c?"تم العثور على العميل":"لم يُعثر على سجل","ok")}catch(e){err(e)}}
async function repeatCustomerOrder(orderId){
 if(!activeCustomer?.id)return toast("ابحث عن العميل برقم هاتفه أولًا","warn");
 try {
  const data=await api(db.from("orders").select("id,customer_id,invoice_no,order_items(variant_id,qty,name_snapshot,unit_snapshot)").eq("id",orderId).eq("customer_id",activeCustomer.id).single());
  if(!data)throw Error("الطلب السابق غير موجود لهذا العميل");
  const next=[],missing=[];
  for(const item of data.order_items||[]){
    const v=variant(item.variant_id);
    if(!v||!v.published||!v.product.active||(v.track_stock&&num(v.stock_qty)<num(item.qty))){missing.push(item.name_snapshot);continue}
    const previous=next.find(x=>x.id===v.id);
    if(previous)previous.qty+=num(item.qty);else next.push({id:v.id,qty:num(item.qty)});
  }
  if(!next.length)return toast("لا توجد أصناف متاحة من الطلب السابق لإعادة شرائها","warn");
  if(posCart.length&&!confirm("سيتم استبدال محتويات السلة الحالية بالطلب السابق. هل تريد المتابعة؟"))return;
  posCart=next;
  renderSalesPos();
  const result=q("#customer-result");result?.scrollIntoView({behavior:"smooth",block:"start"});
  toast("أُعيدت أصناف الفاتورة "+data.invoice_no+" إلى السلة بالسعر الحالي. يمكنك تعديل الكميات"+(missing.length?"؛ تعذّر إضافة "+missing.length+" أصناف غير متوفرة":""));
 }catch(e){err(e)}
}
async function createCustomer(e){e.preventDefault();const f=formValues(e.currentTarget);const phones=[f["cust-phone1"],f["cust-phone2"]].filter(Boolean);const addr={governorate:f["cust-gov"],area:f["cust-area"],block:f["cust-block"],street:f["cust-street"],house:f["cust-house"]};try{const id=await api(db.rpc("create_customer",{_name:f["cust-name"],_phones:phones,_address:addr,_consent:true}));activeCustomer=await api(db.rpc("get_customer",{_cid:id}));toast("حُفظ العميل ورقم الهاتف والعنوان");renderSalesPos()}catch(e){err(e)}}
async function savePosOrder(){if(!activeCustomer?.id)return toast("يجب استرجاع العميل أو تسجيله برقم هاتف قبل حفظ طلبه","warn");if(!posCart.length)return toast("أضف صنفًا أولًا","warn");const method=q("#pos-payment").value,discount=num(q("#pos-discount").value),paid=num(q("#pos-paid").value),addr=Object.fromEntries(["governorate","area","block","street","house"].map(k=>[k,q("#pos-address-"+k)?.value?.trim()||""])),deliveryFee=num(q("#pos-delivery-fee")?.value);if(discount<0||paid<0||deliveryFee<0)return toast("مبلغ غير صالح","warn");if(!addr.governorate||!addr.area||!addr.block)return toast("الرجاء تسجيل المحافظة والمنطقة والقطعة قبل الحفظ","warn");try{const p={items:posCart.map(x=>({variant_id:x.id,qty:num(x.qty)})),customer_id:activeCustomer?.id||null,payment_method:method,discount,paid,delivery_fee:deliveryFee,address:addr,save_address:!!q("#pos-save-address")?.checked};const response=await api(db.rpc("pos_create_order",{p}));toast(`حُفظت الفاتورة رقم ${response.invoice_no}`);posCart=[];await renderSales();const o=(managerCache.orders||[]).find(x=>x.invoice_no===response.invoice_no||x.id===response.id);if(o){selectedOrder=o;const d=q("#order-details");if(d)d.innerHTML=orderDetails(o)}}catch(e){err(e)}}
function renderSalesOrders(){const el=q("#sales-content");el.innerHTML=`<div class="panel"><h2>سجل فواتير المبيعات</h2>${ordersTable(managerCache.orders||[])}</div><div id="order-details" style="margin-top:18px"></div>`}
async function signOut(){try{await db.auth.signOut();location.href=route("login")}catch(e){err(e)}}
async function renderManager(){
 const orders=await fetchOrders();managerCache.orders=orders;
 const tabs=[["overview","الرئيسية","📊"],["orders","الفواتير","🧾"],["products","الأسعار والمنتجات","🥬"],["customers","العملاء","👥"],["stock","المخزون","📦"],["accounts","المحاسبة والميزانية","💰"],["reports","التقارير","📈"],["suppliers","الموردون","🚚"],["settings","الإعدادات","⚙️"],["team","إدارة الموظفين","👥"]];
 root.innerHTML=`<div class="dashboard"><aside class="dash-side">${brand()}<nav>${tabs.map(([id,t,icon])=>`<button class="dash-nav ${managerTab===id?"active":""}" data-manager-tab="${id}">${icon} ${t}</button>`).join("")}<button class="dash-nav" id="manager-out">تسجيل الخروج</button></nav></aside><main class="dash-main"><div class="dash-top"><div><h1>${esc(tabs.find(x=>x[0]===managerTab)?.[1]||"لوحة التحكم")}</h1><small>${esc(staffDisplayName)} • لوحة الإدارة</small></div><a class="btn" href="${route("sales")}">الانتقال للبيع</a></div><section id="manager-content"></section></main></div>`;
 qa("[data-manager-tab]").forEach(b=>b.addEventListener("click",()=>{managerTab=b.dataset.managerTab;renderManager()}));q("#manager-out").addEventListener("click",signOut);
 const target=q("#manager-content");
 if(managerTab==="overview")await managerOverview(target);
 if(managerTab==="orders")managerOrders(target);
 if(managerTab==="products")managerProducts(target);
 if(managerTab==="customers")managerCustomers(target);
 if(managerTab==="stock")managerStock(target);
 if(managerTab==="accounts")await managerAccounting(target);
 if(managerTab==="reports")await managerReports(target);
 if(managerTab==="suppliers")await managerSuppliers(target);
 if(managerTab==="settings")managerSettings(target);
 if(managerTab==="team")await managerTeam(target);
}
async function managerOverview(target){
 const orders=managerCache.orders||[],active=orders.filter(o=>!["cancelled","returned"].includes(o.status)),tod=today();
 const todayOrders=active.filter(o=>new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Kuwait",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(o.created_at))===tod);
 const sum=x=>x.reduce((a,o)=>a+num(o.total),0),due=active.reduce((a,o)=>a+Math.max(0,num(o.total)-num(o.paid)),0);
 target.innerHTML=`<div class="stats-grid"><div class="stat"><small>طلبات اليوم</small><strong>${todayOrders.length}</strong></div><div class="stat"><small>مبيعات اليوم</small><strong>${cash(sum(todayOrders))}</strong></div><div class="stat"><small>فواتير في الأرشيف</small><strong>${orders.length}</strong></div><div class="stat"><small>المتبقي على الفواتير</small><strong>${cash(due)}</strong></div></div>${!settings.opening_entered?`<div class="notice" style="margin-bottom:16px">⚠️ التقارير المحاسبية لا تشكل ميزانية عمومية مكتملة قبل إدخال الأرصدة الافتتاحية وتكاليف البضاعة وكل الحركات.</div>`:""}<div class="panel"><div class="section-head"><h3>آخر الفواتير</h3><button class="btn small" data-manager-tab="orders">جميع الفواتير</button></div>${ordersTable(orders.slice(0,12))}</div><div id="order-details" style="margin-top:15px"></div>`;
}
function managerOrders(target){const orders=managerCache.orders||[];target.innerHTML=`<div class="panel"><div class="section-head"><h3>الفواتير المحفوظة (${orders.length})</h3><button class="btn small" id="export-orders">تصدير CSV</button></div><label class="search" style="margin-bottom:16px">🔎 <input id="manager-invoice-filter" placeholder="رقم الفاتورة أو اسم العميل" /></label><div id="filtered-invoices">${ordersTable(orders)}</div></div><div id="order-details" style="margin-top:15px"></div>`;q("#manager-invoice-filter").addEventListener("input",e=>{const v=e.target.value.trim();q("#filtered-invoices").innerHTML=ordersTable(orders.filter(o=>String(o.invoice_no).includes(v)||String(o.customer_snapshot?.name||"").includes(v)))});q("#export-orders").addEventListener("click",()=>exportCsv(orders.map(o=>({invoice:o.invoice_no,created_at:o.created_at,customer:o.customer_snapshot?.name,status:o.status,total:o.total,paid:o.paid,channel:o.channel})),"oman-invoices.csv"))}
function exportCsv(rows,name){if(!rows.length)return toast("لا توجد بيانات للتصدير","warn");const keys=Object.keys(rows[0]),value=v=>`"${String(v??"").replace(/"/g,'""')}"`;const csv="\ufeff"+[keys.map(value).join(","),...rows.map(r=>keys.map(k=>value(r[k])).join(","))].join("\r\n");const blob=new Blob([csv],{type:"text/csv;charset=utf-8"}),u=URL.createObjectURL(blob),a=document.createElement("a");a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),2000)}
function managerProducts(target){
 target.innerHTML=`<div class="panel"><h3>إضافة صنف جديد</h3><form id="new-product"><div class="form-grid">${field("new-name","اسم المنتج","text","",true)}${field("new-origin","المنشأ")}${sel("new-category","الفئة",categories.map(c=>({value:c.id,label:c.name_ar})))}</div><button class="btn primary">إضافة المنتج</button></form></div><div class="panel" style="margin-top:18px"><h2>المنتجات والأسعار</h2><p class="muted">السعر في قاعدة البيانات وليس في الصور. السعر القديم محفوظ داخل الفاتورة المستخرجة وقت البيع.</p><div class="admin-products">${catalog.map(p=>`<div class="admin-product"><div class="thumb">${esc(p.emoji)}</div><div><div class="row wrap"><strong>${esc(p.name_ar)}</strong><span class="badge gray">${esc(p.origin||"المنشأ غير محدد")}</span><label class="inline tiny"><input type="checkbox" data-prod-active="${p.id}" ${p.active?"checked":""}> منشور</label></div><div class="row wrap"><label class="btn small" for="upload-${esc(p.id)}">📷 تغيير الصورة</label><input id="upload-${esc(p.id)}" type="file" accept="image/png,image/jpeg,image/webp" style="display:none" data-photo="${esc(p.id)}"></div>${p.product_variants.map(v=>`<div class="variant-line"><span><input class="input" data-unit-label="${esc(v.id)}" value="${esc(v.unit_label)}" aria-label="اسم الوحدة"> ${v.needs_review?'<span class="badge warning">تحتاج مراجعة</span>':""}</span><input class="input" type="number" step="0.001" min="0" value="${esc(v.price_value)}" data-price="${esc(v.id)}"><label class="inline tiny"><input type="checkbox" data-review="${esc(v.id)}" ${v.needs_review?"":"checked"}> سعر معتمد</label><label class="inline tiny"><input type="checkbox" data-publish="${esc(v.id)}" ${v.published?"checked":""}> بيع</label><select class="select" data-unit-type="${esc(v.id)}">${["كيلو","حبة","علبة","سلة","كرتون","سحارة","فلين","غير مؤكدة"].map(u=>`<option value="${u}" ${v.price_unit===u?"selected":""}>${u}</option>`).join("")}</select><button class="btn small" data-save-variant="${esc(v.id)}">حفظ</button></div>`).join("")}<details style="margin-top:9px"><summary class="muted tiny">إضافة خيار بيع جديد</summary><div class="row wrap" style="margin-top:10px"><input class="input" style="flex:1" placeholder="وحدة البيع: علبة / كيلو" data-new-unit="${p.id}"><input class="input" style="width:110px" type="number" min="0" step=".001" placeholder="السعر" data-new-price="${p.id}"><button class="btn small" data-new-variant="${p.id}">إضافة</button></div></details></div></div>`).join("")}</div></div>`;
 q("#new-product").addEventListener("submit",async e=>{e.preventDefault();const f=formValues(e.currentTarget);try{await api(db.from("products").insert({slug:"oman-"+Date.now(),name_ar:f["new-name"],origin:f["new-origin"]||null,category_id:f["new-category"],active:true,emoji:"🍎"}));toast("أُضيف المنتج");await refreshProtected()}catch(e){err(e)}});
 qa("[data-save-variant]").forEach(b=>b.addEventListener("click",async()=>{const id=b.dataset.saveVariant;try{const price=num(q(`[data-price="${id}"]`).value),unitLabel=q(`[data-unit-label="${id}"]`).value.trim(),priceUnit=q(`[data-unit-type="${id}"]`).value,approved=q(`[data-review="${id}"]`).checked,published=q(`[data-publish="${id}"]`).checked;if(!Number.isFinite(price)||price<0||!unitLabel)throw Error("السعر أو وحدة البيع غير صالح");await api(db.from("product_variants").update({price_value:price,unit_label:unitLabel,price_unit:priceUnit,unit_confirmed:approved&&priceUnit!=='غير مؤكدة',needs_review:!approved||priceUnit==='غير مؤكدة',published:approved&&published&&priceUnit!=='غير مؤكدة'}).eq("id",id));toast("حُفظ السعر الجديد؛ دون تغيير الفواتير السابقة");await basic();await renderManager()}catch(e){err(e)}}));
 qa("[data-prod-active]").forEach(b=>b.addEventListener("change",async()=>{try{await api(db.from("products").update({active:b.checked}).eq("id",b.dataset.prodActive));toast("حُدث ظهور المنتج")}catch(e){err(e)}}));
 qa("[data-photo]").forEach(f=>f.addEventListener("change",()=>uploadPhoto(f)));
 qa("[data-new-variant]").forEach(b=>b.addEventListener("click",async()=>{const id=b.dataset.newVariant,unit=q(`[data-new-unit="${id}"]`)?.value?.trim(),price=num(q(`[data-new-price="${id}"]`)?.value);if(!unit||price<0)return toast("أدخل الوحدة والسعر","warn");const allowed=["كيلو","حبة","علبة","سلة","كرتون","سحارة","فلين"];const unitType=allowed.find(x=>unit.includes(x))||"غير مؤكدة";try{await api(db.from("product_variants").insert({product_id:id,unit_label:unit,price_unit:unitType,price_value:price,unit_confirmed:unitType!=="غير مؤكدة",needs_review:unitType==="غير مؤكدة",published:unitType!=="غير مؤكدة"}));toast("أُضيف خيار البيع");await basic();await renderManager()}catch(e){err(e)}}));
}
async function uploadPhoto(input){const id=input.dataset.photo,file=input.files?.[0];if(!file)return;if(!["image/png","image/jpeg","image/webp"].includes(file.type)||file.size>5*1024*1024)return toast("الصور المسموحة PNG/JPG/WebP بحجم أقل من 5 ميجابايت","warn");const name=id+"/"+Date.now()+"-"+Math.random().toString(36).slice(2)+"."+file.name.split(".").pop().toLowerCase();try{const up=await db.storage.from("oman-product-images").upload(name,file,{cacheControl:"3600",upsert:false,contentType:file.type});if(up.error)throw up.error;const {data}=db.storage.from("oman-product-images").getPublicUrl(name);await api(db.from("products").update({image_url:data.publicUrl,image_is_original:true}).eq("id",id));toast("حُفظت صورة المنتج بدون تغيير السعر");await basic();await renderManager()}catch(e){err(e)}}
function managerCustomers(target){target.innerHTML=`<div class="panel"><h3>البحث الآمن في سجل العملاء</h3><div class="row"><input class="input" id="manager-customer-search" placeholder="رقم الهاتف أو الاسم"><button class="btn primary" id="manager-find">بحث</button></div><div id="manager-customer-result" style="margin-top:18px"></div></div>`;q("#manager-find").addEventListener("click",async()=>{const v=q("#manager-customer-search").value.trim();try{let arr;if(/[\d٠-٩]/.test(v)&&v.replace(/\D/g,"").length>=8){const c=await api(db.rpc("lookup_customer",{_phone:v}));arr=c?[c]:[]}else{arr=await api(db.rpc("search_customers",{_q:v}))}const slot=q("#manager-customer-result");slot.innerHTML=arr?.length?arr.map(c=>`<div class="panel" style="margin-bottom:10px"><strong>${esc(c.name)}</strong><div class="muted">${esc(c.phone||(c.phones||[]).map(p=>p.phone).join("، "))}</div><button class="btn small" data-customer-details="${esc(c.id)}">عرض السجل المخوّل</button></div>`).join(""):`<p class="muted">لا يوجد عميل مطابق</p>`}catch(e){err(e)}})}
function managerStock(target){
 const vs=catalog.flatMap(p=>p.product_variants.map(v=>({...v,p})));target.innerHTML=`<div class="panel"><h3>جرد المخزون</h3><p class="muted">يمكن تفعيل تتبع مخزون الوحدة من خلال تسجيل الكمية الفعلية. التغيير ينشئ حركة جرد وأثرًا محاسبيًا عند وجود تكلفة.</p><div class="table-wrap"><table class="data-table"><thead><tr><th>الصنف</th><th>الوحدة</th><th>الكمية الحالية</th><th>الكمية الجديدة</th><th>الإجراء</th></tr></thead><tbody>${vs.map(v=>`<tr><td>${esc(v.p.name_ar)}</td><td>${esc(v.unit_label)}</td><td>${v.track_stock?esc(v.stock_qty):"غير مفعّل"}</td><td><input class="input" type="number" min="0" step="0.001" value="${esc(v.stock_qty)}" data-stock-qty="${v.id}" style="width:110px"></td><td><button class="btn small" data-stock-save="${v.id}">تسجيل جرد</button></td></tr>`).join("")}</tbody></table></div></div>`;
 qa("[data-stock-save]").forEach(b=>b.addEventListener("click",async()=>{const id=b.dataset.stockSave,qty=num(q(`[data-stock-qty="${id}"]`).value);if(qty<0)return;try{await api(db.rpc("adjust_stock",{_variant_id:id,_new_qty:qty,_reason:"تسوية جرد يدوي"}));toast("حُفظ الجرد والحركة المحاسبية");await basic();await renderManager()}catch(e){err(e)}}));
}
async function managerAccounting(target){
 const f=daysAgo(29),t=today();target.innerHTML=`<div class="panel"><h3>تقارير الحسابات من دفتر القيود</h3><div class="row wrap"><label>من <input type="date" class="input" id="acc-from" value="${f}"></label><label>إلى <input type="date" class="input" id="acc-to" value="${t}"></label><button id="acc-refresh" class="btn primary">تحديث</button></div><div id="acc-report" style="margin-top:22px">جارٍ احتساب البيانات...</div></div><div class="detail-grid" style="margin-top:20px"><div class="panel"><h3>تسجيل مصروف</h3><form id="expense-form">${field("expense-category","نوع المصروف","text","",true)}${field("expense-amount","المبلغ بالدينار","number","",true)}${sel("expense-method","طريقة الصرف",[{value:"cash",label:"نقدي"},{value:"transfer",label:"بنك"}])}${field("expense-note","ملاحظات")}<button class="btn primary">ترحيل المصروف</button></form></div><div class="panel"><h3>الأرصدة الافتتاحية</h3>${settings.opening_entered?`<div class="success">تم تسجيل الأرصدة الافتتاحية.</div>`:`<div class="notice">أدخل الأرصدة الفعلية قبل اعتماد الميزانية العمومية. لا تعتد بالأرقام عند نقص بيانات تكاليف البضاعة.</div><form id="open-balances">${field("open-cash","نقدية أول المدة","number","0")}${field("open-bank","رصيد البنك","number","0")}${field("open-stock","قيمة المخزون الافتتاحي","number","0")}<button class="btn">تثبيت الأرصدة الافتتاحية</button></form>`}</div></div>`;
 q("#acc-refresh").addEventListener("click",loadAccountReport);
 q("#expense-form").addEventListener("submit",async e=>{e.preventDefault();const v=formValues(e.currentTarget);try{await api(db.rpc("add_expense",{_date:today(),_category:v["expense-category"],_amount:num(v["expense-amount"]),_method:v["expense-method"],_note:v["expense-note"]}));toast("سُجل المصروف في دفتر القيود");await loadAccountReport();e.currentTarget.reset()}catch(e){err(e)}});
 q("#open-balances")?.addEventListener("submit",async e=>{e.preventDefault();const v=formValues(e.currentTarget);try{await api(db.rpc("set_opening_balances",{_cash:num(v["open-cash"]),_bank:num(v["open-bank"]),_inventory:num(v["open-stock"]),_note:"أرصدة افتتاحية معتمدة من المدير"}));toast("حُفظت الأرصدة الافتتاحية");settings.opening_entered=true;await renderManager()}catch(e){err(e)}});
 await loadAccountReport();
}
async function loadAccountReport(){
 try{const list=await api(db.rpc("report_accounts",{_from:q("#acc-from").value,_to:q("#acc-to").value}));const by=code=>list.find(r=>r.code===code)||{},p=code=>num(by(code).period_credit)-num(by(code).period_debit),b=code=>num(by(code).closing_debit)-num(by(code).closing_credit);const revenue=p("4000")+p("4300")+p("4900") + p("4100")+p("4200"),cogs=-p("5000"),jard=-p("5100"),exp=-p("6000")-p("6900"),gross=revenue-cogs,net=gross-exp-jard;
 const html=`<div class="stats-grid"><div class="stat"><small>صافي الإيرادات</small><strong>${cash(revenue)}</strong></div><div class="stat"><small>تكلفة البضاعة</small><strong>${cash(cogs)}</strong></div><div class="stat"><small>مجمل الربح</small><strong>${cash(gross)}</strong></div><div class="stat"><small>صافي الربح المحاسبي</small><strong>${cash(net)}</strong></div></div>${!settings.opening_entered?`<p class="notice">⚠️ الأرصدة الافتتاحية غير مثبتة؛ لا تعتبر هذه ميزانية عمومية معتمدة.</p>`:""}<div class="stats-grid"><div class="stat"><small>الصندوق</small><strong>${cash(b("1000"))}</strong></div><div class="stat"><small>البنك</small><strong>${cash(b("1010"))}</strong></div><div class="stat"><small>ذمم العملاء</small><strong>${cash(b("1100"))}</strong></div><div class="stat"><small>ذمم الموردين</small><strong>${cash(-b("2000"))}</strong></div></div><div class="table-wrap"><table class="data-table"><thead><tr><th>رمز الحساب</th><th>اسم الحساب</th><th>مدين الفترة</th><th>دائن الفترة</th><th>رصيد ختامي</th></tr></thead><tbody>${list.map(r=>`<tr><td>${esc(r.code)}</td><td>${esc(r.name_ar)}</td><td>${cash(r.period_debit)}</td><td>${cash(r.period_credit)}</td><td>${cash(num(r.closing_debit)-num(r.closing_credit))}</td></tr>`).join("")}</tbody></table></div>`;q("#acc-report").innerHTML=html;
 }catch(e){q("#acc-report").innerHTML=`<div class="error-box">${esc(e.message)}</div>`}
}
async function managerSuppliers(target){
 const suppliers=await api(db.from("suppliers").select("*").order("created_at",{ascending:false}).limit(200));const purchases=await api(db.from("purchases").select("*,suppliers(name)").order("purchase_date",{ascending:false}).limit(100));
 target.innerHTML=`<div class="detail-grid"><div class="panel"><h3>إضافة مورد</h3><form id="supplier-form">${field("supplier-name","اسم المورد","text","",true)}${field("supplier-phone","رقم الهاتف")}${field("supplier-note","ملاحظات")}<button class="btn primary">حفظ المورد</button></form></div><div class="panel"><h3>تسجيل فاتورة مشتريات</h3><form id="purchase-form">${sel("purchase-supplier","المورد",[{value:"",label:"بدون تحديد"},...suppliers.map(x=>({value:x.id,label:x.name}))])}${sel("purchase-variant","الصنف",catalog.flatMap(x=>x.product_variants.map(v=>({value:v.id,label:x.name_ar+" / "+v.unit_label}))))}${field("purchase-qty","الكمية","number","1",true)}${field("purchase-cost","تكلفة الوحدة","number","",true)}${field("purchase-paid","المسدد الآن","number","0")}<button class="btn primary">حفظ المشتريات</button></form></div></div><div class="panel" style="margin-top:18px"><h3>الموردون (${suppliers.length})</h3><ul class="list">${suppliers.map(x=>`<li>${esc(x.name)} — ${esc(x.phone||"")}</li>`).join("")||"<li>لا توجد بيانات موردين</li>"}</ul><h3 style="margin-top:20px">آخر المشتريات</h3><div class="table-wrap"><table class="data-table"><thead><tr><th>التاريخ</th><th>المورد</th><th>الإجمالي</th><th>المدفوع</th></tr></thead><tbody>${purchases.map(x=>`<tr><td>${esc(x.purchase_date)}</td><td>${esc(x.suppliers?.name||"—")}</td><td>${cash(x.total)}</td><td>${cash(x.paid)}</td></tr>`).join("")}</tbody></table></div></div>`;
 q("#supplier-form").addEventListener("submit",async e=>{e.preventDefault();const v=formValues(e.currentTarget);try{await api(db.from("suppliers").insert({name:v["supplier-name"],phone:v["supplier-phone"],notes:v["supplier-note"]}));toast("حُفظ المورد");await renderManager()}catch(e){err(e)}});
 q("#purchase-form").addEventListener("submit",async e=>{e.preventDefault();const v=formValues(e.currentTarget);try{await api(db.rpc("add_purchase",{p:{supplier_id:v["purchase-supplier"]||null,items:[{variant_id:v["purchase-variant"],qty:num(v["purchase-qty"]),unit_cost:num(v["purchase-cost"])}],paid:num(v["purchase-paid"]),date:today()}}));toast("حُفظت المشتريات وقيدها المحاسبي");await renderManager()}catch(e){err(e)}});
}
function managerSettings(target){
 target.innerHTML=`<div class="panel" style="max-width:790px"><h3>إعدادات الشركة ونقطة البيع</h3><form id="settings-form"><div class="form-grid">${field("company_name","اسم المتجر","text",settings.company_name,true)}${field("phone","هاتف الشركة","tel",settings.phone)}${field("address","عنوان المتجر","text",settings.address)}${field("delivery_fee","رسوم التوصيل (د.ك)","number",settings.delivery_fee)}${field("free_delivery_over","توصيل مجاني للطلبات فوق","number",settings.free_delivery_over??"")}${field("staff_max_discount_pct","الحد الأقصى لخصم الموظف (%)","number",settings.staff_max_discount_pct)}${sel("print_size","حجم ورق الطباعة",[{value:"a4",label:"A4 - ورقتان"},{value:"80mm",label:"80mm - إيصالان"}],settings.print_size)}</div><div class="row wrap"><label class="inline"><input type="checkbox" name="pay_cod" ${settings.pay_cod?"checked":""}> الدفع عند الاستلام</label><label class="inline"><input type="checkbox" name="pay_transfer" ${settings.pay_transfer?"checked":""}> تحويل يدوي</label><label class="inline"><input type="checkbox" name="pay_credit" ${settings.pay_credit?"checked":""}> البيع الآجل</label></div><div class="field" style="margin-top:16px"><label>سياسة الخصوصية</label><textarea class="textarea" name="privacy_policy">${esc(settings.privacy_policy)}</textarea></div><button class="btn primary">حفظ إعدادات المتجر</button></form><p class="muted tiny">لا يوجد ربط بنكي مباشر أو KNET قبل إعداد مزود دفع رسمي مستقل.</p></div>`;
 q("#settings-form").addEventListener("submit",async e=>{e.preventDefault();const f=formValues(e.currentTarget);const data={company_name:f.company_name,phone:f.phone,address:f.address,delivery_fee:num(f.delivery_fee),free_delivery_over:f.free_delivery_over?num(f.free_delivery_over):null,staff_max_discount_pct:num(f.staff_max_discount_pct),print_size:f.print_size,pay_cod:!!f.pay_cod,pay_transfer:!!f.pay_transfer,pay_credit:!!f.pay_credit,privacy_policy:f.privacy_policy};try{await api(db.from("settings").update(data).eq("id",1));settings={...settings,...data};toast("حُفظت الإعدادات على الخادم");await renderManager()}catch(e){err(e)}});
}

async function managerTeam(target){
 let staff;
 try{
   staff=await api(db.from("employee_directory").select("id,display_name,login_email,position_title,status,user_id,created_at").order("created_at",{ascending:false}));
 }catch(error){
   target.innerHTML='<div class="panel"><h2>إدارة الموظفين</h2><p class="notice">لم يتم تطبيق تحديث قاعدة بيانات الموظفين بعد. تتطلب الإضافة أو التعديل تنفيذ ملف database/employee_directory.sql بواسطة مالك قاعدة البيانات.</p></div>';
   return;
 }
 const active=staff.filter(x=>x.status==="active").length;
 const rows=staff.map(x=>'<tr><td><strong>'+esc(x.display_name)+'</strong></td><td>'+esc(x.position_title)+'</td><td><small class="muted">'+esc(x.login_email)+'</small></td><td><span class="badge '+(x.status==="active"?"":"warning")+'">'+(x.status==="active"?"مفعّل":x.status==="pending"?"بانتظار الاعتماد":"موقوف")+'</span></td><td><div class="actions-row"><button class="btn small" data-team-action="edit" data-team-id="'+esc(x.id)+'">تعديل</button> '+(x.user_id===user?.id?'<span class="badge">المدير - حساب محمي</span>':(x.status==="active"?'<button class="btn small red" data-team-action="disable" data-team-id="'+esc(x.id)+'">إيقاف</button>':'<button class="btn small primary" data-team-action="activate" data-team-id="'+esc(x.id)+'">تفعيل</button>')+' <button class="btn small red" data-team-action="delete" data-team-id="'+esc(x.id)+'">حذف</button>')+'</div></td></tr>').join('');
 target.innerHTML='<div class="panel"><div class="section-head"><div><h2>إدارة المستخدمين والموظفين</h2><p class="muted">اسم الموظف يظهر في شاشات العمل؛ بريد الدخول مخصص للمصادقة ولا يحل محل الاسم.</p></div><span class="badge">'+active+' مفعل من '+staff.length+'</span></div>'
 +'<form id="create-employee" class="staff-form"><div class="form-grid">'
 +field("employee-name","اسم الموظف","text","",true)+field("employee-email","بريد تسجيل الدخول","email","",true)+field("employee-position","المسمّى الوظيفي","text","موظف المبيعات")
 +'</div><button class="btn primary">➕ إضافة موظف جديد</button></form>'
 +'<p class="notice" style="margin:16px 0">إضافة الموظف تنشئ سجلًا باسمه، وليس كلمة مرور. ينشئ الموظف حسابه من صفحة الدخول ويؤكد بريده ثم يضغط المدير «تفعيل». لا تُمنح صلاحية المدير تلقائيًا.</p>'
 +'<div class="table-wrap"><table class="data-table"><thead><tr><th>اسم الموظف</th><th>المسمّى</th><th>بريد الدخول</th><th>الحالة</th><th>الإجراءات</th></tr></thead><tbody>'+(rows||'<tr><td colspan="5" class="center muted">لا يوجد موظفون بعد</td></tr>')+'</tbody></table></div></div>';
 q("#create-employee").addEventListener("submit",async e=>{
   e.preventDefault();const values=formValues(e.currentTarget),button=e.currentTarget.querySelector("button");button.disabled=true;
   try{await api(db.rpc("manage_employee",{p_action:"create",p_employee_id:null,p_display_name:values["employee-name"],p_login_email:values["employee-email"],p_position_title:values["employee-position"]}));toast("تمت إضافة الموظف بالاسم، والحساب بانتظار التفعيل");await managerTeam(target)}
   catch(error){err(error)}finally{button.disabled=false}
 });
 target.onclick=async event=>{
   const button=event.target.closest("button[data-team-action]");if(!button)return;
   const action=button.dataset.teamAction,id=button.dataset.teamId,entry=staff.find(x=>x.id===id);
   if(!entry)return;
   let name=null,email=null,position=null;
   if(action==="edit"){
     name=prompt("اسم الموظف",entry.display_name);if(name===null)return;
     position=prompt("المسمّى الوظيفي",entry.position_title);if(position===null)return;
     if(entry.status==="pending"){email=prompt("بريد الدخول",entry.login_email);if(email===null)return}
   }else if(action==="disable"){
     if(!confirm("إيقاف صلاحية الموظف وسحب حق استقبال الطلبات؟"))return;
   }else if(action==="activate"){
     if(!confirm("هل تحققت من هوية الموظف وملكيته لبريد الدخول؟"))return;
   }else if(action==="delete"){
     if(!confirm("إزالة الموظف وسحب صلاحياته؟ تبقى سجلات الفواتير السابقة والتدقيق محفوظة."))return;
   }else return;
   button.disabled=true;
   try{await api(db.rpc("manage_employee",{p_action:action,p_employee_id:id,p_display_name:name,p_login_email:email,p_position_title:position}));toast("تم حفظ التعديل");await managerTeam(target)}
   catch(error){err(error)}finally{button.disabled=false}
 };
}
async function managerReports(target){
 const records=managerCache.orders||[];
 target.innerHTML='<div class="panel"><h2>تقارير الإدارة</h2><p class="muted">تقارير المدير فقط. مؤشرات الفواتير هنا محدودة بآخر 250 فاتورة؛ الحسابات والميزانية التفصيلية تُستخرج من دفتر القيود.</p>'
 +'<div class="row wrap"><label>من <input type="date" class="input" id="report-from" value="'+daysAgo(29)+'"></label><label>إلى <input type="date" class="input" id="report-to" value="'+today()+'"></label><button id="report-refresh" class="btn primary">تحديث</button><button id="report-export" class="btn">تصدير CSV</button></div>'
 +'<div id="report-output" style="margin-top:18px"></div></div><div class="panel" style="margin-top:18px"><h3>الميزانية ودفتر القيود</h3>'
 +(settings.opening_entered?'<div class="success">الأرصدة الافتتاحية مدخلة. راجع بيانات التكاليف قبل اعتماد الربح النهائي.</div>':'<div class="notice">الميزانية العمومية غير مكتملة دون الأرصدة الافتتاحية وتكاليف البضاعة.</div>')
 +'<button class="btn primary" id="report-ledger">عرض المحاسبة والميزانية</button></div>';
 const calc=()=>{
   const from=q("#report-from").value,to=q("#report-to").value;
   const selected=records.filter(o=>{const d=String(o.created_at||"").slice(0,10);return d>=from&&d<=to});
   const valid=selected.filter(o=>o.status!=="returned"&&o.status!=="cancelled");
   const sum=key=>valid.reduce((acc,o)=>acc+num(o[key]),0);
   return {selected,valid,total:sum("total"),paid:sum("paid"),balance:valid.reduce((acc,o)=>acc+Math.max(0,num(o.total)-num(o.paid)),0)};
 };
 const render=()=>{
   const r=calc();q("#report-output").innerHTML='<div class="stats-grid"><div class="stat"><small>عدد الطلبات</small><strong>'+r.selected.length+'</strong></div><div class="stat"><small>مجموع الفواتير السارية</small><strong>'+cash(r.total)+'</strong></div><div class="stat"><small>المبالغ المحصلة</small><strong>'+cash(r.paid)+'</strong></div><div class="stat"><small>المتبقي على العملاء</small><strong>'+cash(r.balance)+'</strong></div></div>'+(records.length>=250?'<div class="notice">تنبيه: تقرير الفواتير يعرض آخر 250 طلبًا فقط، استخدم دفتر القيود للفترة المحاسبية الكاملة.</div>':'');
 };
 q("#report-refresh").addEventListener("click",render);
 q("#report-export").addEventListener("click",()=>{const rows=calc().selected.map(o=>({invoice:o.invoice_no,date:o.created_at,name:o.customer_snapshot?.name,status:o.status,total:o.total,paid:o.paid}));exportCsv(rows,"oman-manager-invoices.csv")});
 q("#report-ledger").addEventListener("click",()=>{managerTab="accounts";renderManager()});
 render();
}

document.addEventListener("click",async e=>{
 const b=e.target.closest("button");if(!b)return;
 const id=b.dataset.showOrder||b.dataset.printOrder||b.dataset.updateOrder||b.dataset.receiveOrder;
 if(b.dataset.repeatOrder)await repeatCustomerOrder(b.dataset.repeatOrder);
 if(b.dataset.posAdd){const el=q(`[data-pos-select="${b.dataset.posAdd}"]`);if(el)addCart(el.value,true)}
 if(b.dataset.showOrder)await viewOrder(id);
 if(b.dataset.printOrder){const o=(managerCache.orders||[]).find(x=>x.id===id);printTwo(o)}
 if(b.dataset.updateOrder)await setStatus(id);
 if(b.dataset.receiveOrder)await receiveOrder(id);
 if(b.dataset.customerDetails){try{const c=await api(db.rpc("get_customer",{_cid:b.dataset.customerDetails}));const box=q("#manager-customer-result");if(box)box.innerHTML=customerCard(c)}catch(x){err(x)}}
 if(b.dataset.revokeStaff){if(!confirm("هل ترغب في سحب صلاحية الموظف؟"))return;try{await api(db.rpc("revoke_staff",{_user_id:b.dataset.revokeStaff}));toast("سُحبت الصلاحية");await renderManager()}catch(x){err(x)}}
 if(b.dataset.managerTab && page==="manager"&&b.closest("#manager-content")){managerTab=b.dataset.managerTab;renderManager()}
});
init().catch(e=>{root.innerHTML=`<div class="container"><div class="page-title"><h1>تعذر تحميل المتجر</h1><div class="error-box">${esc(e.message)}</div><p>تحقق من اتصال الإنترنت ثم حدّث الصفحة.</p><a class="btn" href="${route()}">العودة للصفحة الرئيسية</a></div></div>`;err(e)});
}
omanCommerceApp();
